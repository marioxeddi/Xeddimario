import CONFIG from '../config'
import storage from '../plugins/localStorage'

import ApolloClient, { createNetworkInterface } from 'apollo-client'

const networkInterface = createNetworkInterface({ uri: CONFIG.main.api.graphql })

networkInterface.use([{
  applyMiddleware (req, next) {
    const token = storage.get('_auth.token') ? storage.get('_auth.token') : null

    if (!req.options.headers) req.options.headers = {}
    if (token) req.options.headers.authorization = `Bearer ${token}`

    next()
  }
}])

const apollo = new ApolloClient({
  networkInterface: networkInterface,
  connectToDevTools: true,
  dataIdFromObject: (result) => {
    if (result.id && result.__typename) {
      return result.__typename + result.id
    }
    return null
  }
})

export default apollo
