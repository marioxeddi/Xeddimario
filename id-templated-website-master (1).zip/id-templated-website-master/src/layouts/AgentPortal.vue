<template>
  <div class="agentPortalLayout">
    <header>
      <div class="header background-primary">
        <ui-layout container justify-space-between wrap>
          <ui-layout
            justify-start
            class="header__logo col-xs-5"
          >
            <img :src="$parent.carrierSettings.logo">
          </ui-layout>
          <ui-layout
            v-if="$route.meta.loginAvailable"
            justify-end
            align-center
            class="col-xs-7"
          >
      <!--  <a
              v-if="$route.name='landingPage'"
              href="#howItWorks"
              class="howItWorks"
            >
              How it works
            </a> -->
            <ui-button
              dense
              dark
              color-primary
              @click.native="$router.push({ name: 'login' })"
            >
              Log In
            </ui-button>
          </ui-layout>
          <ui-layout
            v-if="$route.meta.auth && $route.name !== 'onboardingBoost'"
            class="header__nav col-xs-7"
          >
            <nav>
              <router-link
                v-for="link in links"
                :key="link.name"
                :to="{ name: link.href }"
                :class="{ 'active': link.href === $route.name }"
              >
                {{ link.name }}
              </router-link>
            </nav>
            <button class="mobmenu-btn" @click="mobileNav = !mobileNav">
              <ui-icon class="mobmenu-btn__icon">menu</ui-icon>
            </button>
          </ui-layout>
        </ui-layout>
      </div>
      <div class="mobmenu" :style="{ height: mobileNavHeight() }">
        <router-link
          v-for="link in links"
          :key="link.name"
          :to="{ name: link.href }"
          :class="{ 'background-primary': link.href === $route.name }"
        >
          <span :class="{ 'color-primary': link.href === $route.name }">
            {{ link.name }}
          </span>
        </router-link>
      </div>
    </header>

    <main class="gradient">
      <router-view></router-view>
    </main>

    <footer>
      <div class="footer">
        <ui-layout container align-center justify-space-between>
          <ui-layout justify-start class="col-xs-6">
            <a href="https://www.insurancedrip.com/" target="_blank">
              <img src="/static/id-logo.svg" alt="InsuranceDrip">
            </a>
          </ui-layout>
          <ui-layout justify-end class="col-xs-6">
            <a href="http://xeddi.com/" target="_blank">
              <img src="/static/xeddi-logo.png" alt="Powered by Xeddi">
            </a>
          </ui-layout>
        </ui-layout>
      </div>
    </footer>

    <ui-loading :visible="$store.state.loading.loading" />

    <ui-snackbar :visible="$store.state.states.snackbar" alert>
      {{ $store.state.states.message }}
    </ui-snackbar>
  </div>
</template>

<script>
export default {
  name: 'AgentPortalLayout',
  data () {
    return {
      mobileNav: false,
      links: [
        {
          name: 'Reports',
          href: 'reports'
        },
        {
          name: 'My Boosts',
          href: 'myBoosts'
        },
        {
          name: 'My Account',
          href: 'myAccount'
        },
        {
          name: 'Contacts',
          href: 'contacts'
        },
        {
          name: 'Log Out',
          href: 'logout'
        }
      ]
    }
  },
  mounted () {
    const btn = document.querySelector('.mobmenu-btn')
    const icon = document.querySelector('.mobmenu-btn__icon')

    document.addEventListener('click', (e) => {
      if ((e.target !== btn && e.target !== icon) && this.mobileNav) this.mobileNav = false
    })
  },
  methods: {
    mobileNavHeight () {
      const height = this.links.length * 55

      return this.mobileNav ? height + 'px' : '0'
    }
  }
}
</script>

<style lang="scss">
@import '../assets/scss/variables';
@import '../assets/scss/mixins';

.agentPortalLayout {
  overflow-x: hidden;

  .header {
    padding: 0 30px;
    @include media(md) {
      padding: 0;
    }

    &__logo {
      padding-top:    25px;
      padding-bottom: 25px;

      img {
        height: 16px;
        @include media(md) {
          height: 40px;
        }
      }
    }

    &__nav {
      nav {
        width:           100%;
        display:         flex;
        justify-content: flex-end;

        a {
          margin-right: 40px;
          color:        transparentize($white, .5);
          font-size:    16px;
          text-align:   center;
          font-weight:  500;
          position:     relative;
          display:      flex;
          align-items:  center;

          @include media(md) {
            &:last-of-type {
              margin-right: 0;
            }
          }

          &.active {
            color: darken($white, 5%);

            &:after {
              content:       " ";
              width:         0;
              height:        0;
              border-left:   10px solid transparent;
              border-right:  10px solid transparent;
              border-bottom: 10px solid $white;
              position:      absolute;
              left:          calc(50% - 10px);
              bottom:        0;
            }
          }

          &:not(.active) {
            display: none;
            @include media(md) {
              display: flex;
            }
          }
        }
      }

      button {
        margin-left: auto;
        color:       $white;
        display:     flex;
        align-items: center;
        @include media(md) {
          display: none !important;
        }
      }
    }
  }

  .howItWorks {
    margin-right: 40px;
    color:        $white;
    font-size:    16px;
    font-weight:  500;
    display:      block;
  }

  .mobmenu {
    background:  $white;
    will-change: height;
    transition:  height .3s;
    overflow:    hidden;
    box-shadow:  0 1px 2px $grey-basic;
    position:    relative;
    @include media(md) {
      display: none !important;
    }

    a {
      width:      100%;
      height:     55px;
      padding:    15px;
      text-align: center;
      position:   relative;
      display:    block;

      &.background-primary:after {
        content:    " ";
        background: transparentize($white, .1);
        position:   absolute;
        top:        0;
        right:      0;
        bottom:     0;
        left:       0;
      }

      &:not(:last-of-type) {
        border-bottom: 1px solid $grey-light;
      }

      span {
        color:     $grey-dark;
        font-size: 20px;
        position:  relative;
        z-index:   1;
      }
    }
  }

  .footer {
    height:     60px;
    padding:    0 30px;
    background: $white;
    position:   absolute;
    right:      0;
    bottom:     0;
    left:       0;
    @include media(md) {
      padding: 0;
    }

    & > .ui-layout {
      height: 100%;
    }

    img {
      height: 30px;
      @media screen and (max-width: 320px) {
        max-width: 100px;
      }
    }
  }
}
</style>
