<template>
  <div class="authLayout">
    <header>
      <div class="header">
        <ui-layout container justify-space-between wrap>
          <ui-layout
            justify-start
            class="header__logo col-xs-5"
          >
            <img :src="$parent.carrierSettings.logo">
          </ui-layout>
          <ui-layout
            v-if="$route.meta.loginAvailable"
            justify-end
            align-center
            class="col-xs-7"
          >
            <ui-button
              dense
              dark
              color-primary
              @click.native="$router.push({ name: 'login' })"
            >
              Log In
            </ui-button>
          </ui-layout>
        </ui-layout>
      </div>
    </header>

    <main>
      <router-view></router-view>
    </main>

    <footer>
      <div class="footer">
        <ui-layout container align-center justify-space-between>
          <ui-layout justify-start class="col-xs-6">
            <a href="https://www.insurancedrip.com/" target="_blank">
              <img src="/static/id-logo.svg" alt="InsuranceDrip">
            </a>
          </ui-layout>
          <ui-layout justify-end class="col-xs-6">
            <a href="http://xeddi.com/" target="_blank">
              <img src="/static/xeddi-logo.png" alt="Powered by Xeddi">
            </a>
          </ui-layout>
        </ui-layout>
      </div>
    </footer>

    <ui-loading :visible="$store.state.loading.loading" />

    <ui-snackbar :visible="$store.state.states.snackbar">
      {{ $store.state.states.message }}
    </ui-snackbar>
  </div>
</template>

<script>
export default {
  name: 'AuthLayout'
}
</script>

<style lang="scss">
@import '../assets/scss/variables';
@import '../assets/scss/mixins';

.authLayout {
  overflow-x: hidden;

  .header {
    width:      100%;
    padding:    0 20px;
    background: transparentize($black, .8);
    position:   absolute;
    top:        0;
    left:       0;
    @include media(md) {
      padding: 0;
    }

    &__logo {
      padding-top:    25px;
      padding-bottom: 25px;

      img {
        height: 16px;
        @include media(md) {
          height: 32px;
        }
      }
    }
  }

  main {
    min-height:      calc(100vh - 60px);
    padding-top:     126px;
    background:      url('/static/authbg.jpg') center no-repeat;
    background-size: cover;
    display:         flex;
    align-items:     center;
    justify-content: center;
    @include media(md) {
      padding-top: 82px;
    }
  }

  .footer {
    height:     60px;
    padding:    0 20px;
    background: $white;
    position:   absolute;
    right:      0;
    bottom:     0;
    left:       0;
    @include media(md) {
      padding: 0;
    }

    & > .ui-layout {
      height: 100%;
    }

    img {
      height: 30px;
      @media screen and (max-width: 320px) {
        max-width: 100px;
      }
    }
  }
}
</style>
