import { assign, pick, keys } from 'lodash'

// assign keys that only exists in object1
export const assignOnly = (object1, object2) => {
  return assign({}, object1, pick(object2, keys(object1)))
}
export const slugify = (string) => {
  const from = 'àáäâèéëêìíïîòóöôùúüûňñçßÿœæŕśńṕẃǵǹḿǘẍźḧ·/_,:;'
  const to = 'aaaaeeeeiiiioooouuuuncnsyoarsnpwgnmuxzh------'
  const exp = new RegExp(from.split('').join('|'), 'g')

  return string.toString().toLowerCase()
    .replace(/\s+/g, '-') // Replace spaces with -
    .replace(exp, c =>
      to.charAt(from.indexOf(c))) // Replace special chars
    .replace(/&/g, '-and-') // Replace & with 'and'
    .replace(/[^\w\-]+/g, '') // Remove all non-word chars
    .replace(/\-\-+/g, '-') // Replace multiple - with single -
    .replace(/^-+/, '') // Trim - from start of text
    .replace(/-+$/, '') // Trim - from end of text
}
