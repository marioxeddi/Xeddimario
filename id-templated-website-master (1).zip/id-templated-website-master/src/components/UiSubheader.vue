<template>
  <div
    class="ui-subheader"
    :class="{
      'align-left': alignLeft,
      'align-center': alignCenter,
      'align-right': alignRight
    }"
    :style="{
      fontSize: fontSize + 'px',
      fontWeight: fontWeight,
      marginTop: top + 'px',
      marginBottom: bottom + 'px'
    }"
  >
    <slot></slot>
  </div>
</template>

<script>
export default {
  name: 'UiSubheader',
  props: {
    alignLeft: Boolean,
    alignCenter: Boolean,
    alignRight: Boolean,
    fontSize: [ Number, String ],
    fontWeight: [ Number, String ],
    top: {
      type: [ Number, String ],
      default: 0
    },
    bottom: {
      type: [ Number, String ],
      default: 40
    }
  }
}
</script>

<style lang="scss">
@import '../assets/scss/mixins';

.ui-subheader {
  width:       100%;
  padding:     0 30px;
  font-size:   14px;
  font-weight: 400;
  text-align:  center;
  @include media(md) {
    font-size: 16px;
  }

  &.align-left {
    text-align: left;
  }

  &.align-center {
    text-align: center;
  }

  &.align-right {
    text-align: right;
  }
}
</style>
