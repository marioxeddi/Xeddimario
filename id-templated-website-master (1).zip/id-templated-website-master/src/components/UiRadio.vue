<template>
  <div>
    <div
      v-for="option in options"
      :key="option.value"
      class="ui-radio"
    >
      <label for=""></label>
      <input id="" type="radio" :name="name" :value="option.value">
    </div>
  </div>
</template>

<script>
export default {
  name: 'UiRadio',
  data () {
    return {

    }
  },
  props: {
    name: {
      type: String,
      required: true
    },
    options: {
      type: Array,
      required: true
    },
    checked: Number
  },
  methods: {
    id () {

    }
  }
}
</script>

<style lang="scss">
.ui-radio {

}
</style>
