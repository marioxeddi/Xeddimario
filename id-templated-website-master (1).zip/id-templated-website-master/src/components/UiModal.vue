<template>
  <transition name="fade">
    <div
      v-show="currentlyVisible"
      :id="id"
      class="ui-modal"
      @click="close"
    >
      <transition name="scale">
        <div
          v-show="currentlyVisible"
          class="ui-modal__content"
        >
          <slot></slot>
        </div>
      </transition>
    </div>
  </transition>
</template>

<script>
export default {
  name: 'UiModal',
  data () {
    return {
      currentlyVisible: this.visible
    }
  },
  props: {
    id: {
      type: String,
      required: true
    },
    visible: {
      type: Boolean,
      default: false
    },
    nonClosable: {
      type: Boolean,
      default: false
    }
  },
  methods: {
    open () {
      this.currentlyVisible = true
    },
    close (e) {
      if (this.id) {
        const el = document.getElementById(this.id)

        if (e && !this.nonClosable) {
          if (e.target === el) this.currentlyVisible = false
        } else if (!e && this.nonClosable) {
          this.currentlyVisible = false
        } else if (!e && !this.nonClosable) {
          this.currentlyVisible = false
        } else if (e && this.nonClosable) {
          return
        }
      } else {
        console.warn('You must provide an ID for the modal in order to make it closable')
      }
    }
  }
}
</script>

<style lang="scss">
@import '../assets/scss/variables';

.fade-enter-active, .fade-leave-active {
  transition: opacity .3s cubic-bezier(0.000, 0.735, 0.270, 0.990);
}
.fade-enter, .fade-leave-to {
  opacity: 0;
}
.scale-enter-active, .scale-leave-active {
  transition: transform .3s cubic-bezier(0.000, 0.735, 0.270, 0.990);
}
.scale-enter, .scale-leave-to {
  transform: scale(.75)!important;
}

.ui-modal {
  width:           100%;
  height:          100%;
  background:      transparentize($grey-dark, .2);
  position:        fixed;
  top:             0;
  left:            0;
  z-index:         999;
  display:         flex;
  align-items:     center;
  justify-content: center;

  &__content {
    max-width:     calc(100% - 40px);
    max-height:    calc(100% - 40px);
    padding:       50px;
    background:    $white;
    border-radius: 6px;
    box-shadow:    0 2px 20px transparentize($black, .95);
    transform:     scale(1);
    overflow-y:    auto;
  }
}
</style>
