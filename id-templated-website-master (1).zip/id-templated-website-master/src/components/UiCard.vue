<template>
  <div
    class="ui-card"
    :class="{ 'fluid': fluid, 'unresponsive-style': unresponsiveStyle }"
  >
    <div v-if="header || subheader" class="ui-card__header">
      <div v-if="header" class="ui-card__header__header">
        {{ header }}
      </div>
      <div v-if="subheader" class="ui-card__header__subheader">
        {{ subheader }}
      </div>
    </div>

    <div class="ui-card__content">
      <slot></slot>
    </div>
  </div>
</template>

<script>
export default {
  name: 'UiCard',
  props: {
    header: String,
    subheader: String,
    fluid: Boolean,
    unresponsiveStyle: Boolean
  }
}
</script>

<style lang="scss">
@import '../assets/scss/variables';
@import '../assets/scss/mixins';

.ui-card {
  background: $white;
  box-shadow: 1px 2px 3px transparentize($black, .9);
  @include media(md) {
    border-radius: 6px;
    border:        1px solid $grey-light;
  }

  &.fluid {
    width: 100%;
  }

  &.unresponsive-style {
    border-radius: 6px;
    border:        1px solid $grey-light;
  }

  &__header {
    padding:         20px 30px;
    border-bottom:   1px solid $grey-light;
    display:         flex;
    align-items:     center;
    justify-content: space-between;
    @media screen and (max-width: 640px) {
      flex-wrap: wrap;
    }

    &__header {
      color:       $grey-dark;
      font-size:   18px;
      font-weight: 500;
      line-height: 18px;
      @media screen and (max-width: 640px) {
        max-width:  100%;
        flex-basis: 100%;
      }
    }

    &__subheader {
      color:       $grey-basic;
      font-size:   16px;
      font-weight: 400;
      @media screen and (max-width: 640px) {
        max-width:  100%;
        flex-basis: 100%;
        margin-top: 10px;
      }
    }
  }

  &__content {
    padding: 24px 20px;
  }
}
</style>
