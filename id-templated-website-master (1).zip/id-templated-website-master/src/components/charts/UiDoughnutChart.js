import { Doughnut } from 'vue-chartjs'

export default Doughnut.extend({
  name: 'UiDoughnutChart',
  props: ['data', 'options'],
  mounted () {
    this.renderChart(this.data, this.options)
  },
  watch: {
    data: function () {
      this._chart.destroy()
      this.renderChart(this.data, this.options)
    }
  }
})
