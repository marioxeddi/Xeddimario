<template>
  <button
    class="ui-button"
    :class="{
      'disabled': disabled,
      'dense': dense,
      'success': success,
      'blue': blue,
      'dark': dark,
      'color-primary': colorPrimary,
      'outline': outline,
      'outline-alert': outlineAlert,
      'fluid': fluid
    }"
    v-if="!to"
  >
    <slot></slot>
  </button>
  <button
    class="ui-button"
    :class="{
      'disabled': disabled,
      'dense': dense,
      'success': success,
      'blue': blue,
      'dark': dark,
      'color-primary': colorPrimary,
      'outline': outline,
      'outline-alert': outlineAlert,
      'fluid': fluid
    }"
    v-else
    @click="$router.push({ name: to })"
  >
    <slot></slot>
  </button>
</template>

<script>
export default {
  name: 'UiButton',
  props: {
    disabled: Boolean,
    dense: Boolean,
    success: Boolean,
    blue: Boolean,
    dark: Boolean,
    colorPrimary: Boolean,
    outline: Boolean,
    outlineAlert: Boolean,
    fluid: Boolean,
    to: String
  }
}
</script>

<style lang="scss">
@import "../assets/scss/variables";

.ui-button {
  min-width:     150px;
  padding:       15px 25px;
  color:         $grey-basic;
  font-size:     16px;
  font-weight:   500;
  border-radius: 6px;

  &.disabled {
    background: $grey-light;
    color:      $grey-basic;
  }

  &.dense {
    min-width: 100px;
    padding:   10px 25px;
  }

  &.success {
    background: $success;
    color:      $white;
  }

  &.blue {
    border: 1px solid $blue;
    color:  $blue;
  }

  &.dark {
    background: $white;
  }

  &.outline {
    border: 2px solid $grey-light;
  }

  &.outline-alert {
    border: 2px solid $alert;
    color:  $alert;
  }

  &.fluid {
    width: 100%;
  }
}
</style>
