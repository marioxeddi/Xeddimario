<template>
  <div class="ui-tabs" :class="{ 'card-tabs': cardTabs }">
    <div class="ui-tabs__labels">
      <button
        v-for="(tab, index) in tabList"
        :key="tab.label"
        class="ui-tabs__labels__label"
        :class="{ 'active': index === activeTab }"
        @click="setActiveTab(tab)"
      >
        {{ tab.label }}
      </button>
    </div>
    <div class="ui-tabs__container">
      <div
        class="ui-tabs__container__inner"
        :style="{
          width: fullWidth + 'px',
          transform: 'translateX(-' + position + 'px)'
        }"
      >
        <slot></slot>
      </div>
    </div>
  </div>
</template>

<script>
import { indexOf } from 'lodash'

export default {
  name: 'UiTabs',
  data () {
    return {
      tabList: {},
      tabWidth: 0,
      fullWidth: 0,
      position: 0,
      activeTab: 0
    }
  },
  props: {
    cardTabs: Boolean
  },
  mounted () {
    this.tabList = this.$children
    this.calculateWidths()

    this.$nextTick(() => {
      window.dispatchEvent(new Event('resize'))
    })

    window.addEventListener('resize', () => {
      this.position = this.$el.clientWidth * this.activeTab
      this.calculateWidths()
    })
  },
  methods: {
    calculateWidths () {
      this.tabWidth = this.$el.clientWidth
      this.fullWidth = this.tabWidth * this.tabList.length

      for (const tabId in this.$children) {
        const tab = this.$children[tabId]

        tab.$el.style.width = this.tabWidth + 'px'
      }
    },
    setActiveTab (tab) {
      const index = indexOf(this.tabList, tab)

      this.position = this.$el.clientWidth * index
      this.activeTab = index
    }
  }
}
</script>

<style lang="scss">
@import '../assets/scss/variables';

.ui-tabs {
  width: 100%;

  &.card-tabs {
    width:  calc(100% + 40px);
    margin: -24px -20px 0;

    .ui-tabs__labels {
      padding: 0 30px;
    }

    .ui-tabs__container__inner > * {
      padding: 24px 20px 0;
    }
  }

  &__labels {
    border-bottom:   1px solid $grey-light;
    position:        relative;
    display:         flex;
    justify-content: flex-start;

    &__label {
      padding:  12px 0;
      color:    $grey-dark;
      position: relative;

      &:not(:last-of-type) {
        margin-right: 30px;
      }

      &.active {
        color: $link-classic;

        &:after {
          transform: scaleX(1);
        }
      }

      &:after {
        content:          " ";
        width:            100%;
        height:           1px;
        background:       $link-classic;
        transform:        scaleX(0);
        transform-origin: center;
        position:         absolute;
        bottom:           0;
        left:             0;
        transition:       transform .3s;
      }
    }
  }

  &__container {
    overflow-x: hidden;

    &__inner {
      display:    flex;
      transition: transform .3s cubic-bezier(.25, .8, .25, 1);
    }
  }
}
</style>
