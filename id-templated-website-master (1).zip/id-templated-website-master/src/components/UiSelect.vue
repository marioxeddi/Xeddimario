<template>
  <div class="ui-select" :class="{ 'fluid': fluid }">
    <div v-if="label" class="ui-select__label">
      {{ label }}
    </div>
    <div class="ui-select__input" :class="{ 'placeholder': !value }">
      <template v-if="!value && placeholder">
        {{ placeholder }}
      </template>
      <template v-else-if="!value && !placeholder">
        Select One
      </template>
      <template v-else-if="value">
        {{ value[text] }}
      </template>
    </div>

    <div v-show="dropdownOpen" class="ui-select__options">
      <div
        v-for="item in data"
        :key="item[trackBy]"
        class="ui-select__options__item"
        @click="select(item)"
      >
        <span class="ui-select__options__item__text color-primary">{{ item[text] }}</span>
        <span class="ui-select__options__item__background background-primary"></span>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'UiSelect',
  data () {
    return {
      value: this.default ? this.data[this.default - 1] : null,
      dropdownOpen: false
    }
  },
  props: {
    label: String,
    placeholder: String,
    data: {
      type: Array,
      required: true
    },
    trackBy: {
      type: String,
      required: true
    },
    text: {
      type: String,
      required: true
    },
    fluid: Boolean,
    default: Number
  },
  mounted () {
    const el = this.$el.querySelector('.ui-select__input')

    document.addEventListener('click', (e) => {
      if (e.target === el && !this.dropdownOpen) {
        this.dropdownOpen = true
      } else {
        this.dropdownOpen = false
      }
    })
  },
  methods: {
    select (item) {
      this.value = item
      this.$emit('input', this.value)
      this.$emit('selected', this.value)
    }
  }
}
</script>

<style lang="scss">
@import "../assets/scss/variables";

.ui-select {
  width:    auto;
  cursor:   pointer;
  position: relative;

  &.fluid {
    width: 100%;
  }

  &:not(:last-of-type) {
    margin-bottom: 20px;
  }

  &:only-child {
    margin-bottom: 20px;
  }

  &__label {
    margin-bottom: 10px;
    color:         $grey-basic;
    font-size:     14px;
    font-weight:   400;
    line-height:   14px;
    display:       flex;
    align-items:   center;
  }

  &__input {
    padding:       10px 16px;
    color:         $grey-dark;
    font-weight:   500;
    border:        2px solid $grey-light;
    border-radius: 6px;
    position:      relative;

    &:after {
      font-family: "Material Icons";
      content:     "\E5C5";
      color:       $grey-dark;
      position:    absolute;
      right:       20px;
      top:         50%;
      transform:   translateY(-50%);
    }

    &.placeholder {
      color: transparentize($grey-dark, .3)
    }
  }

  &__options {
    width:         100%;
    max-height:    200px;
    background:    $white;
  	border:        1px solid $grey-light;
  	border-radius: 4px;
  	box-shadow:    0 1px 4px 0 rgba(0,0,0,0.08);
    transform:     translateY(100%);
    position:      absolute;
    bottom:        -2px;
    left:          0;
    z-index:       1;
    overflow-y:    auto;

    &__item {
      padding:     10px 14px;
    	color:       $grey-dark;
    	font-size:   14px;
    	font-weight: 500;
    	line-height: 14px;
      position:    relative;

      &:not(:last-of-type) {
        border-bottom: 1px solid $grey-light;
      }

      &:hover &__background {
        display: block;
      }

      &:not(:hover) &__text {
        color: $grey-dark !important;
      }

      &__text {
        position: relative;
        z-index:  1;
      }

      &__background {
        position: absolute;
        top:      0;
        right:    0;
        bottom:   0;
        left:     0;
        opacity:  .1;
        display:  none;
      }
    }
  }
}
</style>
