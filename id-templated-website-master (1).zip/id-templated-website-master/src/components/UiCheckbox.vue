<template>
  <div class="ui-checkbox">
    <div
      class="ui-checkbox__container"
      :class="{ 'checked': checked }"
      @click="toggleCheck()"
    >
      <div
        class="ui-checkbox__container__icon"
        :class="{
          'background-primary': checked,
          'color-white': checked,
          'dense': dense
        }"
      >
        <ui-icon>check</ui-icon>
      </div>
      <input
        type="checkbox"
        :id="id"
        :value="value"
        :checked="checked"
      />
    </div>

    <label v-if="label" :for="id">
      {{ label }}
    </label>
  </div>
</template>

<script>
export default {
  name: 'UiCheckbox',
  data () {
    return {
      checked: this.value || false
    }
  },
  props: {
    id: String,
    value: Boolean,
    label: String,
    dense: Boolean
  },
  watch: {
    value (value) {
      this.checked = value
    }
  },
  methods: {
    toggleCheck () {
      this.checked = !this.checked
      this.$emit('input', this.checked)
      this.$emit('checked', this.checked)
    }
  }
}
</script>

<style lang="scss">
@import "../assets/scss/variables";

.ui-checkbox {
  display:     flex;
  align-items: center;
  cursor:      pointer;

  &__container {

    &__icon {
      width:           24px;
      height:          24px;
      margin-right:    10px;
      background:      $grey-light;
      color:           $grey-light;
      border-radius:   6px;
      display:         flex;
      align-items:     center;
      justify-content: center;
      transition:      all .3s;

      &.dense {
        width:         16px;
        height:        16px;
        border-radius: 2px;

        i {
          font-size: 14px;
        }
      }

      i {
        font-size: 20px;
      }
    }
  }

  input {
    visibility: hidden;
    position:   absolute;
  }

  label {
    color:       $grey-dark;
    font-size:   14px;
    font-weight: 400;
    cursor:      pointer;
  }
}
</style>
