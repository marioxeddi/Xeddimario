<template>
  <div class="ui-tab" :ref="id">
    <slot></slot>
  </div>
</template>

<script>
export default {
  name: 'UiTab',
  props: {
    label: {
      type: String,
      required: true
    },
    id: {
      type: [ String, Number ],
      required: true
    }
  }
}
</script>
