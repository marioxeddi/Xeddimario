<template>
  <div class="ui-boost-card">
    <div
      class="ui-boost-card__media"
      :style="{
        background: `linear-gradient(rgba(0,0,0,.4),rgba(0,0,0,.4)), url(${coverImage}) top no-repeat`
      }"
    >
      <div class="ui-boost-card__media__tags">
        <div
          v-for="tag in tags"
          :key="tag.text"
          class="ui-boost-card__media__tags__tag"
          :style="{ background: `rgb(${tag.color.r},${tag.color.g},${tag.color.b})` }"
        >
          {{ tag.text }}
        </div>
      </div>
      <div class="ui-boost-card__media__date">
        {{ date | moment('MMMM YYYY') }}
      </div>
    </div>
    <ui-layout
      class="ui-boost-card__content"
      wrap
    >
      <ui-layout
        class="ui-boost-card__content__header col-xs-12"
        v-html="header"
      />
      <ui-layout
        column
        v-html="content"
        class="ui-boost-card__content__content col-xs-12"
      />
    </ui-layout>
  </div>
</template>

<script>
export default {
  name: 'UiBoostCard',
  props: {
    tags: [ Array, Object ],
    date: String,
    coverImage: String,
    header: String,
    content: String
  }
}
</script>

<style lang="scss">
@import '../assets/scss/variables';
@import '../assets/scss/mixins';

.ui-boost-card {
  width:         100%;
  background:    $white;
  border-radius: 6px;
  box-shadow:    1px 2px 3px rgba(0,0,0,.1);
  overflow:      hidden;

  &__media {
    height:          400px;
    padding:         20px 120px 20px 20px;
    background-size: cover !important;
    position:        relative;

    &__tags {
      width: 100%;

      &__tag {
        margin-bottom: 10px;
        padding:       6px 13px;
        background:    #53bbb3;
        color:         $white;
        border-radius: 40px;
        display:       inline-block;

        &:not(:last-of-type) {
          margin-right: 10px;
        }
      }
    }

    &__date {
      color:       $white;
      font-size:   14px;
      font-weight: 400;
      position:    absolute;
      top:         26px;
      right:       26px;
    }
  }

  &__content {
    padding: 10px;
    @include media(md) {
      padding: 30px;
    }

    &__header {
      margin-bottom: 20px;
      color:         $grey-dark;
      font-size:     26px;
      font-weight:   300;
      line-height:   40px;
    }

    &__content {
      color:       $grey-basic;
      font-size:   14px;
      font-weight: 400;
      line-height: 21px;
    }
  }
}
</style>
