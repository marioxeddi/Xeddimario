<template>
  <div v-if="visible" class="loading">
    <div class="loading__spinner"></div>
  </div>
</template>

<script>
export default {
  name: 'UiLoading',
  props: {
    visible: Boolean
  }
}
</script>

<style lang="scss">
@import '../assets/scss/variables';

@keyframes rotate {
  from { transform: rotate(0deg) }
  to   { transform: rotate(360deg) }
}

.loading {
  width:           100%;
  height:          100vh;
  background:      transparentize($black, .15);
  display:         flex;
  align-items:     center;
  justify-content: center;
  position:        fixed;
  top:             0;
  left:            0;
  z-index:         999;

  &__spinner {
    width:         50px;
    height:        50px;
    border-radius: 50%;
    border-top:    4px solid white;
    border-right:  4px solid white;
    animation:     rotate 1s linear infinite;
  }
}
</style>
