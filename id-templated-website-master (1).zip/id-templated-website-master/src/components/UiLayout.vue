<template>
  <div
    class="ui-layout"
    :class="{
      'container': container,
      'wrap': wrap,
      'align-start': alignStart,
      'align-center': alignCenter,
      'align-end': alignEnd,
      'justify-start': justifyStart,
      'justify-center': justifyCenter,
      'justify-end': justifyEnd,
      'justify-space-between': justifySpaceBetween,
      'flex-direction-column': column
    }"
  >
    <slot></slot>
  </div>
</template>

<script>
export default {
  name: 'UiLayout',
  props: {
    container: Boolean,
    wrap: Boolean,
    alignStart: Boolean,
    alignCenter: Boolean,
    alignEnd: Boolean,
    justifyStart: Boolean,
    justifyCenter: Boolean,
    justifyEnd: Boolean,
    justifySpaceBetween: Boolean,
    column: Boolean
  }
}
</script>

<style lang="scss">
@import '../assets/scss/variables';
@import '../assets/scss/mixins';

.ui-layout {
  max-width: 100%;
  display:   flex;

  &:not([class*="col-"]) {
    max-width:  100%;
    flex-basis: 100%;
  }

  &[class*="col-"] {
    padding-right: #{$gutter}px;
    padding-left:  #{$gutter}px;
  }

  &.container:not([class*="col-"]) {
    max-width:    calc(100% + 20px);
    width:        auto;
    margin-left:  -10px;
    margin-right: -10px;
    @include media(md) {
      max-width: 760px;
      width:     760px;
      margin:    0 auto;
      padding:   0 20px;
    }
    @include media(lg) {
      max-width: 1170px;
      width:     1170px;
    }
  }

  &.wrap {
    flex-wrap: wrap;
  }

  &.align-start {
    align-items: flex-start;
  }

  &.align-center {
    align-items: center;
  }

  &.align-end {
    align-items: flex-end;
  }

  &.justify-start {
    justify-content: flex-start;
  }

  &.justify-center {
    justify-content: center;
  }

  &.justify-end {
    justify-content: flex-end;
  }

  &.justify-space-between {
    justify-content: space-between;
  }

  &.flex-direction-column {
    flex-direction: column;
  }

  @each $breakpoint, $size in $breakpoints {
    @for $i from 1 through $columns {
      &.col-#{$breakpoint}-#{$i} {
        @if $size {
          @media screen and (min-width: #{$size}) {
            max-width:  ((100% / $columns) * $i);
            flex-basis: ((100% / $columns) * $i);
          }
        } @else {
          max-width:  ((100% / $columns) * $i);
          flex-basis: ((100% / $columns) * $i);
        }
      }
    }
  }
}
</style>
