<template>
  <div
    class="ui-header"
    :class="{
      'align-left': alignLeft,
      'align-center': alignCenter,
      'align-right': alignRight
    }"
    :style="{
      fontSize: fontSize + 'px',
      fontWeight: fontWeight,
      marginTop: top + 'px',
      marginBottom: bottom + 'px'
    }"
  >
    <slot></slot>
  </div>
</template>

<script>
export default {
  name: 'UiHeader',
  props: {
    alignLeft: Boolean,
    alignCenter: Boolean,
    alignRight: Boolean,
    fontSize: [ Number, String ],
    fontWeight: [ Number, String ],
    top: {
      type: [ Number, String ],
      default: 95
    },
    bottom: {
      type: [ Number, String ],
      default: 45
    }
  }
}
</script>

<style lang="scss">
@import '../assets/scss/variables';
@import '../assets/scss/mixins';

.ui-header {
  width:       100%;
  padding:     0 30px;
  color:       $black;
  font-size:   22px;
  font-weight: 700;
  line-height: 38px;
  text-align:  center;
  @include media(md) {
    font-size: 36px;
  }

  &.align-left {
    text-align: left;
  }

  &.align-center {
    text-align: center;
  }

  &.align-right {
    text-align: right;
  }
}
</style>
