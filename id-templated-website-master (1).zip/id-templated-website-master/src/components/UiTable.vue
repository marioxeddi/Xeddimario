<template>
  <div class="ui-table" :class="{ 'card-table': cardTable }">
    <div class="ui-table__toolbar">
      <div v-if="searchable" class="ui-table__toolbar__search">
        <ui-input v-model="searchString" />
        <div @click="$emit('search', searchString)" class="ui-table__toolbar__search__button">
          <ui-icon>search</ui-icon>
        </div>
      </div>
      <div class="ui-table__toolbar__actions">
        <ui-button
          v-if="deletable"
          dense
          :outline="!selected.length"
          :outline-alert="!!selected.length"
          :style="{
            opacity: !selected.length ? '.4' : '1',
            cursor: !selected.length ? 'default' : 'pointer'
          }"
          @click.native="deleteRows()"
        >
          <ui-icon :size="18">{{ customDeleteIcon || 'delete' }}</ui-icon>
          <span>{{ customDelete || 'Delete' }}</span>
        </ui-button>
        <ui-button
          v-if="customAction"
          dense
          blue
          @click.native="$emit('customAction')"
        >
          <ui-icon :size="18">{{ customActionIcon }}</ui-icon>
          <span>{{ customAction }}</span>
        </ui-button>
      </div>
    </div>
    <div class="ui-table__content">
      <table cellpadding="0" cellspacing="0">
        <thead v-if="fields.length">
          <th>
            <ui-checkbox dense @checked="checkAll" />
          </th>
          <th
            v-for="field in fields"
            :key="field.name"
            class="color-primary"
            @click="sort(field.name)"
          >
            {{ field.header }}
            <ui-icon v-if="currentSorting.column === field.name" class="sorting-icon">
              {{ currentSorting.isSortDesc ? 'arrow_downward' : 'arrow_upward' }}
            </ui-icon>
          </th>
        </thead>
        <tbody>
          <tr
            v-for="(row, index) in data"
            :key="index"
            :class="{ 'deactivated': row.isActive === false }"
          >
            <td>
              <ui-checkbox dense :value="isChecked(row)" @checked="checkOne($event, row)" />
            </td>
            <td v-for="cell in fields" :key="cell.name" :data-header="cell.header">
              {{ data[index][cell.name] }}
            </td>
          </tr>
        </tbody>
      </table>
    </div>
    <div v-if="pagination" class="ui-table__pagination">
      <div class="ui-table__pagination__rows">
        <span>Rows per page:</span>
        <div class="ui-table__pagination__rows__selection">
          <div class="ui-table__pagination__rows__selection__button">
            <span>
              {{ rowsPerPage }}
            </span>
            <ui-icon>
              arrow_drop_down
            </ui-icon>
            <button @focus="dropdownVisible = true" @blur="closeDropdown"></button>
          </div>
          <div
            v-show="dropdownVisible"
            class="ui-table__pagination__rows__selection__dropdown"
          >
            <div
              v-for="item in rowsPerPageOptions"
              :key="item"
              class="ui-table__pagination__rows__selection__dropdown__item"
              @click="$emit('changeCountPerPage', item)"
            >
              {{ item }}
            </div>
          </div>
        </div>
        <div
          v-if="((offset || offset + 1)) && countPerPage && totalCount"
          :style="{ marginRight: '20px' }"
        >
          {{ currentOffset + 1 }}
          -
          {{ currentOffset + rowsPerPage < currentTotalCount ? currentOffset + rowsPerPage : currentTotalCount }}
          of
          {{ currentTotalCount }}
        </div>
        <div class="ui-table__pagination__controls">
          <ui-icon @click.native="prev()">chevron_left</ui-icon>
          <ui-icon @click.native="next()">chevron_right</ui-icon>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { find, indexOf, map } from 'lodash'

export default {
  name: 'UiTable',
  data () {
    return {
      searchString: this.searchQuery || '',
      dropdownVisible: false,
      rowsPerPage: this.countPerPage || 50,
      rowsPerPageOptions: [25, 50, 75, 100],
      currentOffset: this.offset || 0,
      currentTotalCount: this.totalCount || 0,
      selected: [],
      currentSorting: {
        column: this.sorting.column,
        isSortDesc: this.sorting.isSortDesc
      }
    }
  },
  props: {
    cardTable: Boolean,
    fields: {
      type: Array,
      required: true
    },
    // This property is causing a Vue warning in
    // the browser console.
    data: {
      type: Array,
      required: true
    },
    searchQuery: String,
    sorting: Object,
    searchable: Boolean,
    deletable: Boolean,
    customDelete: String,
    customDeleteIcon: String,
    customAction: String,
    customActionIcon: {
      type: String,
      default: 'add'
    },
    pagination: Boolean,
    offset: Number,
    countPerPage: Number,
    totalCount: Number
  },
  watch: {
    sorting (value) {
      this.currentSorting = value
    },
    offset (value) {
      this.currentOffset = value
    },
    countPerPage (value) {
      this.rowsPerPage = value
    },
    totalCount (value) {
      this.currentTotalCount = value
    }
  },
  methods: {
    closeDropdown () {
      setTimeout(() => {
        this.dropdownVisible = false
      }, 500)
    },
    isChecked (row) {
      return !!find(this.selected, row)
    },
    checkAll (value) {
      if (value) {
        this.selected = []
        this.data.forEach((row) => {
          this.selected.push(row)
        })
      } else {
        this.selected = []
      }
    },
    checkOne (value, row) {
      if (value) {
        this.selected.push(row)
      } else {
        this.selected.splice(indexOf(this.selected, row), 1)
      }
    },
    deleteRows () {
      const rowsToDelete = map(this.selected, 'id')

      if (this.selected.length) this.$emit('delete', rowsToDelete)
    },
    sort (column) {
      if (column === this.currentSorting.column) {
        this.currentSorting.isSortDesc = !this.currentSorting.isSortDesc
      } else {
        this.currentSorting = {
          column: column,
          isSortDesc: true
        }
      }

      this.$emit('sort', this.currentSorting)
    },
    prev () {
      if ((this.offset + 1) > this.countPerPage) {
        this.$emit('prev', (this.offset - this.countPerPage))
      } else {
        this.$emit('prev', 0)
      }
    },
    next () {
      if (this.offset < (this.totalCount - this.countPerPage)) {
        this.$emit('next', (this.offset + this.countPerPage))
      }
    }
  }
}
</script>

<style lang="scss">
@import "../assets/scss/variables";
@import "../assets/scss/mixins";

.ui-table {
  width: 100%;

  &.card-table {
    width:        calc(100% + 40px);
    margin-right: -20px;
    margin-left:  -20px;
  }

  &__toolbar {
    padding:     30px 30px 0;
    display:     flex;
    align-items: flex-start;
    flex-wrap:   wrap;
    @media screen and (max-width: 420px) {
      justify-content: center;
    }

    &__search {
      display: flex;

      &__button {
        width:           40px;
        height:          40px;
        color:           $grey-basic;
        border:          2px solid $grey-light;
        border-left:     none;
        border-radius:   0 6px 6px 0;
        display:         flex;
        align-items:     center;
        justify-content: center;
        cursor:          pointer;
      }

      .ui-input input {
        border-radius:      6px 0 0 6px;
        border-right-width: 1px;
      }
    }

    &__actions {
      margin-left: auto;
      display:     flex;
      @media screen and (max-width: 320px) {
        margin-right: auto;
      }

      .ui-button {
        margin-left:  10px;
        border-width: 2px !important;
        @media screen and (max-width: 768px) {
          min-width:       initial !important;
          width:           40px;
          height:          40px;
          padding:         10px !important;
          display:         flex;
          align-items:     center;
          justify-content: center;
        }

        .ui-icon {
          display: inline-block;
          @include media(md) {
            display: none;
          }
        }

        span {
          display: none;
          @include media(md) {
            display: inline-block;
          }
        }
      }
    }
  }

  &__content {
    width:      100%;
    overflow-x: auto;

    table {
      width: 100%;

      &, * {
        @media screen and (max-width: 768px) {
          display: block;
        }
      }

      thead {
        @media screen and (max-width: 768px) {
          display: none;
        }
      }

      tr {
        @media screen and (max-width: 768px) {
          padding:       10px 0;
          border-bottom: 1px solid transparentize($black,.88);
        }
      }

      th, td {
        padding:       8px 30px;
        border-bottom: 1px solid transparentize($black,.88);
        @media screen and (max-width: 768px) {
          border: none;
        }

        &:first-of-type {
          width: 80px;
          @media screen and (max-width: 768px) {
            padding: 0;
          }
        }

        &:not(:first-of-type) {
          @media screen and (max-width: 768px) {
            &:before {
              content:      attr(data-header);
              width:        40%;
              margin-right: 10px;
              color:        $blue;
              font-weight:  500;
              text-align:   right;
              display:      inline-block;
            }
          }
        }
      }

      th {
        font-size:   12px;
        font-weight: 500;
        text-align:  left;
        cursor:      pointer;

        .sorting-icon {
          margin-left:    2px;
          color:          $grey-dark;
          font-size:      13px;
          vertical-align: middle;
        }
      }

      tr {
        &.deactivated {
          background: transparentize($alert, .7);
        }
      }

      td {
        width:     100%;
        color:     $grey-dark;
        font-size: 13px;
        position:  relative;

        @include media(md) {
          width: auto;
        }

        .ui-checkbox {
          @media screen and (max-width: 768px) {
            position: absolute;
            top:      0px;
            left:     20px;
            z-index:  1;
          }

          &__container__icon {
            @media screen and (max-width: 768px) {
              display: flex;
            }
          }
        }
      }
    }
  }

  &__pagination {
    margin-top:      20px;
    color:           $grey-basic;
    display:         flex;
    align-items:     center;
    justify-content: center;
    @include media(md) {
      justify-content: flex-end;
    }

    &__rows {
      display:     flex;
      align-items: center;

      &__selection {
        margin:   0 25px;
        position: relative;

        &__button {
          position:    relative;
          display:     flex;
          align-items: center;

          button {
            width:      100%;
            background: transparent;
            border:     none;
            position:   absolute;
            top:        0;
            right:      0;
            bottom:     0;
            left:       0;
            z-index:    1;
            cursor:     pointer;
          }
        }

        &__dropdown {
          background:    $white;
          border:        1px solid $grey-light;
        	border-radius: 4px;
        	box-shadow:    0 1px 4px 0 rgba(0,0,0,0.08);
          position:      absolute;
          top:           100%;
          right:         0;
          z-index:       2;

          &__item {
            padding: 6px 12px;
            cursor:  pointer;

            &:hover {
              background: $grey-light;
            }

            &:not(:last-of-type) {
              border-bottom: 1px solid $grey-light;
            }
          }
        }
      }
    }

    &__controls {
      display: flex;
      @include media(md) {
        padding-right: 20px;
      }

      .ui-icon {
        margin-left: 0;
        cursor:      pointer;

        @include media(md) {
          margin-left: 20px;
        }
      }
    }
  }
}
</style>
