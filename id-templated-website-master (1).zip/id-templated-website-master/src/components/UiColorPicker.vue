<template>
  <div class="ui-color-picker">
    <div class="ui-color-picker__title">
      Theme Color
    </div>
    <div
      class="ui-color-picker__button"
      :style="{ background: `rgb(${color.r},${color.g},${color.b})` }"
      @click="$refs[`${id}-picker`].open()"
    >
    </div>

    <ui-modal :id="`${id}-picker`" :ref="`${id}-picker`" class="ui-color-picker__picker">
      <color-picker @input="changeColor" :value="color" />

      <ui-modal-actions justify-center>
        <ui-button success @click.native="$refs[`${id}-picker`].close()">
          Confirm
        </ui-button>
      </ui-modal-actions>
    </ui-modal>
  </div>
</template>

<script>
import { Chrome } from 'vue-color'

export default {
  name: 'UiColorPicker',
  components: {
    'color-picker': Chrome
  },
  data () {
    return {
      color: this.value || { r: '186', g: '186', b: '186' },
      pickerVisible: false
    }
  },
  props: {
    id: {
      type: String,
      required: true
    },
    value: Object
  },
  watch: {
    value (value) {
      this.color = value
    }
  },
  methods: {
    changeColor (value) {
      this.color = {
        r: value.rgba.r,
        g: value.rgba.g,
        b: value.rgba.b
      }

      this.$emit('selected', this.color)
    }
  }
}
</script>

<style lang="scss">
@import "../assets/scss/variables";

.ui-color-picker {
  &__title {
    margin-bottom: 10px;
  	color:         $grey-basic;
  	font-size:     14px;
  	line-height:   14px;
  }

  &__button {
    width:         40px;
    height:        40px;
    border-radius: 6px;
    cursor:        pointer;
  }

  &__picker  {
    .ui-modal__content {
      padding: 0 0 50px;
    }

    .vc-chrome {
      box-shadow: none;
    }
  }
}
</style>
