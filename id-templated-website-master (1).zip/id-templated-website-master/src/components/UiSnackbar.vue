<template>
  <div
    class="ui-snackbar"
    :class="{
      'active': active,
      'success': success,
      'alert': alert
    }"
  >
    <slot></slot>
    <div @click="close()" class="ui-snackbar__icon">
      <ui-icon>close</ui-icon>
    </div>
  </div>
</template>

<script>
export default {
  name: 'UiSnackbar',
  data () {
    return {
      active: this.visible
    }
  },
  props: {
    success: Boolean,
    alert: Boolean,
    visible: {
      type: Boolean,
      default: false
    }
  },
  watch: {
    visible (value) {
      value ? this.open() : this.close()
    }
  },
  methods: {
    open () {
      this.active = true
    },
    close () {
      this.active = false
      this.$store.dispatch('states/closeSnackbar')
    }
  }
}
</script>

<style lang="scss">
@import "../assets/scss/variables";

.ui-snackbar {
  padding:       10px 15px;
  background:    transparentize($black, .13);
  color:         $white;
  border-radius: 6px;
  transform:     translate(-50%, 10px);
  box-shadow:    1px 2px 3px rgba(0, 0, 0, 0.1);
  position:      fixed;
  bottom:        40px;
  left:          50%;
  z-index:       -999;
  opacity:       0;
  transition:    all .3s;

  &.active {
    transform: translate(-50%, 0);
    z-index:   999;
    opacity:   1;
  }

  &.success {
    background: transparentize($success, .13);
  }

  &.alert {
    background: transparentize($alert, .13);
  }

  &__icon {
    width:           20px;
    height:          20px;
    background:      $white;
    border-radius:   50px;
    position:        absolute;
    top:             -8px;
    right:           -8px;
    display:         flex;
    align-items:     center;
    justify-content: center;
    cursor:          pointer;

    i {
      font-size: 16px;
      color:     $alert;
    }
  }
}
</style>
