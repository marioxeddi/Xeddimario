<template>
  <div class="ui-social-card" v-tooltip="{content: tooltip, delay: {hide: 500}}">
    <div class="ui-social-card__icon">
      <div 
        class="ui-social-card__icon__background"
        :style="{ background: color }"
      >
      </div>
      <img :src="'/static/socialIcons/' + icon" :alt="name">
      <div v-if="connected" :style="{ color: color }" class="ui-social-card__icon__stats">
        Connected{{ count === null ? '' : ` (${count})`}}
      </div>
    </div>
    <!-- 
      fix css. 
      update accept to only allow .csv when social card type = CSV
      update accept to only allow .vcf when social card type = VCF
    -->
    <div v-if="isUploadFileType">
      <input
        :id="'input-' + type" 
        type="file"
        style="display: none"
        accept=".csv, .vcf"
        @change="selectFile"
        class="ui-social-card__button"
        :style="{ background: color }"
      >
      <div
        class="ui-social-card__button"
        :style="{ background: color }"
        @click="triggerSelectFile(id)"
      >
        {{ name }}
      </div>
    </div>

    <div
      v-else-if="!connected"
      class="ui-social-card__button"
      :style="{ background: color }"
      @click="linkAccount()"
    >
      {{ name }}
    </div>
    <div
      v-else
      class="ui-social-card__disconnect"
      :style="{ color: color, borderColor: color }"
      @click="unlinkAccount()"
    >
      Disconnect
    </div>
  </div>
</template>

<script>
import gql from 'graphql-tag'
import * as axios from 'axios'

export default {
  name: 'UiSocialCard',
  data () {
    return {
      base64FileData: '',
      fileName: '',
      uploadedFile: null
    }
  },
  props: {
    id: Number,
    name: String,
    type: {
      type: String,
      required: true
    },
    redirectURL: String,
    icon: String,
    color: String,
    connected: Boolean,
    count: Number,
    isUploadFileType: Boolean
  },
  computed: {
    url () {
      return `${window.location.origin}/syncHandler/${this.$route.name}/${this.type}`
    },
    tooltip () {
      if (this.name === 'Upload CSV') {
        return '<p>What is a CSV file? A CSV file stores comma-separated tabular data (numbers and text) in plain-text form.</p><p>You can <a href="/static/InsuranceDripCE.csv" download>DOWNLOAD OUR TEMPLATE</a></p>CSV is limited to 1000 contacts per upload. For uploads over the required limit please email the file to <a href="mailto:support@xeddi.com">support@xeddi.com</a>'
      } else if (this.name === 'Import iCloud') {
        return '<p>iCloud contacts can be imported from a VCF file: <a href="https://support.apple.com/kb/PH3606?locale=en_US" target="_blank">INSTRUCTIONS</a>'
      } else if (this.name === 'Import Outlook') {
        return '<p>Connect your Outlook, Live, Hotmail, or MSN account here!</p>'
      } else {
        return null
      }
    }
  },
  methods: {
    linkAccount () {
      this.$store.dispatch('loading/loading', true)

      this.$apollo.query({
        query: gql`
        query requestLinkAccountAuthorizeUrl(
          $type: String!,
          $redirectUrl: String!
        ) {
          requestLinkAccountAuthorizeUrl(
            type: $type,
            redirectUrl: $redirectUrl
          ) {
            authorizeUrl
          }
        }
        `,
        variables: {
          type: this.type,
          redirectUrl: this.redirectURL || this.url
        }
      }).then((response) => {
        this.$store.dispatch('loading/loading', false)
        this.$emit('clicked')
        window.location.href = response.data.requestLinkAccountAuthorizeUrl.authorizeUrl
      }).catch((response) => {
        this.$store.dispatch('loading/loading', false)
        this.$store.dispatch('states/setMessage', response.graphQLErrors[0].message)
        this.$store.dispatch('states/openSnackbar')
      })
    },
    unlinkAccount () {
      this.$store.dispatch('loading/loading', true)

      this.$apollo.mutate({
        mutation: gql`
        mutation unlinkAccount($type: String!, $id: Int!, $isDeleteContacts: Boolean) {
          unlinkAccount(type: $type, id: $id, isDeleteContacts: $isDeleteContacts) {
            isSuccessful
            message
          }
        }
        `,
        variables: {
          type: this.type,
          id: this.id,
          isDeleteContacts: true
        },
        refetchQueries: [
          {
            query: gql`
            query getConnections {
              getConnections {
                totalCount
                contactConnections {
                  id
                  name
                  type
                  icon
                  color
                  isConnected
                  count
                  isUploadFileType
                }
              }
            }
            `
          },
          {
            query: gql`
            query getConnections {
              getConnections {
                socialMediaConnections {
                  id
                  name
                  type
                  icon
                  color
                  isConnected
                }
              }
            }
            `
          },
          {
            query: gql`
            query getConnections {
              getConnections {
                totalCount
                contactConnections {
                  id
                  name
                  type
                  icon
                  color
                  isConnected
                  count
                  isUploadFileType
                }
                socialMediaConnections {
                  id
                  name
                  type
                  icon
                  color
                  isConnected
                }
              }
            }
            `
          }
        ]
      }).then((response) => {
        this.$store.dispatch('loading/loading', false)
      }).catch((response) => {
        this.$store.dispatch('loading/loading', false)
        this.$store.dispatch('states/setMessage', response.graphQLErrors[0].message)
        this.$store.dispatch('states/openSnackbar')
      })
    },
    triggerSelectFile (id) {
      document.getElementById('input-' + this.type).click()
    },
    selectFile (e) {
      const file = e.target.files[0]
      this.fileName = file.name

      // if (!file || !file.type.includes('image/')) {
      //   return
      // }

      if (typeof FileReader === 'function') {
        const reader = new FileReader()

        reader.onload = (event) => {
          this.base64FileData = event.target.result
        }

        reader.readAsDataURL(file)
        this.uploadFile()
      } else {
        alert('Sorry, FileReader API not supported')
      }
    },
    uploadFile () {
      this.$store.dispatch('loading/loading', true)

      this.$apollo.query({
        query: gql`
        query requestFileUploadToken {
          requestFileUploadToken {
            postUrl
          }
        }
        `
      }).then((response) => {
        const url = response.data.requestFileUploadToken.postUrl
        axios.post(url, { imageData: this.base64FileData, name: this.fileName }).then((response2) => {
          this.uploadedFile = response2.data.getUrl
          this.uploadContacts()
        }).catch(() => {
          this.$store.dispatch('loading/loading', false)
          this.$store.dispatch('states/setMessage', 'The image upload failed. Please try repeating the action.')
          this.$store.dispatch('states/openSnackbar')
        })
      }).catch((response) => {
        this.$store.dispatch('loading/loading', false)
        this.$store.dispatch('states/setMessage', response.graphQLErrors[0].message)
        this.$store.dispatch('states/openSnackbar')
      })
    },
    uploadContacts () {
      document.getElementById('input-' + this.type).value = ''

      this.$apollo.mutate({
        mutation: gql`
        mutation uploadContacts($type: String!, $fileUrl: String!) {
          uploadContacts(type: $type, fileUrl: $fileUrl) {
            isSuccessful
            message
          }
        }
        `,
        variables: {
          type: this.type,
          fileUrl: this.uploadedFile
        },
        refetchQueries: [
          {
            query: gql`
            query getConnections {
              getConnections {
                totalCount
                contactConnections {
                  id
                  name
                  type
                  icon
                  color
                  isConnected
                  count
                  isUploadFileType
                }
              }
            }
            `
          },
          {
            query: gql`
            query getConnections {
              getConnections {
                socialMediaConnections {
                  id
                  name
                  type
                  icon
                  color
                  isConnected
                }
              }
            }
            `
          },
          {
            query: gql`
            query getConnections {
              getConnections {
                totalCount
                contactConnections {
                  id
                  name
                  type
                  icon
                  color
                  isConnected
                  count
                  isUploadFileType
                }
                socialMediaConnections {
                  id
                  name
                  type
                  icon
                  color
                  isConnected
                }
              }
            }
            `
          }
        ]
      }).then((response) => {
        this.$store.dispatch('loading/loading', false)
      }).catch((response) => {
        this.$store.dispatch('loading/loading', false)
        this.$store.dispatch('states/setMessage', response.graphQLErrors[0].message)
        this.$store.dispatch('states/openSnackbar')
      })
    }
  }
}
</script>

<style lang="scss">
@import '../assets/scss/variables';
@import '../assets/scss/mixins';

.ui-social-card {
  width: 100%;
  @media screen and (max-width: 768px) {
    margin: 10px 0;
  }

  &__icon {
    height:          150px;
    border-radius:   6px;
    display:         flex;
    align-items:     center;
    justify-content: center;
    position:        relative;
    // overflow:        hidden;

    &__background {
      width:    100%;
      height:   100%;
      position: absolute;
      top:      0;
      left:     0;
      opacity:  .1;
      border-radius: 6px;
    }

    &__stats {
      width:      100%;
      font-size:  12px;
      text-align: center;
      position:   absolute;
      bottom:     10px;
      left:       0;
    }

    img {
      max-width: 50px;
    }
  }

  &__button {
    margin-top:      10px;
    padding:         10px;
    color:           $white;
    font-size:       14px;
    text-align:      center;
    font-weight:     500;
    border-radius:   6px;
    display:         flex;
    align-items:     center;
    justify-content: center;
    cursor:          pointer;
  }

  &__disconnect {
    margin-top:      10px;
    padding:         9px;
    font-size:       14px;
    text-align:      center;
    font-weight:     500;
    border:          1px solid transparent;
    border-radius:   6px;
    display:         flex;
    align-items:     center;
    justify-content: center;
    cursor:          pointer;
  }
}

// Tooltip styling
// .tip-icon {
//   background-color: $grey-dark;
//   color: white;
//   font-size: 18px;
//   padding-left: 6px;
//   padding-right: 6px;
//   border-radius: 50%;
//   position: absolute;
//   top: 0px;
//   left: 15px;
// }

.tooltip {
  display: block !important;
  z-index: 10000;
  @include media(sm) {
    width: 100%;
  }
  @include media(md) {
    max-width: 30%;
  }

  .tooltip-inner {
    background:    white;
    color:         $grey-dark;
    border:        1px solid $grey-basic;
    border-radius: 16px;
    padding:       5px 10px 4px;
    p {
      text-align: center;
    }
    a {
      text-decoration: none;
      color:           $blue;
    }
  }

  .tooltip-arrow {
    width: 0;
    height: 0;
    border-style: solid;
    position: absolute;
    margin: 5px;
    border-color: $grey-basic;
    z-index: 1;
  }

  &[x-placement^="top"] {
    margin-bottom: 5px;

    .tooltip-arrow {
      border-width: 5px 5px 0 5px;
      border-left-color: transparent !important;
      border-right-color: transparent !important;
      border-bottom-color: transparent !important;
      bottom: -5px;
      left: calc(50% - 5px);
      margin-top: 0;
      margin-bottom: 0;
    }
  }

  &[x-placement^="bottom"] {
    margin-top: 5px;

    .tooltip-arrow {
      border-width: 0 5px 5px 5px;
      border-left-color: transparent !important;
      border-right-color: transparent !important;
      border-top-color: transparent !important;
      top: -5px;
      left: calc(50% - 5px);
      margin-top: 0;
      margin-bottom: 0;
    }
  }

  &[x-placement^="right"] {
    margin-left: 5px;

    .tooltip-arrow {
      border-width: 5px 5px 5px 0;
      border-left-color: transparent !important;
      border-top-color: transparent !important;
      border-bottom-color: transparent !important;
      left: -5px;
      top: calc(50% - 5px);
      margin-left: 0;
      margin-right: 0;
    }
  }

  &[x-placement^="left"] {
    margin-right: 5px;

    .tooltip-arrow {
      border-width: 5px 0 5px 5px;
      border-top-color: transparent !important;
      border-right-color: transparent !important;
      border-bottom-color: transparent !important;
      right: -5px;
      top: calc(50% - 5px);
      margin-left: 0;
      margin-right: 0;
    }
  }

  &[aria-hidden='true'] {
    visibility: hidden;
    opacity: 0;
    transition: opacity .15s, visibility .15s;
  }

  &[aria-hidden='false'] {
    visibility: visible;
    opacity: 1;
    transition: opacity .15s;
  }
}

.iCloudImg {
  max-width: 100%;
  @include media(sm) {
    visibility: hidden;
  }
  @include media(md) {
    visibility: visible;
  }
}
</style>
