<template>
  <div
    class="ui-input"
    :class="{
      'fluid': fluid,
      'valid': validation && isValid !==null && isValid,
      'invalid': validation && isValid !==null && !isValid
    }"
  >
    <label v-if="label" :style="{ textAlign: labelRight ? 'right' : '' }">
      {{ label }}
      <div v-if="tooltip" class="ui-input__tooltip">
        <div class="ui-input__tooltip__icon">?</div>
        <div class="ui-input__tooltip__tooltip">
          {{ tooltip }}
        </div>
      </div>
    </label>
    <template v-if="mask">
      <input
        v-if="type === 'text'"
        type="text"
        :placeholder="placeholder"
        :value="value"
        v-model="currentValue"
        :class="{ 'fluid': fluid }"
        :style="{ maxWidth: maxWidth + 'px' }"
        v-mask="mask"
        @focus="$emit('focus')"
        @blur="$emit('blur')"
      />
      <input
        v-if="type === 'password'"
        type="password"
        :placeholder="placeholder"
        :value="value"
        v-model="currentValue"
        :class="{ 'fluid': fluid }"
        :style="{ maxWidth: maxWidth + 'px' }"
        v-mask="mask"
        @focus="$emit('focus')"
        @blur="$emit('blur')"
      />
      <input
        v-if="type === 'tel'"
        type="tel"
        :placeholder="placeholder"
        :value="value"
        v-model="currentValue"
        :class="{ 'fluid': fluid }"
        :style="{ maxWidth: maxWidth + 'px' }"
        v-mask="mask"
        @focus="$emit('focus')"
        @blur="$emit('blur')"
      />
    </template>
    <template v-else>
      <input
        v-if="type === 'text'"
        type="text"
        :placeholder="placeholder"
        :value="value"
        v-model="currentValue"
        :class="{ 'fluid': fluid }"
        :style="{ maxWidth: maxWidth + 'px' }"
        @focus="$emit('focus')"
        @blur="$emit('blur')"
      />
      <input
        v-if="type === 'password'"
        type="password"
        :placeholder="placeholder"
        :value="value"
        v-model="currentValue"
        :class="{ 'fluid': fluid }"
        :style="{ maxWidth: maxWidth + 'px' }"
        @focus="$emit('focus')"
        @blur="$emit('blur')"
      />
      <input
        v-if="type === 'tel'"
        type="tel"
        :placeholder="placeholder"
        :value="value"
        v-model="currentValue"
        :class="{ 'fluid': fluid }"
        :style="{ maxWidth: maxWidth + 'px' }"
        @focus="$emit('focus')"
        @blur="$emit('blur')"
      />
    </template>
  </div>
</template>

<script>
export default {
  name: 'UiInput',
  data () {
    return {
      currentValue: this.value,
      isValid: null
    }
  },
  props: {
    type: {
      type: String,
      default: 'text'
    },
    label: String,
    labelRight: Boolean,
    placeholder: String,
    value: [ String, Number ],
    fluid: Boolean,
    tooltip: String,
    maxWidth: [ String, Number ],
    mask: String,
    validation: Boolean,
    valid: Boolean
  },
  watch: {
    currentValue () {
      this.isValid = this.valid
      this.$emit('input', this.currentValue)
    },
    valid () {
      this.isValid = this.valid
    }
  }
}
</script>

<style lang="scss">
@import "../assets/scss/variables";
@import '../assets/scss/mixins';

.ui-input {
  position: relative;

  &.fluid {
    width: 100%;
  }

  &:not(:last-of-type) {
    margin-bottom: 20px;
  }

  &:only-child {
    margin-bottom: 20px;
  }

  &.valid {
    input {
      padding-right: 34px;
      border:        2px solid $success;
    }

    &:after {
      font-family: "Material Icons";
      content:     "\E5CA";
      color:       $success;
      position:    absolute;
      bottom:      13px;
      right:       10px;
    }
  }

  &.invalid {
    input {
      padding-right: 34px;
      border:        2px solid $alert;
    }

    &:after {
      font-family: "Material Icons";
      content:     "\E5CD";
      color:       $alert;
      position:    absolute;
      bottom:      13px;
      right:       10px;
    }
  }

  &__tooltip {
    position: relative;
    @media screen and (max-width: 320px) {
      display: none;
    }

    &__icon {
      width:           15px;
      height:          15px;
      margin-left:     7px;
      color:           $grey-basic;
      font-size:       12px;
      font-weight:     500;
      line-height:     12px;
      border:          2px solid $grey-light;
      border-radius:   50%;
      display:         flex;
      align-items:     center;
      justify-content: center;
      cursor:          pointer;

      &:hover + .ui-input__tooltip__tooltip {
        opacity: 1;
      }
    }

    &__tooltip {
      width:            180px;
      padding:          7px 10px;
      color:            $white;
      font-size:        11px;
      font-weight:      400;
      line-height:      18px;
      background-color: transparentize($black, .2);
      border-radius:    4px;
      box-shadow:       0 1px 4px rgba(44, 64, 90, 0.21);
      position:         absolute;
      bottom:           50%;
      left:             27px;
      opacity:          0;
      transition:       opacity .3s;
      pointer-events:   none;
      @include media(md) {
        width: 280px;
      }
    }
  }

  label {
    margin-bottom: 10px;
    color:         $grey-basic;
    font-size:     14px;
    font-weight:   400;
    line-height:   14px;
    display:       flex;
    align-items:   center;
  }

  input {
    padding:       10px 16px;
    color:         $grey-dark;
    font-weight:   500;
    border:        2px solid $grey-light;
    border-radius: 6px;

    &:focus {
      border: 2px solid $blue;
    }

    &.fluid {
      width: 100%;
    }
  }

}
</style>
