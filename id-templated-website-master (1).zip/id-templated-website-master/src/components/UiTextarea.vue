<template>
  <div
    class="ui-textarea"
    :class="{ 'fluid': fluid }"
  >
    <label :style="{ textAlign: labelRight ? 'right' : '' }">
      {{ label }}
      <div v-if="tooltip" class="ui-input__tooltip">
        <div class="ui-input__tooltip__icon">?</div>
        <div class="ui-input__tooltip__tooltip">
          {{ tooltip }}
        </div>
      </div>
    </label>
    <textarea
      v-model="currentValue"
      :rows="rows"
      :placeholder="placeholder"
      :class="{ 'fluid': fluid, 'resizable': resizable }"
      :style="{ maxWidth: maxWidth + 'px' }"
    >
      {{ value }}
    </textarea>
  </div>
</template>

<script>
export default {
  name: 'UiTextarea',
  data () {
    return {
      currentValue: this.value
    }
  },
  props: {
    label: String,
    labelRight: Boolean,
    rows: {
      type: [ String, Number ],
      default: 8
    },
    placeholder: String,
    value: [ String, Number ],
    fluid: Boolean,
    tooltip: String,
    maxWidth: [ String, Number ],
    resizable: Boolean
  },
  watch: {
    currentValue () {
      this.$emit('input', this.currentValue)
    }
  }
}
</script>

<style lang="scss">
@import "../assets/scss/variables";
@import '../assets/scss/mixins';

.ui-textarea {
  &.fluid {
    width: 100%;
  }

  &:not(:last-of-type) {
    margin-bottom: 20px;
  }

  &:only-child {
    margin-bottom: 20px;
  }

  &__tooltip {
    position: relative;
    @media screen and (max-width: 320px) {
      display: none;
    }

    &__icon {
      width:           15px;
      height:          15px;
      margin-left:     7px;
      color:           $grey-basic;
      font-size:       12px;
      font-weight:     500;
      line-height:     12px;
      border:          2px solid $grey-light;
      border-radius:   50%;
      display:         flex;
      align-items:     center;
      justify-content: center;
      cursor:          pointer;

      &:hover + .ui-input__tooltip__tooltip {
        opacity: 1;
      }
    }

    &__tooltip {
      width:            180px;
      padding:          7px 10px;
      color:            $white;
      font-size:        11px;
      font-weight:      400;
      line-height:      18px;
      background-color: transparentize($black, .2);
      border-radius:    4px;
      box-shadow:       0 1px 4px rgba(44, 64, 90, 0.21);
      position:         absolute;
      bottom:           50%;
      left:             27px;
      opacity:          0;
      transition:       opacity .3s;
      @include media(md) {
        width: 280px;
      }
    }
  }

  label {
    margin-bottom: 10px;
    color:         $grey-basic;
    font-size:     14px;
    font-weight:   400;
    line-height:   14px;
    display:       flex;
    align-items:   center;
  }

  textarea {
    padding:       10px 16px;
    color:         $grey-dark;
    font-weight:   500;
    border:        2px solid $grey-light;
    border-radius: 6px;

    &.fluid {
      width: 100%;
    }

    &:not(.resizable) {
      resize: none;
    }
  }
}
</style>
