<template>
  <div class="ui-form-header">
    <slot></slot>
  </div>
</template>

<script>
export default {
  name: 'UiFormHeader'
}
</script>

<style lang="scss">
@import "../assets/scss/variables";

.ui-form-header {
  margin:      30px 0;
  color:       $grey-dark;
  font-size:   18px;
  font-weight: 500;
  line-height: 18px;
}
</style>
