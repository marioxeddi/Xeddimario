<template>
  <div
    class="ui-modal-actions"
    :class="{
      'wrap': wrap,
      'align-start': alignStart,
      'align-center': alignCenter,
      'align-end': alignEnd,
      'justify-start': justifyStart,
      'justify-center': justifyCenter,
      'justify-end': justifyEnd,
      'justify-space-between': justifySpaceBetween,
      'flex-direction-column': column
    }"
  >
    <slot></slot>
  </div>
</template>

<script>
export default {
  name: 'UiModalActions',
  props: {
    wrap: Boolean,
    alignStart: Boolean,
    alignCenter: Boolean,
    alignEnd: Boolean,
    justifyStart: Boolean,
    justifyCenter: Boolean,
    justifyEnd: Boolean,
    justifySpaceBetween: Boolean,
    column: Boolean
  }
}
</script>

<style lang="scss">
.ui-modal-actions {
  margin:  0 -10px -20px;
  display: flex;

  &.wrap {
    flex-wrap: wrap;
  }

  &.align-start {
    align-items: flex-start;
  }

  &.align-center {
    align-items: center;
  }

  &.align-end {
    align-items: flex-end;
  }

  &.justify-start {
    justify-content: flex-start;
  }

  &.justify-center {
    justify-content: center;
  }

  &.justify-end {
    justify-content: flex-end;
  }

  &.justify-space-between {
    justify-content: space-between;
  }

  &.flex-direction-column {
    flex-direction: column;
  }

  .ui-button {
    margin: 30px 10px 0;
  }
}
</style>
