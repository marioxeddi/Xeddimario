<template>
  <div class="ui-mini-boost-card">
    <div
      class="ui-mini-boost-card__media"
      :style="{
        background: `linear-gradient(rgba(0,0,0,.4),rgba(0,0,0,.4)), url(${coverImage}) top no-repeat`
      }"
    >
      <div class="ui-mini-boost-card__media__tags">
        <div
          v-for="tag in tags"
          :key="tag.text"
          class="ui-mini-boost-card__media__tags__tag"
          :style="{ background: `rgb(${tag.color.r},${tag.color.g},${tag.color.b})` }"
        >
          {{ tag.text }}
        </div>
      </div>
      <div class="ui-mini-boost-card__media__date">
        {{ date | moment('MMMM YYYY') }}
      </div>
      <div class="ui-mini-boost-card__media__header">
        {{ header }}
      </div>
    </div>
    <div class="ui-mini-boost-card__content">
      <div class="ui-mini-boost-card__content__text">
        {{ content }}
      </div>
      <div class="ui-mini-boost-card__content__button">
        <ui-button v-if="completed" class="background-primary color-white" dense>
          Delivered
        </ui-button>
        <ui-button v-else success dense>
          Send Now
        </ui-button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'UiBoostLibraryMiniCard',
  props: {
    tags: [ Array, Object ],
    date: String,
    coverImage: String,
    header: String,
    content: String,
    completed: Boolean
  }
}
</script>

<style lang="scss">
@import '../assets/scss/variables';

.ui-mini-boost-card {
  width:         100%;
  background:    $white;
  border-radius: 6px;
  box-shadow:    1px 2px 3px rgba(0,0,0,.1);
  overflow:      hidden;
  cursor:        pointer;

  &__media {
    height:          270px;
    padding:         20px;
    background-size: cover !important;
    display:         flex;
    flex-direction:  column;
    justify-content: space-between;
    position:        relative;

    &__tags {
      width:         100%;
      padding-right: 100px;

      &__tag {
        margin-bottom: 10px;
        padding:       6px 13px;
        background:    #53bbb3;
        color:         $white;
        border-radius: 40px;
        display:       inline-block;

        &:not(:last-of-type) {
          margin-right: 10px;
        }
      }
    }

    &__date {
      color:       $white;
      font-size:   14px;
      font-weight: 400;
      position:    absolute;
      top:         26px;
      right:       26px;
    }

    &__header {
      color:       $white;
      font-size:   14px;
      font-weight: 400;
      line-height: 20px;
    }
  }

  &__content {
    padding: 20px;

    &__text {
      height:      63px;
      color:       $grey-basic;
      font-size:   14px;
      font-weight: 400;
      line-height: 21px;
      overflow:    hidden;
      position:    relative;

      &:after {
        content:    " ";
        width:      100%;
        height:     100%;
        background: linear-gradient(to top, $white, rgba(255,255,255,0));
        position:   absolute;
        bottom:     0;
        left:       0;
      }
    }

    &__button {
      padding-top: 20px;

      .ui-button {
        width:     100%;
        font-size: 14px;
      }
    }
  }

  &__stats {
    padding:     0px 20px 20px 20px;
    display:     flex;

    div {
      flex:      1;
      color:     $grey-dark;
      font-size: 16px;

      span {
        color:     $grey-basic;
        font-size: 12px;
        display:   block;
      }
    }
  }
}
</style>
