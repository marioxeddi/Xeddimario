// Components
import UiButton from './UiButton.vue'
import UiInput from './UiInput.vue'
import UiCheckbox from './UiCheckbox.vue'
import UiSelect from './UiSelect.vue'
import UiTextarea from './UiTextarea.vue'
import UiHeader from './UiHeader.vue'
import UiSubheader from './UiSubheader.vue'
import UiFormHeader from './UiFormHeader.vue'
import UiLayout from './UiLayout.vue'
import UiCard from './UiCard.vue'
import UiBoostCard from './UiBoostCard.vue'
import UiMiniBoostCard from './UiMiniBoostCard.vue'
import UiSocialCard from './UiSocialCard'
import UiAvatar from './UiAvatar.vue'
import UiIcon from './UiIcon.vue'
import UiModal from './UiModal.vue'
import UiModalActions from './UiModalActions.vue'
import UiTabs from './UiTabs.vue'
import UiTab from './UiTab.vue'
import UiSnackbar from './UiSnackbar.vue'
import UiLoading from './UiLoading.vue'
import UiPagination from './UiPagination.vue'
import UiTable from './UiTable.vue'
import UiColorPicker from './UiColorPicker.vue'
import UiBoostLibraryMiniCard from './UiBoostLibraryMiniCard.vue'

// Charts
import UiBarChart from './charts/UiBarChart'
import UiDoughnutChart from './charts/UiDoughnutChart'
import UiLineChart from './charts/UiLineChart'

// Define global components
export const globalComponents = {
  UiButton,
  UiInput,
  UiCheckbox,
  UiSelect,
  UiTextarea,
  UiHeader,
  UiSubheader,
  UiFormHeader,
  UiLayout,
  UiCard,
  UiMiniBoostCard,
  UiBoostCard,
  UiSocialCard,
  UiAvatar,
  UiIcon,
  UiModal,
  UiModalActions,
  UiTabs,
  UiTab,
  UiSnackbar,
  UiLoading,
  UiPagination,
  UiTable,
  UiColorPicker,
  UiBoostLibraryMiniCard,

  UiBarChart,
  UiDoughnutChart,
  UiLineChart
}

// Export global components
export default Vue => {
  Object.keys(globalComponents).forEach((name) => {
    Vue.component(name, globalComponents[name])
  })
}
