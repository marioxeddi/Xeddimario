<template>
  <div class="ui-pagination">
    <div
      @click="prev()"
      class="ui-pagination__prev"
      :class="{ 'disabled': this.prevDisabled }"
    >
      <ui-icon>play_arrow</ui-icon>
    </div>
    <div class="ui-pagination__text">
      Page {{ page }} of {{ pages }}
    </div>
    <div
      @click="next()"
      class="ui-pagination__next"
      :class="{ 'disabled': this.nextDisabled }"
    >
      <ui-icon>play_arrow</ui-icon>
    </div>
  </div>
</template>

<script>
export default {
  name: 'UiPagination',
  data () {
    return {
      page: this.current
    }
  },
  props: {
    current: {
      type: Number,
      required: true
    },
    pages: {
      type: Number,
      required: true
    }
  },
  computed: {
    prevDisabled () {
      return this.page === 1
    },
    nextDisabled () {
      return this.page === this.pages || this.pages === 0
    }
  },
  watch: {
    current (value) {
      this.page = value
    }
  },
  methods: {
    prev () {
      if (!this.prevDisabled) {
        this.page -= 1
        this.$emit('pagination', this.page)
      }
    },
    next () {
      if (!this.nextDisabled) {
        this.page += 1
        this.$emit('pagination', this.page)
      }
    }
  }
}
</script>

<style lang="scss">
@import '../assets/scss/variables';

.ui-pagination {
  display:         flex;
  align-items:     center;
  justify-content: center;

  &__prev, &__next {
  	height:          36px;
  	width:           36px;
    background:      $white;
  	border:          1px solid transparentize($black, .9);
  	border-radius:   4px;
    display:         flex;
    align-items:     center;
    justify-content: center;
    cursor:          pointer;

    &.disabled {
      background: $grey-light;
      border:     $grey-light;
      opacity:    .5;
      cursor:     default;
    }

    i {
      color:       $grey-basic;
      font-size:   14px;
      user-select: none;
    }
  }

  &__prev i {
    transform: rotate(180deg);
  }

  &__text {
    padding:     0 40px;
    color:       $grey-basic;
    font-size:   12px;
    font-weight: 500;
    user-select: none;
  }
}
</style>
