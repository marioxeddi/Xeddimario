<template>
  <div class="ui-avatar">
    <input :id="'input-' + id" type="file" accept="image/*" @change="selectImage">

    <div class="ui-avatar__add" v-if="!src && uploadable || cropImg">
      <label v-if="!imgSrc" :for="'input-' + id" class="ui-avatar__add__image">
        <div class="ui-avatar__add__image__icon">
          <ui-icon size="16" grey-basic>edit</ui-icon>
        </div>
      </label>
      <div
        v-else
        class="ui-avatar__add__avatar"
        @click="$refs[id].open()"
        :style="{ background: 'url(' + cropImg + '), black center no-repeat' }"
      >
      </div>
      <label
        v-if="uploadable"
        :for="'input-' + id"
        class="ui-avatar__add__button"
      >
        {{ customUploadText || 'Upload Profile Picture' }}
      </label>
    </div>

    <div class="ui-avatar__hasImage" v-else>
      <div
        class="ui-avatar__hasImage__image"
        :style="{ background: 'url(' + src + '), black center no-repeat' }"
      >
      </div>
      <label
        v-if="uploadable"
        :for="'input-' + id"
        class="ui-avatar__hasImage__button"
      >
        {{ customUploadText || 'Upload Profile Picture' }}
      </label>
    </div>

    <ui-modal v-if="uploadable" :id="id" :ref="id" non-closable>
      <vue-cropper
        :ref="'cropper-' + id"
        :src="imgSrc"
        :view-mode="1"
        :min-crop-box-width="120"
        :min-crop-box-height="120"
        :auto-crop-area="1"
        :cropmove="cropImage"
        :zoomable="false"
        :style="{ maxWidth: '800px', maxHeight: 'calc(100vh - 200px)' }"
      />
      <ui-modal-actions justify-end>
        <ui-button dense outline @click.native="cancel()">Cancel</ui-button>
        <ui-button dense success @click.native="confirm()">Confirm</ui-button>
      </ui-modal-actions>
    </ui-modal>
  </div>
</template>

<script>
import VueCropper from 'vue-cropperjs'

export default {
  name: 'UiAvatar',
  components: {
    VueCropper
  },
  data () {
    return {
      loading: 0,
      name: '',
      cropImg: '',
      cropImgTemp: '',
      imgSrc: ''
    }
  },
  props: {
    id: String,
    uploadable: Boolean,
    customUploadText: String,
    src: String
  },
  watch: {
    cropImg (value) {
      this.$emit('input', value)
    }
  },
  methods: {
    selectImage (e) {
      const file = e.target.files[0]
      this.name = file.name

      if (!file || !file.type.includes('image/')) {
        return
      }

      if (typeof FileReader === 'function') {
        const reader = new FileReader()

        reader.onload = (event) => {
          this.imgSrc = event.target.result
          this.cropImgTemp = event.target.result
          this.$refs['cropper-' + this.id].replace(event.target.result)
        }

        reader.readAsDataURL(file)
      } else {
        alert('Sorry, FileReader API not supported')
      }

      this.$refs[this.id].open()
    },
    cropImage () {
      this.cropImgTemp = this.$refs['cropper-' + this.id].getCroppedCanvas().toDataURL()
    },
    cancel () {
      if (!this.cropImg) this.imgSrc = ''

      document.getElementById('input-' + this.id).value = ''

      this.$refs[this.id].close()
    },
    confirm () {
      this.cropImg = this.cropImgTemp

      document.getElementById('input-' + this.id).value = ''

      this.$refs[this.id].close()
    }
  }
}
</script>

<style lang="scss">
@import "../assets/scss/variables";
@import "../assets/scss/mixins";

.ui-avatar {
  width: 100%;
  @include media(md) {
    width: auto;
  }

  &__hasImage {
    display:         flex;
    align-items:     center;
    justify-content: space-between;
    @include media(md) {
      justify-content: flex-start;
    }

    &__image {
      width:           70px;
      height:          70px;
      background-size: cover !important;
      border-radius:   6px;
      @include media(md) {
        width:  120px;
        height: 120px;
      }
    }

    &__button {
      margin-left:   0;
      padding:       10px;
      color:         $grey-basic;
      font-size:     14px;
      font-weight:   500;
      border:        2px solid $grey-light;
      border-radius: 6px;
      cursor:        pointer;
      @include media(md) {
        margin-left: 20px;
      }
    }
  }

  &__add {
    display:         flex;
    align-items:     center;
    justify-content: space-between;
    @include media(md) {
      justify-content: flex-start;
    }

    &__image {
      width:           70px;
      height:          70px;
      background:      transparentize($grey-dark, .3);
      border-radius:   6px;
      display:         flex;
      align-items:     center;
      justify-content: center;
      cursor:          pointer;
      @include media(md) {
        width:  120px;
        height: 120px;
      }

      &__icon {
        width:           24px;
        height:          24px;
        background:      $grey-light;
        border-radius:   50%;
        display:         flex;
        align-items:     center;
        justify-content: center;
      }
    }

    &__avatar {
      width:           70px;
      height:          70px;
      background-size: cover !important;
      border-radius:   6px;
      cursor:          pointer;
      @include media(md) {
        width:  120px;
        height: 120px;
      }
    }

    &__button {
      margin-left:   0;
      padding:       10px;
      color:         $grey-basic;
      font-size:     14px;
      font-weight:   500;
      border:        2px solid $grey-light;
      border-radius: 6px;
      cursor:        pointer;
      @include media(md) {
        margin-left: 20px;
      }
    }
  }

  input[type="file"] {
    display: none;
  }
}
</style>
