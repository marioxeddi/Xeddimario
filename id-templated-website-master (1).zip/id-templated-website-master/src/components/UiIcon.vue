<template>
  <i
    class="material-icons ui-icon"
    :class="{
      'color-primary': primary,
      'grey-light': greyLight,
      'grey-basic': greyBasic,
      'grey-dark': greyDark,
      'border': border
    }"
    :style="{
      fontSize: size + 'px',
      color: customColor
    }"
  >
    <slot></slot>
  </i>
</template>

<script>
export default {
  name: 'UiIcon',
  props: {
    primary: Boolean,
    size: [ String, Number ],
    greyLight: Boolean,
    greyBasic: Boolean,
    greyDark: Boolean,
    customColor: String,
    border: Boolean
  }
}
</script>

<style lang="scss">
@import "../assets/scss/variables";

.ui-icon {
  &.grey-light {
    color: $grey-light;
  }

  &.grey-basic {
    color: $grey-basic;
  }

  &.grey-dark {
    color: $grey-dark;
  }

  &.border {
    padding:       15px;
    color:         $success;
    border:        2px solid $success;
    border-radius: 50%;
  }
}
</style>
