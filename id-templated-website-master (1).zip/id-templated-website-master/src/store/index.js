import Vue from 'vue'
import Vuex from 'vuex'

import auth from './modules/auth'
import states from './modules/states'
import anchoring from './modules/anchoring'
import loading from './modules/loading'
import boostLibrary from './modules/boostLibrary'

Vue.use(Vuex)

const store = new Vuex.Store({
  modules: {
    auth,
    states,
    anchoring,
    loading,
    boostLibrary
  },
  strict: process.env.NODE_ENV === 'development'
})

if (module.hot) {
  module.hot.accept([
    './modules/auth',
    './modules/states',
    './modules/anchoring',
    './modules/loading',
    './modules/boostLibrary'
  ], () => {
    const auth = require('./modules/auth').default
    const states = require('./modules/states').default
    const anchoring = require('./modules/anchoring').default
    const loading = require('./modules/loading').default
    const boostLibrary = require('./modules/boostLibrary').default

    store.hotUpdate({
      modules: {
        auth: auth,
        states: states,
        anchoring: anchoring,
        loading: loading,
        boostLibrary: boostLibrary
      }
    })
  })
}

export default store
