import storage from '../../plugins/localStorage'

const prefix = '_anchoring.'

const state = {
  anchor: storage.get(prefix + 'anchor') || false
}

const mutations = {
  setAnchor (state, payload) {
    state.anchor = payload

    storage.set(prefix + 'anchor', payload)
  }
}

const actions = {
  setAnchor ({ commit }, payload) {
    commit('setAnchor', payload)
  }
}

export default {
  namespaced: true,
  state,
  actions,
  mutations
}
