const state = {
  snackbar: false,
  snackbarTimeout: 4000,
  message: '',
  loading: false
}

const mutations = {
  openSnackbar (state, payload) {
    state.snackbar = true
    state.snackbarTimeout = payload
  },
  closeSnackbar (state) {
    state.snackbar = false
  },
  setMessage (state, payload) {
    state.message = payload
  }
}

const actions = {
  openSnackbar ({ commit }, payload = 4000) {
    commit('openSnackbar', payload)

    if (payload > 0) {
      setTimeout(() => {
        commit('closeSnackbar')
      }, payload)
    }
  },
  closeSnackbar ({ commit }) {
    commit('closeSnackbar')
  },
  setMessage ({ commit }, payload) {
    commit('setMessage', payload)
  }
}

export default {
  namespaced: true,
  state,
  actions,
  mutations
}
