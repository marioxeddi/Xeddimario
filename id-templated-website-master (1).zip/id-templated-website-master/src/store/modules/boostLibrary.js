import storage from '../../plugins/localStorage'

const prefix = '_boostLibrary.'

const state = {
  selectedBoostId: storage.get(prefix + 'selectedBoostId') || -1
}

const mutations = {
  setSelectedBoostId (state, payload) {
    state.selectedBoostId = payload
    storage.set(prefix + 'selectedBoostId', payload)
  },
  resetSelectedBoostId (state) {
    state.selectedBoostId = -1
    storage.set(prefix + 'selectedBoostId', -1)
  }
}

const actions = {
  setSelectedBoostId ({ commit }, payload) {
    commit('setSelectedBoostId', payload)
  },
  resetSelectedBoostId ({ commit }) {
    commit('setSelectedBoostId', -1)
  }
}

export default {
  namespaced: true,
  state,
  actions,
  mutations
}
