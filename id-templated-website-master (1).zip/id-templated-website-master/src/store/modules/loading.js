const state = {
  loading: false
}

const mutations = {
  loading (state, payload) {
    state.loading = payload
  }
}

const actions = {
  loading ({ commit }, payload) {
    commit('loading', payload)
  }
}

export default {
  namespaced: true,
  state,
  actions,
  mutations
}
