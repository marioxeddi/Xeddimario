import apollo from '../../apollo'
import gql from 'graphql-tag'
import storage from '../../plugins/localStorage'

import { assign } from 'lodash'

const prefix = '_auth.'
const loginMutation = gql`
mutation login($email: String!, $password: String!, $id: Int, $templateId: Int) {
  login(email: $email, password: $password, id: $id, templateId: $templateId) {
    id
    authToken
    isCarrier
    hasSentABoost
  }
}
`

const checkQuery = gql`
query me {
  me {
    id
    profilePhoto
    firstName
    lastName
    email
    phone
    autoSend
    hasSentABoost
  }
}
`

const state = {
  token: storage.get(prefix + 'token') || null,
  user: storage.get(prefix + 'user', true) || null
}

const mutations = {
  loginSuccess (state, payload) {
    state.token = payload.authToken
    state.user = payload

    storage.set(prefix + 'user', payload, true)
    storage.set(prefix + 'token', payload.authToken)
  },

  loginFail (state, payload) {
    state.token = state.user = null

    storage.remove(prefix + 'user')
    storage.remove(prefix + 'token')
  },

  me (state, payload) {
    const data = assign({}, state.user, payload)
    state.user = data

    storage.set(prefix + 'user', data, true)
  },

  logout (state, payload) {
    state.token = state.user = null
    apollo.resetStore()

    storage.remove(prefix + 'user')
    storage.remove(prefix + 'token')
  }
}

const actions = {
  login ({ commit }, params) {
    return new Promise((resolve, reject) => {
      apollo.mutate({
        mutation: loginMutation,
        fetchPolicy: 'network-only',
        variables: {
          ...params
        }
      }).then((response) => {
        if (response.data.login) {
          commit('loginSuccess', response.data.login)
          resolve({ success: true })

          apollo.query({
            query: checkQuery,
            fetchPolicy: 'network-only'
          }).then((response2) => {
            commit('me', response2.data.me)
          })
        } else {
          commit('loginFail')
          resolve({ success: false, error: 'login fail' })
        }
      }).catch((error) => {
        commit('loginFail')
        reject(error)
      })
    })
  },
  setUser ({ commit }, payload) {
    commit('me', payload)
  },
  logout ({ commit }) {
    commit('logout')
  },
  check ({ commit }) {
    return new Promise((resolve, reject) => {
      apollo.query({
        query: checkQuery,
        fetchPolicy: 'network-only'
      }).then((response) => {
        if (response.data.me) {
          resolve({ success: true, data: response.data.me })
          commit('me', response.data.me)
        } else {
          resolve({ success: false, data: response.data.me })
        }
      }).catch((error) => {
        reject(error)
      })
    })
  }
}

export default {
  namespaced: true,
  state,
  actions,
  mutations
}
