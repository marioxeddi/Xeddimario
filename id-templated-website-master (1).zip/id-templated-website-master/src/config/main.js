let GRAPHQL_DNS

if (process.env.NODE_ENV === 'production' && !process.env.GRAPHQL_DNS) {
  console.log('NODE_ENV is production but no GRAPHQL_DNS is set. Using default: https://graphql.insurancedrip.com')
  GRAPHQL_DNS = 'https://graphql.insurancedrip.com/api/graphql'
} else {
  GRAPHQL_DNS = 'https://staging-graphql.insurancedrip.com/api/graphql'
}

export default {
  api: {
    graphql: process.env.GRAPHQL_DNS || GRAPHQL_DNS
  }
}
