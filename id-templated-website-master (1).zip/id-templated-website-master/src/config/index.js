import main from './main.js'
import routes from './routes.js'

export default {
  main,
  routes
}
