export default [
  {
    path: '/',
    component: resolve => require(['../App.vue'], resolve),
    children: [
      {
        path: '/',
        component: resolve => require(['../layouts/AgentPortal.vue'], resolve),
        children: [
          {
            path: '/',
            component: resolve => require(['../views/agentPortal/BoostLibrary.vue'], resolve),
            name: 'landingPage',
            meta: {
              loginAvailable: true,
              auth: false
            }
          },
          {
            path: '/boostLibrary',
            component: resolve => require(['../views/agentPortal/BoostLibrary.vue'], resolve),
            name: 'boostLibrary',
            meta: {
              loginAvailable: true,
              auth: false
            }
          },
          {
            path: '/libraryBoost/:id',
            component: resolve => require(['../views/agentPortal/LibraryBoost.vue'], resolve),
            name: 'libraryBoost',
            meta: {
              loginAvailable: false,
              auth: false
            }
          },
          {
            path: '/verifyAccount/:templateId?',
            component: resolve => require(['../views/agentPortal/account/Verify.vue'], resolve),
            name: 'verifyAccount',
            meta: {
              loginAvailable: true,
              auth: false
            }
          },
          {
            path: '/createAccount/:id/:templateId?',
            component: resolve => require(['../views/agentPortal/account/Create.vue'], resolve),
            name: 'createAccount',
            meta: {
              loginAvailable: true,
              auth: false
            }
          },
          {
          //   // Add /:id paramater
            path: '/launchBoost',
            component: resolve => require(['../views/agentPortal/LaunchBoost.vue'], resolve),
            name: 'launchBoost',
            meta: {
              loginAvailable: false,
              auth: true
            }
          },
          // {
          //   path: '/onboardingBoost',
          //   component: resolve => require(['../views/agentPortal/marketingBoost/OnboardingBoost.vue'], resolve),
          //   name: 'onboardingBoost',
          //   meta: {
          //     loginAvailable: false,
          //     auth: true
          //   }
          // },
          {
            path: '/marketingBoost/:id',
            component: resolve => require(['../views/agentPortal/marketingBoost/MarketingBoost.vue'], resolve),
            name: 'marketingBoost',
            meta: {
              loginAvailable: false,
              auth: true
            }
          },
          {
            path: '/boost/:id/:sourceType?/:sourceKey?',
            component: resolve => require(['../views/agentPortal/marketingBoost/PreviewMarketingBoost.vue'], resolve),
            name: 'previewMarketingBoost',
            meta: {
              loginAvailable: false,
              auth: false
            }
          },
          {
            path: '/myBoosts',
            component: resolve => require(['../views/agentPortal/account/MyBoosts.vue'], resolve),
            name: 'myBoosts',
            meta: {
              loginAvailable: false,
              auth: true
            }
          },
          {
            path: '/myAccount',
            component: resolve => require(['../views/agentPortal/account/MyAccount.vue'], resolve),
            name: 'myAccount',
            meta: {
              loginAvailable: false,
              auth: true
            }
          },
          {
            path: '/contacts',
            component: resolve => require(['../views/agentPortal/account/Contacts.vue'], resolve),
            name: 'contacts',
            meta: {
              loginAvailable: false,
              auth: true
            }
          },
          {
            path: '/reports',
            component: resolve => require(['../views/agentPortal/account/Reports.vue'], resolve),
            name: 'reports',
            meta: {
              loginAvailable: false,
              auth: true
            }
          }
        ]
      },
      {
        path: '/',
        component: resolve => require(['../layouts/CarrierPortal.vue'], resolve),
        children: [
          {
            path: '/carrierDashboard',
            component: resolve => require(['../views/carrierPortal/Dashboard.vue'], resolve),
            name: 'carrierDashboard',
            meta: {
              loginAvailable: false,
              auth: true
            }
          },
          {
            path: '/viewMarketingBoost/:id',
            component: resolve => require(['../views/carrierPortal/marketingBoost/MarketingBoost.vue'], resolve),
            name: 'viewMarketingBoost',
            meta: {
              loginAvailable: false,
              auth: true
            }
          },
          {
            path: '/agents',
            component: resolve => require(['../views/carrierPortal/account/Agents.vue'], resolve),
            name: 'agents',
            meta: {
              loginAvailable: false,
              auth: true
            }
          },
          {
            path: '/carrierBoosts',
            component: resolve => require(['../views/carrierPortal/account/MarketingBoosts.vue'], resolve),
            name: 'carrierBoosts',
            meta: {
              loginAvailable: false,
              auth: true
            }
          },
          {
            path: '/carrierSettings',
            component: resolve => require(['../views/carrierPortal/account/Settings.vue'], resolve),
            name: 'carrierSettings',
            meta: {
              loginAvailable: false,
              auth: true
            }
          }
        ]
      },
      {
        path: '/',
        component: resolve => require(['../layouts/Auth.vue'], resolve),
        children: [
          {
            path: '/login',
            component: resolve => require(['../views/auth/Login.vue'], resolve),
            name: 'login',
            meta: {
              loginAvailable: false,
              auth: false
            }
          },
          {
            path: '/resetPassword/:userId/:token',
            component: resolve => require(['../views/auth/ResetPassword.vue'], resolve),
            name: 'resetPassword',
            meta: {
              loginAvailable: true,
              auth: false
            }
          }
        ]
      },
      {
        path: '/logout',
        component: resolve => require(['../views/auth/Logout.vue'], resolve),
        name: 'logout'
      },
      {
        path: '/syncHandler/:redirectURL/:type',
        component: resolve => require(['../views/agentPortal/account/SyncHandler.vue'], resolve),
        name: 'LinkAccountSyncHandler'
      }
    ]
  }
]
