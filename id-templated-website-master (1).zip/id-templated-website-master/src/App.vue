<template>
  <router-view></router-view>
</template>

<script>
import gql from 'graphql-tag'

export default {
  name: 'App',
  data () {
    return {
      loading: 0,
      carrierSettings: {}
    }
  },
  apollo: {
    carrierSettings: {
      query: gql`
      query carrierSettings {
        carrierSettings {
          logo
          themeColor {
            r
            g
            b
          }
        }
      }
      `,
      variables () {
        return {
          id: 2438
        }
      },
      loadingKey: 'loading'
    }
  },
  watch: {
    loading (value) {
      if (value < 1) {
        const rgb = `${this.carrierSettings.themeColor.r},${this.carrierSettings.themeColor.g},${this.carrierSettings.themeColor.b}`

        const css = `
        main.gradient { background: linear-gradient(to bottom, rgba(255,255,255,1), rgba(${rgb},.1)); }
        main.solid { background: rgba(${rgb},.1); }
        .background-primary { background: rgb(${rgb})!important; }
        .color-primary { color: rgb(${rgb})!important; }
        `
        const head = document.head || document.getElementsByTagName('head')[0]
        const style = document.createElement('style')

        style.type = 'text/css'
        if (style.styleSheet) {
          style.styleSheet.cssText = css
        } else {
          style.appendChild(document.createTextNode(css))
        }

        head.appendChild(style)
      }
    }
  }
}
</script>
