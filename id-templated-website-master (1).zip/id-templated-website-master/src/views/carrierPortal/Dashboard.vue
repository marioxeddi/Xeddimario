<template>
  <div v-if="loading < 1">
    <ui-layout justify-center wrap>
      <ui-layout class="col-xs-12 col-md-4" :style="{ margin: '0 auto' }">
        <ui-card header="Top 10 Tags" fluid>
          <ui-layout class="col-xs-12">
            <table>
              <thead>
                <th align="left">Name</th>
                <th align="right">Clicks</th>
              </thead>
              <tr v-for="tag in carrierDashboard.topTenTags" :key="tag.tag.text">
                <td align="left">
                  <div :style="{ background: `rgb(${tag.tag.color.r},${tag.tag.color.g},${tag.tag.color.b})` }"></div>
                  <span>{{ tag.tag.text }}</span>
                </td>
                <td align="right">
                  <span>{{ tag.clicks }}</span>
                </td>
              </tr>
            </table>
          </ui-layout>
        </ui-card>
      </ui-layout>
      <!-- <ui-layout class="col-xs-12 col-md-6">
        <ui-card header="Boost Engagement" fluid class="carrierEngagement">
          <ui-layout class="col-xs-12">
            <ui-line-chart
              :data="stats.engagement.data"
              :options="stats.engagement.options"
            />
          </ui-layout>
        </ui-card>
      </ui-layout> -->
      <!-- <ui-layout class="col-xs-12 col-md-9" wrap :style="{ padding: '0' }">
        <ui-header font-weight="300" font-size="26" top="50">
          Marketing Boosts Data
        </ui-header>
        <ui-subheader
          class="color-grey-dark"
          align-center
        >
          Your Marketing Boost reports and analytics will be available seven days after you send your first marketing boost.
        </ui-subheader>
      </ui-layout> -->
      <ui-layout class="col-xs-12">
        <ui-subheader
          class="color-grey-dark"
          font-size="18"
          font-weight="500"
          top="10"
          bottom="20"
          :style="{ padding: '0' }"
        >
          Top 3 Boosts
        </ui-subheader>
      </ui-layout>
      <ui-layout wrap class="col-xs-12" :style="{ padding: '0' }">
        <ui-layout
          v-for="boost in carrierDashboard.topThreeBoosts"
          :key="boost.id"
          class="col-xs-12 col-md-4"
        >
          <ui-mini-boost-card
            :tags="boost.tags"
            :date="boost.date"
            :coverImage="boost.coverImage"
            :completed="boost.sent"
            :header="boost.title"
            :content="boost.summary"
            :sends="boost.sends"
            :opens="boost.opens"
            :clicks="boost.clicks"
            @click.native="$router.push({ name: 'viewMarketingBoost', params: { id: boost.id } })"
          />
        </ui-layout>
      </ui-layout>
      <ui-layout wrap class="col-xs-12" :style="{ padding: '0' }">
        <ui-layout class="col-xs-12 col-md-6">
          <ui-card header="Social Media Channels Clicks" fluid>
            <ui-doughnut-chart
              :data="stats.socialMedia.clicks"
              :options="stats.socialMedia.clicks.options"
            />
          </ui-card>
        </ui-layout>
        <ui-layout class="col-xs-12 col-md-6">
          <ui-card header="Social Media Channels Leads" fluid>
            <ui-doughnut-chart
              :data="stats.socialMedia.leads"
              :options="stats.socialMedia.leads.options"
            />
          </ui-card>
        </ui-layout>
        <ui-layout class="col-xs-12 col-md-6">
          <ui-card header="Email Channels Leads" fluid>
            <ui-doughnut-chart
              :data="stats.emailChannel.leads"
              :options="stats.emailChannel.leads.options"
            />
          </ui-card>
        </ui-layout>
        <ui-layout class="col-xs-12 col-md-6">
          <ui-card header="Email Channels Clicks" fluid>
            <ui-doughnut-chart
              :data="stats.emailChannel.clicks"
              :options="stats.emailChannel.clicks.options"
            />
          </ui-card>
        </ui-layout>
        <ui-layout class="col-xs-12 col-md-6">
          <ui-card header="Email Channels Opens" fluid>
            <ui-doughnut-chart
              :data="stats.emailChannel.opens"
              :options="stats.emailChannel.opens.options"
            />
          </ui-card>
        </ui-layout>
        <ui-layout class="col-xs-12 col-md-6">
          <ui-card header="Email Channels Sends" fluid>
            <ui-doughnut-chart
              :data="stats.emailChannel.sends"
              :options="stats.emailChannel.sends.options"
            />
          </ui-card>
        </ui-layout>

        <ui-layout class="col-xs-12">
          <ui-card header="Engagement" fluid>
            <ui-line-chart
              :data="stats.monthStats.clicks"
              :options="stats.monthStats.clicks.options"
              :height="200"
            />
          </ui-card>
        </ui-layout>

      </ui-layout>
    </ui-layout>
  </div>
</template>

<script>
import gql from 'graphql-tag'

export default {
  name: 'CarrierDashboard',
  data () {
    return {
      loading: 0,
      carrierDashboard: {},
      stats: {
        socialMedia: {},
        emailChannel: {},
        monthStats: {}
      }
    }
  },
  apollo: {
    carrierDashboard: {
      query: gql`
      query carrierDashboard {
        carrierDashboard {
          topTenTags {
            sends
            clicks
            opens
            leads
            tag {
              text
              color {
                r
                g
                b
              }
            }
          }
          topThreeBoosts {
            id
            coverImage
            title
            summary
            date
            sent
            sends
            opens
            clicks
            tags {
              text
              color {
                r
                g
                b
              }
            }
          }
          boostStats {
            contactSourceStats {
              sends
              clicks
              opens
              leads
              sourceType
            }
            socialMediaStats {
              clicks
              leads
              socialNetworkType
            }
            monthStats {
              month
              year
              dateDisplay
              clicksByEmailSources
              clicksBySocialMediaSources
              clicksByOtherSources
            }
          }
        }
      }
      `,
      result ({ data }) {
        this.socialMediaClicks(data)
        this.socialMediaLeads(data)
        this.emailChannelLeads(data)
        this.emailChannelClicks(data)
        this.emailChannelOpens(data)
        this.emailChannelSends(data)
        this.monthStats(data)
      },
      loadingKey: 'loading'
    }
  },
  watch: {
    loading (value) {
      if (value !== 0) {
        this.$store.dispatch('loading/loading', true)
      } else {
        this.$store.dispatch('loading/loading', false)
      }
    }
  },
  methods: {
    getChannelTypeBackgroundColor (channelType) {
      if (channelType === 'Facebook') {
        return '#4460A0'
      }

      if (channelType === 'LinkedIn') {
        return '#007EBB'
      }

      if (channelType === 'LinkedIn') {
        return '#007EBB'
      }

      if (channelType === 'Google+') {
        return '#F93F2D'
      }

      if (channelType === 'Twitter') {
        return '#00AAEC'
      }

      if (channelType === 'Gmail') {
        return '#AC3D31'
      }

      if (channelType === 'Yahoo') {
        return '#6B0094'
      }

      if (channelType === 'Outlook' || channelType === 'MSN') {
        return '#0072C6'
      }

      if (channelType === 'AOL') {
        return '#2D3140'
      }

      if (channelType === 'iCloud') {
        return '#BD10E0'
      }

      if (channelType === 'Other') {
        return '#878787'
      }

      return '#000000'
    },
    socialMediaClicks (data) {
      const statsViaSocialData = {
        labels: [],
        datasets: [
          {
            backgroundColor: [],
            data: []
          }
        ]
      }

      data.carrierDashboard.boostStats.socialMediaStats.forEach((element) => {
        statsViaSocialData.labels.push(element.socialNetworkType)
        statsViaSocialData.datasets[0].data.push(element.clicks)
        statsViaSocialData.datasets[0].backgroundColor.push(this.getChannelTypeBackgroundColor(element.socialNetworkType))
      })

      this.stats.socialMedia.clicks = statsViaSocialData
    },
    socialMediaLeads (data) {
      const statsViaSocialData = {
        labels: [],
        datasets: [
          {
            backgroundColor: [],
            data: []
          }
        ]
      }

      data.carrierDashboard.boostStats.socialMediaStats.forEach((element) => {
        statsViaSocialData.labels.push(element.socialNetworkType)
        statsViaSocialData.datasets[0].data.push(element.leads)
        statsViaSocialData.datasets[0].backgroundColor.push(this.getChannelTypeBackgroundColor(element.socialNetworkType))
      })

      this.stats.socialMedia.leads = statsViaSocialData
    },
    emailChannelLeads (data) {
      const statsViaEmailData = {
        labels: [],
        datasets: [
          {
            backgroundColor: [],
            data: []
          }
        ]
      }

      data.carrierDashboard.boostStats.contactSourceStats.forEach((element) => {
        statsViaEmailData.labels.push(element.sourceType)
        statsViaEmailData.datasets[0].data.push(element.leads)
        statsViaEmailData.datasets[0].backgroundColor.push(this.getChannelTypeBackgroundColor(element.sourceType))
      })

      this.stats.emailChannel.leads = statsViaEmailData
    },
    emailChannelClicks (data) {
      const statsViaEmailData = {
        labels: [],
        datasets: [
          {
            backgroundColor: [],
            data: []
          }
        ]
      }

      data.carrierDashboard.boostStats.contactSourceStats.forEach((element) => {
        statsViaEmailData.labels.push(element.sourceType)
        statsViaEmailData.datasets[0].data.push(element.clicks)
        statsViaEmailData.datasets[0].backgroundColor.push(this.getChannelTypeBackgroundColor(element.sourceType))
      })

      this.stats.emailChannel.clicks = statsViaEmailData
    },
    emailChannelOpens (data) {
      const statsViaEmailData = {
        labels: [],
        datasets: [
          {
            backgroundColor: [],
            data: []
          }
        ]
      }

      data.carrierDashboard.boostStats.contactSourceStats.forEach((element) => {
        statsViaEmailData.labels.push(element.sourceType)
        statsViaEmailData.datasets[0].data.push(element.opens)
        statsViaEmailData.datasets[0].backgroundColor.push(this.getChannelTypeBackgroundColor(element.sourceType))
      })

      this.stats.emailChannel.opens = statsViaEmailData
    },
    emailChannelSends (data) {
      const statsViaEmailData = {
        labels: [],
        datasets: [
          {
            backgroundColor: [],
            data: []
          }
        ]
      }

      data.carrierDashboard.boostStats.contactSourceStats.forEach((element) => {
        statsViaEmailData.labels.push(element.sourceType)
        statsViaEmailData.datasets[0].data.push(element.sends)
        statsViaEmailData.datasets[0].backgroundColor.push(this.getChannelTypeBackgroundColor(element.sourceType))
      })

      this.stats.emailChannel.sends = statsViaEmailData
    },
    monthStats (data) {
      const monthStatsData = {
        labels: [],
        datasets: [
          {
            label: 'Email',
            fill: false,
            backgroundColor: '#F93F2D',
            borderColor: '#F93F2D',
            data: []
          },
          {
            label: 'Social Media',
            fill: false,
            backgroundColor: '#0072C6',
            borderColor: '#0072C6',
            data: []
          },
          {
            label: 'Organic',
            fill: false,
            backgroundColor: '#ffcc00',
            borderColor: '#ffcc00',
            data: []
          }
        ]
      }

      data.carrierDashboard.boostStats.monthStats.forEach((element) => {
        monthStatsData.labels.push(element.dateDisplay)
        monthStatsData.datasets[0].data.push(element.clicksByEmailSources)
        monthStatsData.datasets[1].data.push(element.clicksBySocialMediaSources)
        monthStatsData.datasets[2].data.push(element.clicksByOtherSources)
      })

      this.stats.monthStats.clicks = monthStatsData
    }
  }
}
</script>

<style lang="scss">
.carrierEngagement .ui-card__content {
  overflow-x: auto;
}
</style>

<style lang="scss" scoped>
@import "../../assets/scss/variables";
@import "../../assets/scss/mixins";

.ui-card, .ui-mini-boost-card {
  margin-bottom: 20px;
}

.ui-subheader {
  text-align: center;
  @include media(md) {
    text-align: left;
  }
}

table {
  width: 100%;

  th {
    padding-bottom: 20px;
  	color:          $grey-basic;
  	font-size:      12px;
  	font-weight:    500;
  	line-height:    12px;
    opacity:        0.8;
  }

  td {
    padding-bottom: 5px;

    div {
    	height:         14px;
    	width:          14px;
      margin-right:   8px;
    	border-radius:  2px;
      vertical-align: middle;
      display:        inline-block;
    }

    span {
    	color:          $grey-dark;
    	font-size:      14px;
      vertical-align: middle;
      display:        inline-block;
    }
  }
}
</style>
