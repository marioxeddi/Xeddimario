<template>
  <div :style="{ width: '100%', minHeight: 'calc(100vh - 260px)' }">
    <ui-layout :style="{ padding: '0' }" wrap>
      <ui-layout
        v-for="boost in boosts.data"
        :key="boost.id"
        class="col-xs-12 col-sm-6 col-md-4"
      >
        <ui-mini-boost-card
          :tags="boost.tags"
          :date="boost.date"
          :coverImage="boost.coverImage"
          :completed="boost.sent"
          :header="boost.title"
          :content="boost.summary"
          :sends="boost.sends"
          :opens="boost.opens"
          :clicks="boost.clicks"
          @click.native="$router.push({ name: 'viewMarketingBoost', params: { id: boost.id } })"
          :style="{ marginBottom: '30px' }"
        />
      </ui-layout>
    </ui-layout>
    <ui-layout v-if="loading < 1" justify-center>
      <ui-pagination
        :current="pagination.page"
        :pages="pages"
        @pagination="changePage"
      />
    </ui-layout>
  </div>
</template>

<script>
import gql from 'graphql-tag'

export default {
  name: 'CarrierMarketingBoosts',
  data () {
    return {
      loading: 0,
      boosts: [],
      pagination: {
        page: 1,
        offset: 0,
        countPerPage: 9
      }
    }
  },
  apollo: {
    boosts: {
      query: gql`
      query getBoosts($offset: Int!, $countPerPage: Int!) {
        getBoosts(offset: $offset, countPerPage: $countPerPage) {
          totalCount
          data {
            id
            coverImage
            title
            summary
            date
            sent
            sends
            opens
            clicks
            tags {
              text
              color {
                r
                g
                b
              }
            }
          }
        }
      }
      `,
      variables () {
        return {
          offset: this.pagination.offset,
          countPerPage: this.pagination.countPerPage
        }
      },
      update: (response) => response.getBoosts,
      loadingKey: 'loading'
    }
  },
  computed: {
    pages () {
      const count = this.boosts.totalCount / this.pagination.countPerPage

      return count <= 1 ? 1 : Math.ceil(count)
    }
  },
  watch: {
    loading (value) {
      if (value !== 0) {
        this.$store.dispatch('loading/loading', true)
      } else {
        this.$store.dispatch('loading/loading', false)
      }
    }
  },
  methods: {
    changePage (page) {
      this.pagination.page = page
      this.pagination.offset = (page - 1) * this.pagination.countPerPage
    }
  }
}
</script>

<style lang="scss">
</style>
