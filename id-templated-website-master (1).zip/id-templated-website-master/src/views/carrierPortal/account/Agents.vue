<template>
  <div v-if="loading < 1" :style="{ width: '100%', minHeight: 'calc(100vh - 260px)' }">
    <div class="agentsHeader">
      <div
        v-for="item in agentsHeader"
        :key="item.name"
        class="agentsHeader__item"
      >
        <div
          class="agentsHeader__item__icon"
          :style="{ background: `rgba(${item.color.r},${item.color.g},${item.color.b},.2)` }"
        >
          <ui-icon :style="{ color: `rgb(${item.color.r},${item.color.g},${item.color.b})` }">
            {{ item.icon }}
          </ui-icon>
        </div>
        <div class="agentsHeader__item__content">
          <div class="agentsHeader__item__content__name">
            {{ item.name }}
          </div>
          <div class="agentsHeader__item__content__count">
            {{ count(item.name) }}
          </div>
        </div>
      </div>
    </div>
    <ui-card fluid>
      <ui-table
        card-table
        searchable
        deletable
        pagination
        custom-delete="Deactivate"
        custom-delete-icon="close"
        :offset="pagination.offset"
        :countPerPage="pagination.countPerPage"
        :totalCount="agentsTable.totalCount"
        :fields="agentsTableFields"
        :data="agentsTable.data"
        :search-query="searchQuery"
        :sorting="sorting"
        @search="searchQuery = $event"
        @sort="sorting = $event"
        @delete="deleteRows"
        @changeCountPerPage="pagination.countPerPage = $event"
        @prev="pagination.offset = $event"
        @next="pagination.offset = $event"
      />
    </ui-card>

    <ui-modal id="state" ref="state">
      <ui-icon border>check</ui-icon>
      <ui-subheader
        font-size="18"
        font-weight="500"
        top="30"
        bottom="10"
        class="color-grey-dark"
      >
        {{ message }}
      </ui-subheader>
      <ui-modal-actions justify-center>
        <ui-button outline @click.native="$refs.state.close()">
          Close
        </ui-button>
      </ui-modal-actions>
    </ui-modal>
  </div>
</template>

<script>
import gql from 'graphql-tag'

export default {
  name: 'CarrierAgents',
  data () {
    return {
      loading: 0,
      message: '',
      searchQuery: '',
      aggregateCounts: {},
      agentsTable: {},
      agentsTableFields: [
        {
          name: 'firstName',
          header: 'First Name'
        },
        {
          name: 'lastName',
          header: 'Last Name'
        },
        {
          name: 'email',
          header: 'E-mail Address'
        },
        {
          name: 'phone',
          header: 'Phone Number'
        },
        {
          name: 'sends',
          header: 'E-mail Sends'
        },
        {
          name: 'posts',
          header: 'SM Posts'
        }
      ],
      agentsHeader: [
        {
          icon: 'group',
          name: 'Agents',
          color: {
            r: '3',
            g: '87',
            b: '134'
          }
        },
        {
          icon: 'contact_phone',
          name: 'Contacts',
          color: {
            r: '125',
            g: '200',
            b: '85'
          }
        }
      ],
      pagination: {
        offset: 0,
        countPerPage: 50
      },
      sorting: {
        column: 'name',
        isSortDesc: true
      }
    }
  },
  apollo: {
    aggregateCounts: {
      query: gql`
      query getCarrierAggregateCounts {
        getCarrierAggregateCounts {
          totalAgentsCount
          totalContactsCount
        }
      }
      `,
      update: (response) => response.getCarrierAggregateCounts,
      loadingKey: 'loading'
    },
    agentsTable: {
      query: gql`
      query getAgents(
        $offset: Int!
        $countPerPage: Int!
        $sortColumn: String
        $isSortDesc: Boolean
        $search: String
      ) {
        getAgents(
          offset: $offset
          countPerPage: $countPerPage
          sortColumn: $sortColumn
          isSortDesc: $isSortDesc
          search: $search
        ) {
          totalCount
          data {
            id
            firstName
            lastName
            email
            phone
            isActive
            sends
            posts
          }
        }
      }
      `,
      variables () {
        return {
          offset: this.pagination.offset,
          countPerPage: this.pagination.countPerPage,
          sortColumn: this.sorting.column,
          isSortDesc: this.sorting.isSortDesc,
          search: this.searchQuery
        }
      },
      update: (response) => response.getAgents,
      loadingKey: 'loading'
    }
  },
  watch: {
    loading (value) {
      if (value !== 0) {
        this.$store.dispatch('loading/loading', true)
      } else {
        this.$store.dispatch('loading/loading', false)
      }
    }
  },
  methods: {
    count (type) {
      switch (type) {
        case 'Contacts':
          return this.aggregateCounts.totalContactsCount
        case 'Agents':
          return this.aggregateCounts.totalAgentsCount
      }
    },
    deleteRows (rows) {
      this.$store.dispatch('loading/loading', true)

      this.$apollo.mutate({
        mutation: gql`
        mutation deactivateAccount($ids: [Int]!) {
          deactivateAccount(ids: $ids) {
            isSuccessful
          }
        }
        `,
        variables: {
          ids: rows
        },
        refetchQueries: [
          {
            query: gql`
            query getAgents(
              $offset: Int!
              $countPerPage: Int!
              $sortColumn: String
              $isSortDesc: Boolean
              $search: String
            ) {
              getAgents(
                offset: $offset
                countPerPage: $countPerPage
                sortColumn: $sortColumn
                isSortDesc: $isSortDesc
                search: $search
              ) {
                totalCount
                data {
                  id
                  firstName
                  lastName
                  email
                  phone
                  isActive
                  sends
                  posts
                }
              }
            }
            `,
            variables: {
              offset: this.pagination.offset,
              countPerPage: this.pagination.countPerPage,
              sortColumn: this.sorting.column,
              isSortDesc: this.sorting.isSortDesc,
              search: this.searchQuery
            }
          }
        ]
      }).then((response) => {
        this.$store.dispatch('loading/loading', false)
        this.message = 'Selected agents have been deactivated'
        this.$refs.state.open()
      }).catch((response) => {
        this.$store.dispatch('loading/loading', false)
        this.$store.dispatch('states/setMessage', response.graphQLErrors[0].message)
        this.$store.dispatch('states/openSnackbar')
      })
    }
  }
}
</script>

<style lang="scss">
@import "../../../assets/scss/variables";
@import "../../../assets/scss/mixins";

.agentsHeader {
  width:           100%;
  margin-bottom:   20px;
  padding:         40px 30px;
  background:      $white;
  box-shadow:      1px 2px 3px 0 transparentize($black, .9);
  display:         flex;
  justify-content: space-around;
  @include media(md) {
    margin-bottom: 30px;
    border-radius: 6px;
  }

  &__item {
    display:     flex;
    align-items: center;

    &__icon {
      width:         40px;
      height:        40px;
      margin-right:  20px;
      border-radius: 50%;
      display:       none;
      @include media(sm) {
        display:         flex;
        align-items:     center;
        justify-content: center;
      }
    }

    &__content {
      &__name {
        margin-bottom: 5px;
      	color:         $grey-basic;
      	font-size:     14px;
      }

      &__count {
      	color:       $grey-dark;
      	font-size:   26px;
      	font-weight: 300;
      }
    }
  }
}

#state {
  .ui-modal__content {
    margin:         20px;
    display:        flex;
    flex-direction: column;
    align-items:    center;
  }
}
</style>
