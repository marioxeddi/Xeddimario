<template>
  <div :style="{ width: '100%', minHeight: 'calc(100vh - 260px)' }">
    <ui-card fluid header="My Account">
      <ui-layout wrap :style="{ maxWidth: 'calc(100% + 80px)', margin: '0 -40px' }">
        <ui-layout class="col-xs-8 col-md-6" :style="{ padding: '0 50px' }">
          <ui-avatar
            uploadable
            id="carrierLogo"
            v-model="imageToUpload"
            customUploadText="Upload Logo"
            :src="carrierSettings.logo"
          />
        </ui-layout>
        <ui-layout class="col-xs-4 col-md-6" :style="{ padding: '0 50px' }">
          <ui-color-picker
            id="carrierColor"
            :value="carrierSettings.themeColor"
            @selected="newColor = $event"
          />
        </ui-layout>
        <ui-layout
          column
          class="col-xs-12 col-md-6"
          :style="{ padding: '30px 50px' }"
        >
          <ui-input
            fluid
            validation
            label="E-mail"
            v-model="email"
            :valid="validation.email"
          />
          <ui-form-header>Change Password</ui-form-header>
          <ui-input
            fluid
            validation
            type="password"
            label="New password"
            tooltip="Use at least 8 characters. Don’t use a password from another site, or something too obvious like your pet’s name."
            v-model="password"
            :valid="validation.password"
          />
          <ui-input
            fluid
            validation
            type="password"
            label="Confirm new password"
            v-model="confirmPassword"
            :valid="validation.confirmPassword"
          />
        </ui-layout>
      </ui-layout>
      <ui-layout justify-end class="col-xs-12" :style="{ marginTop: '40px' }">
        <ui-button @click.native="save()" success>Save Changes</ui-button>
      </ui-layout>
    </ui-card>

    <ui-modal id="saveSuccess" ref="saveSuccess">
      <ui-icon border>check</ui-icon>
      <ui-subheader
        font-size="16"
        font-weight="700"
        top="30"
        bottom="10"
        class="color-grey-dark"
      >
        Success
      </ui-subheader>
      <p>Changes to your settings have been saved.</p>
      <ui-modal-actions justify-center>
        <ui-button outline @click.native="$refs.saveSuccess.close()">
          Close
        </ui-button>
      </ui-modal-actions>
    </ui-modal>
  </div>
</template>

<script>
import gql from 'graphql-tag'
import * as axios from 'axios'

export default {
  name: 'CarrierSettings',
  data () {
    return {
      carrierSettings: {},
      imageToUpload: null,
      uploadedImage: null,
      email: this.$store.state.auth.user.email,
      password: '',
      confirmPassword: '',
      newColor: {
        r: null,
        g: null,
        b: null
      },
      validation: {
        email: true,
        password: true,
        confirmPassword: true
      }
    }
  },
  apollo: {
    carrierSettings: {
      query: gql`
      query carrierSettings {
        carrierSettings {
          logo
          themeColor {
            r
            g
            b
          }
        }
      }
      `
    }
  },
  watch: {
    loading (value) {
      if (value !== 0) {
        this.$store.dispatch('loading/loading', true)
      } else {
        this.$store.dispatch('loading/loading', false)
      }
    },
    email (value) {
      const regexp = new RegExp('^([a-zA-Z0-9-_.+]+)@((?!aol|yahoo)(([a-zA-Z0-9-]+)+))[.]([a-zA-Z]{2,4}|[0-9]{1,3})$')

      this.validation.email = regexp.test(value)
    },
    password (value) {
      this.validation.password = value.length >= 8
      this.validation.confirmPassword = this.confirmPassword === value
    },
    confirmPassword (value) {
      if (!this.password) {
        this.validation.password = false
        this.validation.confirmPassword = false
      } else if (value === this.password) {
        this.validation.confirmPassword = true
      } else {
        this.validation.confirmPassword = false
      }
    }
  },
  methods: {
    save () {
      if (this.validation.email && this.validation.password && this.validation.confirmPassword) {
        if (this.imageToUpload) {
          this.uploadPhoto()
        } else {
          this.editAccount()
        }
      } else {
        this.$store.dispatch('states/setMessage', 'Credentials are invalid, please enter valid credentials.')
        this.$store.dispatch('states/openSnackbar')
      }
    },
    uploadPhoto () {
      this.$store.dispatch('loading/loading', true)

      this.$apollo.query({
        query: gql`
        query requestFileUploadToken {
          requestFileUploadToken {
            postUrl
          }
        }
        `
      }).then((response) => {
        this.$store.dispatch('loading/loading', false)

        const url = response.data.requestFileUploadToken.postUrl
        axios.post(url, { imageData: this.imageToUpload }).then((response2) => {
          this.uploadedImage = response2.data.getUrl
          this.editAccount()
        }).catch(() => {
          this.$store.dispatch('loading/loading', false)
          this.$store.dispatch('states/setMessage', 'The image upload failed. Please try repeating the action.')
          this.$store.dispatch('states/openSnackbar')
        })
      }).catch((response) => {
        this.$store.dispatch('loading/loading', false)
        this.$store.dispatch('states/setMessage', response.graphQLErrors[0].message)
        this.$store.dispatch('states/openSnackbar')
      })
    },
    editAccount () {
      this.$store.dispatch('loading/loading', true)

      this.$apollo.mutate({
        mutation: gql`
        mutation editCarrierAccount(
          $logo: String
          $email: String!
          $themeColorR: Int
          $themeColorG: Int
          $themeColorB: Int
          $password: String
          $confirmPassword: String
        ) {
          editCarrierAccount (
            logo: $logo
            email: $email
            themeColorR: $themeColorR
            themeColorG: $themeColorG
            themeColorB: $themeColorB
            password: $password
            confirmPassword: $confirmPassword
          ) {
            id
            email
          }
        }
        `,
        variables: {
          logo: this.uploadedImage,
          email: this.email,
          themeColorR: this.newColor.r,
          themeColorG: this.newColor.g,
          themeColorB: this.newColor.b,
          password: this.password,
          confirmPassword: this.confirmPassword
        }
      }).then((response) => {
        this.$store.dispatch('loading/loading', false)
        window.location.reload()
      }).catch((response) => {
        this.$store.dispatch('loading/loading', false)
        this.$store.dispatch('states/setMessage', response.graphQLErrors[0].message)
        this.$store.dispatch('states/openSnackbar')
      })
    }
  }
}
</script>

<style lang="scss">
@import "../../../assets/scss/variables";

#saveSuccess {
  .ui-modal__content {
    margin:         20px;
    display:        flex;
    flex-direction: column;
    align-items:    center;
  }

  p {
    max-width:   360px;
    margin:      0;
    color:       $grey-basic;
    font-size:   16px;
    font-weight: 400;
    line-height: 24px;
    text-align:  center;
  }
}
</style>
