<template>
  <ui-layout container justify-center wrap>
    <ui-layout class="resetPassword col-xs-12 col-md-8 col-lg-4">
      <ui-card header="Change Your Password" fluid unresponsive-style>
        <ui-layout wrap>
          <ui-layout class="col-xs-12">
            <ui-input
              v-model="password"
              type="password"
              label="New password"
              tooltip="Use at least 8 characters. Don’t use a password from another site, or something too obvious like your pet’s name."
              fluid
              validation
              :valid="validation.password"
            />
          </ui-layout>
          <ui-layout class="col-xs-12">
            <ui-input
              v-model="confirmPassword"
              type="password"
              label="Confirm password"
              fluid
              validation
              :valid="validation.confirmPassword"
            />
          </ui-layout>
          <ui-layout class="col-xs-12" :style="{ marginTop: '20px' }">
            <ui-button @click.native="confirm()" success fluid>Change Password</ui-button>
          </ui-layout>
        </ui-layout>
      </ui-card>
    </ui-layout>

    <ui-modal id="resetSuccess" ref="resetSuccess">
      <ui-icon border>check</ui-icon>
      <ui-subheader
        font-size="16"
        font-weight="700"
        top="30"
        bottom="10"
        class="color-grey-dark"
      >
        Success
      </ui-subheader>
      <p>Your password had been reset.</p>
      <ui-modal-actions justify-center>
        <ui-button success @click.native="$router.push({ name: 'login' })">
          Okay
        </ui-button>
      </ui-modal-actions>
    </ui-modal>
  </ui-layout>
</template>

<script>
import gql from 'graphql-tag'

export default {
  name: 'ResetPassword',
  data () {
    return {
      password: '',
      confirmPassword: '',
      validation: {
        password: false,
        confirmPassword: false
      }
    }
  },
  watch: {
    password (value) {
      this.validation.password = value.length >= 8
      this.validation.confirmPassword = this.confirmPassword === value
    },
    confirmPassword (value) {
      if (!this.password) {
        this.validation.password = false
        this.validation.confirmPassword = false
      } else if (value === this.password) {
        this.validation.confirmPassword = true
      } else {
        this.validation.confirmPassword = false
      }
    }
  },
  methods: {
    confirm () {
      this.$store.dispatch('loading/loading', true)

      if (this.validation.password && this.validation.confirmPassword) {
        this.$apollo.mutate({
          mutation: gql`
          mutation resetPassword(
            $token: String!
            $password: String!
            $confirmPassword: String!
            $id: Int!
          ) {
            resetPassword(
              token: $token
              password: $password
              confirmPassword: $confirmPassword
              id: $id
            ) {
              id
            }
          }
          `,
          variables: {
            token: this.$route.params.token,
            password: this.password,
            confirmPassword: this.confirmPassword,
            id: this.$route.params.userId
          }
        }).then((response) => {
          this.$store.dispatch('loading/loading', false)
          this.$refs.resetSuccess.open()
        }).catch((response) => {
          this.$store.dispatch('loading/loading', false)
          this.$store.dispatch('states/setMessage', response.graphQLErrors[0].message)
          this.$store.dispatch('states/openSnackbar')
        })
      } else {
        this.$store.dispatch('loading/loading', false)
        this.$store.dispatch('states/setMessage', 'Credentials are invalid, please enter valid credentials.')
        this.$store.dispatch('states/openSnackbar')
      }
    }
  }
}
</script>

<style lang="scss">
@import "../../assets/scss/mixins";

.resetPassword {
  padding: 0 20px !important;

  @include media(lg) {
    padding: 0 10px;
  }
}

#resetSuccess {
  .ui-modal__content {
    margin:         20px;
    display:        flex;
    flex-direction: column;
    align-items:    center;
  }

  p {
    max-width:   360px;
    margin:      0;
    color:       $grey-basic;
    font-size:   16px;
    font-weight: 400;
    line-height: 24px;
    text-align:  center;
  }
}
</style>
