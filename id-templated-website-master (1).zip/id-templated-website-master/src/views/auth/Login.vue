<template>
  <ui-layout container justify-center wrap>
    <ui-layout class="login col-xs-12 col-md-8 col-lg-4">
      <ui-card header="Login to Your Account" fluid unresponsive-style>
        <ui-layout wrap>
          <ui-layout class="col-xs-12">
            <ui-input v-model="login.email" label="E-mail" fluid/>
          </ui-layout>
          <ui-layout class="col-xs-12">
            <ui-input v-model="login.password" label="Password" type="password" fluid />
          </ui-layout>
          <ui-layout
            class="col-xs-12"
            justify-space-between
            wrap
            :style="{ marginBottom: '20px' }"
          >
            <ui-checkbox v-model="remember" label="Remember me" id="agentLoginCheckbox" />
            <button class="forgotPassword" @click="$refs.requestPasswordReset.open()">
              I forgot my password
            </button>
          </ui-layout>
          <ui-layout class="col-xs-12">
            <ui-button dense success fluid @click.native="auth()">
              Log in
            </ui-button>
          </ui-layout>
          <ui-layout class="col-xs-12">
            <button class="signUp" @click="$router.push({ name: 'verifyAccount' })">
              Create Account
            </button>
          </ui-layout>
        </ui-layout>
      </ui-card>
    </ui-layout>

    <ui-modal id="requestPasswordReset" ref="requestPasswordReset">
      <ui-subheader
        font-size="18"
        font-weight="700"
        class="color-grey-dark"
        align-left
        :style="{ padding: '0' }"
      >
        Forgot Password?
      </ui-subheader>
      <p>
        Please enter your email and we will send you a link to change your password to your address.
      </p>
      <ui-input
        v-model="resetPasswordEmail"
        label="E-mail"
        :style="{ marginBottom: '40px' }"
        fluid
      />
      <ui-button success @click.native="sendResetPasswordEmail()">
        Reset Password
      </ui-button>
    </ui-modal>

    <ui-modal id="passwordResetEmailSent" ref="passwordResetEmailSent">
      <ui-icon border>check</ui-icon>
      <ui-subheader
        bottom="40"
        font-size="18"
        font-weight="700"
        class="color-grey-dark"
        :style="{ padding: '0' }"
      >
        We have sent you an email with a link to change your password.<br>
        Please check your inbox.
      </ui-subheader>
      <ui-button outline @click.native="$refs.passwordResetEmailSent.close()">
        Close
      </ui-button>
    </ui-modal>
  </ui-layout>
</template>

<script>
import gql from 'graphql-tag'

export default {
  name: 'Login',
  data () {
    return {
      login: {
        email: '',
        password: ''
      },
      remember: false,
      resetPasswordEmail: '',
      boostId: ''
    }
  },
  mounted () {
    this.boostId = this.$store.state.boostLibrary.selectedBoostId
  },
  methods: {
    auth () {
      this.$store.dispatch('loading/loading', true)

      this.$store.dispatch('auth/login', this.login).then((response) => {
        this.$store.dispatch('loading/loading', false)
        if (response.success) {
          this.$store.dispatch('states/closeSnackbar')

          if (this.$store.state.auth.user.isCarrier) {
            this.$router.push({ name: 'carrierDashboard' })
          } else if (this.boostId > 0) {
            this.$router.push({ name: 'launchBoost' })
          } else {
            this.$router.push({ name: 'reports' })
          }
        }
      }).catch((response) => {
        this.$store.dispatch('loading/loading', false)
        this.$store.dispatch('states/setMessage', response.graphQLErrors[0].message)
        this.$store.dispatch('states/openSnackbar')
      })
    },
    sendResetPasswordEmail () {
      this.$store.dispatch('loading/loading', true)

      this.$apollo.mutate({
        mutation: gql`
        mutation requestPasswordResetEmail($email: String!) {
          requestPasswordResetEmail(email: $email) {
            id
          }
        }
        `,
        variables: {
          email: this.resetPasswordEmail
        }
      }).then((response) => {
        this.$store.dispatch('loading/loading', false)
        this.$refs.requestPasswordReset.close()
        this.$refs.passwordResetEmailSent.open()
      }).catch((response) => {
        this.$store.dispatch('loading/loading', false)
        this.$store.dispatch('states/setMessage', response.graphQLErrors[0].message)
        this.$store.dispatch('states/openSnackbar')
      })
    }
  }
}
</script>

<style lang="scss" scoped>
@import "../../assets/scss/variables";
@import "../../assets/scss/mixins";

.login {
  padding: 0 30px;

  @include media(lg) {
    padding: 0 10px;
  }

  .forgotPassword, .signUp {
    margin-top:  20px;
    color:       $link-classic;
    font-size:   14px;
    font-weight: 400;
    line-height: 16px;
    @include media(md) {
      margin-top: 0;
    }
  }

  .forgotPassword {
    text-align: right;
  }

  .signUp {
    margin-top: 20px;
  }
}

#requestPasswordReset {
  p {
    max-width:   360px;
    color:       $grey-basic;
    font-size:   16px;
    font-weight: 400;
    line-height: 24px;
  }
}

#passwordResetEmailSent {
  text-align: center;

  .ui-icon {
    margin-bottom: 50px;
  }
}
</style>
