<template></template>

<script>
import gql from 'graphql-tag'

export default {
  name: 'Logout',
  mounted () {
    this.$apollo.mutate({
      mutation: gql`
      mutation logout {
        logout {
          id
          isSuccessful
          message
        }
      }
      `
    }).then((response) => {
      if (response.data.logout.isSuccessful) {
        this.$store.dispatch('anchoring/setAnchor', false)
        this.$store.dispatch('auth/logout')
        this.$router.push({ name: 'login' })
      } else {
        this.$router.go(-1)
      }
    }).catch((response) => {
      console.log(response)
    })
  }
}
</script>
