<template>
  <div v-if="loading < 1">
    <ui-layout container justify-center wrap class="previewMarketingBoost">
      <ui-layout
        class="col-xs-12 col-md-10 previewMarketingBoost__header"
        :style="{ margin: '50px 0' }"
        align-center
      >
        <ui-avatar
          :src="viewBoost.agentContactInfo.profilePhoto"
          :style="{ width: 'auto' }"
        />
        <div class="previewMarketingBoost__header__contacts">
          <div class="previewMarketingBoost__header__contacts__left">
            {{ viewBoost.agentContactInfo.firstName }}
            {{ viewBoost.agentContactInfo.lastName }}
          </div>
          <div class="previewMarketingBoost__header__contacts__right">
            <div>
              {{ viewBoost.agentContactInfo.phone }}
            </div>
            <div>
              {{ viewBoost.agentContactInfo.email }}
            </div>
          </div>
        </div>
      </ui-layout>
      <ui-layout class="col-xs-12 col-md-10" :style="{ marginBottom: '60px' }">
        <ui-boost-card
          :tags="viewBoost.tags"
          :date="viewBoost.date"
          :coverImage="viewBoost.coverImage"
          :header="viewBoost.title"
          :content="viewBoost.text"
        />
      </ui-layout>
      <ui-layout class="col-xs-12 col-md-10" :style="{ marginBottom: '50px' }" >
        <ui-card header="Quick Quote" fluid>
          <ui-layout wrap justify-center>
            <ui-layout class="col-xs-12 col-md-4">
              <ui-input v-model="contactForm.firstName" label="First name" fluid />
            </ui-layout>
            <ui-layout class="col-xs-12 col-md-4">
              <ui-input v-model="contactForm.lastName" label="Last name" fluid />
            </ui-layout>
          </ui-layout>
          <ui-layout wrap justify-center>
            <ui-layout class="col-xs-12 col-md-4">
              <ui-input v-model="contactForm.email" label="E-mail" fluid />
            </ui-layout>
            <ui-layout class="col-xs-12 col-md-4">
              <ui-input
                fluid
                label="Phone Number"
                mask="###-###-####"
                v-model="contactForm.phone"
              />
            </ui-layout>
          </ui-layout>
          <ui-layout wrap justify-center>
            <ui-layout class="col-xs-12 col-md-4">
              <ui-input v-model="contactForm.zip" label="Zip Code" fluid />
            </ui-layout>
            <ui-layout class="col-xs-12 col-md-4">
              <ui-select
                v-model="contactForm.age"
                label="Age"
                placeholder="Age"
                :data="ageSelect"
                track-by="id"
                text="text"
                fluid
              />
            </ui-layout>
          </ui-layout>
          <ui-layout wrap justify-center>
            <ui-layout class="col-xs-12 col-md-4">
              <ui-select
                v-model="contactForm.gender"
                label="Gender"
                placeholder="Gender"
                :data="genderSelect"
                track-by="id"
                text="text"
                fluid
              />
            </ui-layout>
            <ui-layout class="col-xs-12 col-md-4">
              <ui-select
                v-model="contactForm.tobacco"
                label="Tobacco"
                :data="tobaccoSelect"
                track-by="id"
                text="text"
                :default="1"
                fluid
              />
            </ui-layout>
          </ui-layout>
          <ui-layout>
            <ui-layout class="col-xs-12" justify-center>
              <ui-button @click.native="send()" success>
                Get Quote
              </ui-button>
            </ui-layout>
          </ui-layout>
        </ui-card>
      </ui-layout>
      <ui-layout
        class="color-grey-basic col-xs-12 col-md-10"
        :style="{ marginBottom: '50px', textAlign: 'center' }"
      >
        By completing this form, you authorize an insurance agent to contact you by phone, text or fax at the phone number listed to provide automated and/or pre-recorded advertisements. You are not required to sign this to purchase any product. This consent applies to all products currently or in the future marketed or sold by us. This authorization continues until it is revoked by you. Further, you waive your right to commence or be party to any group, class or collective action against us relating to any communication made by us to you. This waiver extends to protect any third party on whose behalf or for whose benefit, in whole or in part, we initiated any communication. This waiver applies even if you revoke your consent to be contacted in the future.
      </ui-layout>
    </ui-layout>

    <ui-modal id="messageSent" ref="messageSent">
      <ui-icon border>check</ui-icon>
      <ui-subheader
        bottom="40"
        font-size="18"
        font-weight="500"
        class="color-grey-dark"
        :style="{ padding: '0' }"
      >
        Your Quote Is On It's Way.
      </ui-subheader>
      <p>
        Based on your information, it looks like you might be eligible for an additional household discount. Your agent is checking this and will be supplying your quote very soon.
      </p>
      <ui-button dense outline @click.native="$refs.messageSent.close()">
        Close
      </ui-button>
    </ui-modal>
  </div>
</template>

<script>
import gql from 'graphql-tag'
import { clone } from 'lodash'
import fingerprint from 'fingerprintjs2'

export default {
  name: 'AgentPreviewBoost',
  data () {
    return {
      loading: 0,
      fingerprint: '',
      pageId: '',
      viewBoost: {},
      genderSelect: [
        {
          id: 1,
          text: 'Male'
        },
        {
          id: 2,
          text: 'Female'
        }
      ],
      tobaccoSelect: [
        {
          id: false,
          text: 'Non-Tobacco'
        },
        {
          id: true,
          text: 'Tobacco'
        }
      ],
      contactForm: {
        firstName: '',
        lastName: '',
        email: '',
        phone: '',
        zip: '',
        age: null,
        gender: {},
        tobacco: {}
      }
    }
  },
  apollo: {
    viewBoost: {
      query: gql`
      query viewBoost($id: Int!) {
        viewBoost(id: $id) {
          id
          coverImage
          title
          summary
          text
          tags {
            text
            color {
              r
              g
              b
            }
          }
          agentContactInfo {
            id
            profilePhoto
            firstName
            lastName
            email
            phone
          }
        }
      }
      `,
      variables () {
        return {
          id: this.$route.params.id
        }
      },
      result ({ data }) {
        const head = document.querySelector('head')
        const description = `${data.viewBoost.text.replace(/(<([^>]+)>)/ig, '').split(' ').slice(0, 20).join(' ')}...`

        const metaTags = [
          {
            property: 'og:url',
            content: `${window.location.host}/boost/${this.$route.params.id}`
          },
          {
            property: 'og:type',
            content: 'article'
          },
          {
            property: 'og:title',
            content: data.viewBoost.title
          },
          {
            property: 'og:description',
            content: description
          },
          {
            property: 'og:image',
            content: data.viewBoost.coverImage
          }
        ]

        metaTags.forEach((meta) => {
          const e = document.createElement('meta')
          e.setAttribute('property', meta.property)
          e.setAttribute('content', meta.content)
          head.appendChild(e)
        })
      },
      loadingKey: 'loading'
    }
  },
  computed: {
    ageSelect () {
      let age = { id: 1, text: 64 }
      let ages = []

      while (age.text < 100) {
        ages.push(clone(age))
        age.id += 1
        age.text += 1
      }

      return ages
    }
  },
  watch: {
    loading: function (value) {
      if (value === 0) {
        this.$apollo.mutate({
          mutation: gql`
          mutation boostVisited(
            $id: Int!,
            $url: String!,
            $sourceType: String,
            $sourceKey: String,
            $fingerPrint: String,
          ) {
            boostVisited(
              id: $id,
              url: $url,
              sourceType: $sourceType,
              sourceKey: $sourceKey,
              fingerPrint: $fingerPrint,
            ) {
              id
            }
          }
          `,
          variables: {
            id: this.viewBoost.id,
            url: window.location.href,
            sourceType: this.$route.params.sourceType,
            sourceKey: this.$route.params.sourceKey,
            fingerPrint: this.fingerprint
          }
        }).then((response) => {
          this.pageId = response.data.boostVisited.id
        }).catch((response) => {
          this.$store.dispatch('states/setMessage', response.graphQLErrors[0].message)
          this.$store.dispatch('states/openSnackbar')
        })
      }
    }
  },
  mounted () {
    const vm = this

    fingerprint().get((result) => {
      vm.fingerprint = result
    })
    // this.$ua.trackView('PreviewMarketingBoost')
  },
  methods: {
    send () {
      this.$apollo.mutate({
        mutation: gql`
        mutation boostLeadForm(
          $id: Int!,
          $pageId: Int,
          $tag: String!,
          $firstName: String,
          $lastName: String,
          $email: String,
          $phoneNumber: String,
          $zip: String,
          $age: Int!,
          $gender: String!,
          $isTobaccoUser: Boolean!
        ) {
          boostLeadForm(
            id: $id,
            pageId: $pageId,
            tag: $tag,
            firstName: $firstName,
            lastName: $lastName,
            email: $email,
            phoneNumber: $phoneNumber,
            zip: $zip,
            age: $age,
            gender: $gender,
            isTobaccoUser: $isTobaccoUser
          ) {
            id
            isSuccessful
            message
          }
        }
        `,
        variables: {
          id: this.viewBoost.id,
          pageId: this.pageId,
          tag: this.viewBoost.tags[0].text,
          firstName: this.contactForm.firstName,
          lastName: this.contactForm.lastName,
          email: this.contactForm.email,
          phoneNumber: this.contactForm.phone,
          zip: this.contactForm.zip,
          age: this.contactForm.age.text,
          gender: this.contactForm.gender.text,
          isTobaccoUser: this.contactForm.tobacco.id || false
        }
      }).then((response) => {
        this.$refs.messageSent.open()
      }).catch((response) => {
        this.$store.dispatch('states/setMessage', response.graphQLErrors[0].message)
        this.$store.dispatch('states/openSnackbar')
      })
    }
  }
}
</script>

<style lang="scss">
@import '../../../assets/scss/variables';
@import '../../../assets/scss/mixins';

.previewMarketingBoost {
  @media screen and (max-width: 320px) {
    width: 100% !important;
  }

  &__header {
    &__contacts {
      width:       100%;
      margin-left: 20px;
      text-align:  left;
      @include media(md) {
        display:         flex;
        align-items:     center;
        justify-content: space-between;
      }

      &__left {
      	color:       $grey-dark;
      	font-size:   14px;
      	font-weight: 500;
      	line-height: 24px;
      }

      &__right div {
      	color:       $grey-basic;
      	font-size:   14px;
      	line-height: 24px;
      }
    }

    .ui-avatar__hasImage__image {
      width:  60px;
      height: 60px;
    }
  }
}

#messageSent {
  text-align: center;

  .ui-icon {
    margin-bottom: 30px;
  }

  p {
    max-width:   360px;
    color:       $grey-basic;
    font-size:   16px;
    font-weight: 400;
    line-height: 24px;
  }
}
</style>
