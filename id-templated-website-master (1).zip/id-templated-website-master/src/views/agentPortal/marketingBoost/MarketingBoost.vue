<template>
  <div v-if="loading < 1">
    <ui-layout container justify-center wrap>
      <ui-layout class="col-xs-12">
        <div class="backButton" @click="$router.push({ name: 'myBoosts' })">
          <ui-icon>keyboard_backspace</ui-icon>
          <div>Back to Overview</div>
        </div>
      </ui-layout>
      <ui-layout class="col-xs-12 col-md-8" :style="{ marginBottom: '50px' }">
        <ui-boost-card
          :tags="boostCard.tags"
          :date="boostCard.date"
          :coverImage="boostCard.coverImage"
          :header="boostCard.title"
          :content="boostCard.text"
        />
      </ui-layout>

      <template v-if="boostCard.sent">
        <ui-header font-weight="300" font-size="26" top="50">
          Marketing Boost Data
        </ui-header>
        <ui-layout class="col-xs-12 col-md-8" wrap :style="{ padding: '0' }">
          <ui-subheader
            class="color-grey-dark"
          >
            Your Marketing Boost reports and analytics will be available seven days after you send your first marketing boost.
          </ui-subheader>
        </ui-layout>

        <ui-layout class="col-xs-12 col-md-8" wrap :style="{ padding: '0' }">
          <ui-layout class="col-xs-12 col-md-6">
            <ui-card header="Engagement via Email" fluid>
              <ui-bar-chart
                :data="stats.statsViaEmail.data"
                :options="stats.statsViaEmail.options"
              />
            </ui-card>
          </ui-layout>
          <ui-layout class="col-xs-12 col-md-6">
            <ui-card header="Clicks via Social Media" fluid>
              <ui-bar-chart
                :data="stats.statsViaSocial.data"
                :options="stats.statsViaSocial.options"
              />
            </ui-card>
          </ui-layout>
          <ui-layout class="col-xs-12 col-md-6">
            <ui-card header="Clicks" fluid>
              <ui-doughnut-chart
                :data="stats.clicksViaChannel.data"
                :options="stats.clicksViaChannel.options"
              />
            </ui-card>
          </ui-layout>
          <ui-layout class="col-xs-12 col-md-6">
            <ui-card header="Leads Generated" fluid>
              <ui-doughnut-chart
                :data="stats.leadsViaChannel.data"
                :options="stats.leadsViaChannel.options"
              />
            </ui-card>
          </ui-layout>
        </ui-layout>
        <ui-header font-weight="300" font-size="26" top="50">
          Resend The Marketing Boost
        </ui-header>
        <ui-layout justify-center>
          <ui-button success @click.native="sendBoost()">Send Marketing Boost</ui-button>
        </ui-layout>
        <!-- <ui-layout class="col-xs-12 col-md-8" wrap :style="{ padding: '0' }">
          <ui-subheader
            class="color-grey-dark"
          >
            Your Marketing Boost reports and analytics will be available seven days after you send your first marketing boost.
          </ui-subheader>
        </ui-layout> -->
      </template>

      <template v-else>
        <ui-layout justify-center>
          <ui-button success @click.native="sendBoost()">Send Marketing Boost</ui-button>
        </ui-layout>
      </template>
    </ui-layout>

    <ui-modal id="success" ref="success" non-closable>
      <ui-icon border>check</ui-icon>
      <ui-subheader
        font-size="16"
        font-weight="700"
        top="30"
        bottom="10"
        class="color-grey-dark"
      >
        Success!
      </ui-subheader>
      <p>Your Boost has been sent.</p>
      <ui-modal-actions justify-center>
        <ui-button outline @click.native="$refs.success.close()">
          Close
        </ui-button>
      </ui-modal-actions>
    </ui-modal>
  </div>
</template>

<script>
import gql from 'graphql-tag'

export default {
  name: 'AgentMarketingBoost',
  data () {
    return {
      loading: 0,
      stats: {
        statsViaEmail: {
          data: {
            labels: [],
            datasets: [{
              label: 'Clicks',
              backgroundColor: '#358ED7',
              data: []
            },
            {
              label: 'Opens',
              backgroundColor: '#5E6977',
              data: []
            }]
          },
          options: {
            legend: {
              labels: {
                boxWidth: 12
              }
            }
          }
        },
        statsViaSocial: {
          data: {
            labels: [],
            datasets: [{
              backgroundColor: [],
              data: []
            }]
          },
          options: {
            legend: {
              display: false,
              labels: {
                boxWidth: 12
              }
            }
          }
        },
        clicksViaChannel: {
          data: {
            labels: [],
            datasets: [{
              backgroundColor: [],
              data: []
            }]
          },
          options: {
            percentageInnerCutout: 80,
            legend: {
              display: true,
              position: 'right',
              labels: {
                boxWidth: 12
              }
            }
          }
        },
        leadsViaChannel: {
          data: {
            labels: [],
            datasets: [{
              backgroundColor: [],
              data: []
            }]
          },
          options: {
            percentageInnerCutout: 20,
            legend: {
              display: true,
              position: 'right',
              labels: {
                boxWidth: 12
              }
            }
          }
        }
      },
      boostCard: {},
      connections: {}
    }
  },
  apollo: {
    boostCard: {
      query: gql`
      query marketingBoost($id: Int!) {
        marketingBoost(id: $id) {
          id
          coverImage
          title
          text
          date
          sent
          tags {
            text
            color {
              r
              g
              b
            }
          }
          boostStats {
            contactSourceStats {
              sends
              clicks
              opens
              leads
              sourceType
            }
            socialMediaStats {
              clicks
              leads
              socialNetworkType
            }
            channelStats {
              clicks
              leads
              channelType
            }
            totalClicks
            totalLeads
          }
        }
      }
      `,
      variables () {
        return {
          id: this.$route.params.id
        }
      },
      result ({ data }) {
        this.populateStatsViaEmailData(data)
        this.populateStatsViaSocialData(data)
        this.populateStatsViaChannelData(data)
      },
      update: (response) => response.marketingBoost,
      loadingKey: 'loading'
    },
    connections: {
      query: gql`
      query getConnections {
        getConnections {
          totalCount
          contactConnections {
            id
            name
            type
            icon
            color
            isConnected
            count
            isUploadFileType
          }
          socialMediaConnections {
            id
            name
            type
            icon
            color
            isConnected
          }
        }
      }
      `,
      update: (response) => response.getConnections,
      loadingKey: 'loading'
    }
  },
  watch: {
    loading (value) {
      if (value !== 0) {
        this.$store.dispatch('loading/loading', true)
      } else {
        this.$store.dispatch('loading/loading', false)
      }
    }
  },
  methods: {
    sendBoost () {
      this.$store.dispatch('loading/loading', true)

      this.$apollo.mutate({
        mutation: gql`
        mutation sendMarketingBoost($id: Int!) {
          sendMarketingBoost(id: $id) {
            id
            isSuccessful
            message
          }
        }
        `,
        variables: {
          id: this.boostCard.id
        },
        refetchQueries: [
          {
            query: gql`
            query marketingBoost($id: Int!) {
              marketingBoost(id: $id) {
                id
                coverImage
                title
                text
                date
                sent
                tags {
                  text
                  color {
                    r
                    g
                    b
                  }
                }
                boostStats {
                  contactSourceStats {
                    sends
                    clicks
                    opens
                    leads
                    sourceType
                  }
                  socialMediaStats {
                    clicks
                    leads
                    socialNetworkType
                  }
                  channelStats {
                    clicks
                    leads
                    channelType
                  }
                  totalClicks
                  totalLeads
                }
              }
            }
            `,
            variables: {
              id: this.boostCard.id
            }
          }
        ]
      }).then((response) => {
        this.$store.dispatch('loading/loading', false)
        this.$refs.success.open()
      }).catch((response) => {
        this.$store.dispatch('loading/loading', false)
        this.$store.dispatch('states/setMessage', response.graphQLErrors[0].message)
        this.$store.dispatch('states/openSnackbar')
      })
    },
    getChannelTypeBackgroundColor (channelType) {
      if (channelType === 'Facebook') {
        return '#4460A0'
      }

      if (channelType === 'LinkedIn') {
        return '#007EBB'
      }

      if (channelType === 'LinkedIn') {
        return '#007EBB'
      }

      if (channelType === 'Google+') {
        return '#F93F2D'
      }

      if (channelType === 'Twitter') {
        return '#00AAEC'
      }

      if (channelType === 'Gmail') {
        return '#AC3D31'
      }

      if (channelType === 'Yahoo') {
        return '#6B0094'
      }

      if (channelType === 'Outlook' || channelType === 'MSN') {
        return '#0072C6'
      }

      if (channelType === 'AOL') {
        return '#2D3140'
      }

      if (channelType === 'iCloud') {
        return '#BD10E0'
      }

      if (channelType === 'Other') {
        return '#878787'
      }

      return '#000000'
    },
    populateStatsViaEmailData (data) {
      const self = this
      const statsViaEmailData = {
        labels: [],
        datasets: [{
          label: 'Clicks',
          backgroundColor: '#358ED7',
          data: []
        },
        {
          label: 'Opens',
          backgroundColor: '#5E6977',
          data: []
        }]
      }

      data.marketingBoost.boostStats.contactSourceStats.forEach(function (element) {
        statsViaEmailData.labels.push(element.sourceType)
        statsViaEmailData.datasets[0].data.push(element.clicks)
        statsViaEmailData.datasets[1].data.push(element.opens)
      })

      self._data.stats.statsViaEmail.data = statsViaEmailData
    },
    populateStatsViaSocialData (data) {
      const self = this

      const statsViaSocialData = {
        labels: [],
        datasets: [{
          backgroundColor: [],
          data: []
        }]
      }

      data.marketingBoost.boostStats.socialMediaStats.forEach(function (element) {
        statsViaSocialData.labels.push(element.socialNetworkType)
        statsViaSocialData.datasets[0].data.push(element.clicks)
        statsViaSocialData.datasets[0].backgroundColor.push(self.getChannelTypeBackgroundColor(element.socialNetworkType))
      })

      self._data.stats.statsViaSocial.data = statsViaSocialData
    },
    populateStatsViaChannelData (data) {
      const self = this

      const clicksViaChannelData = {
        labels: [],
        datasets: [{
          backgroundColor: [],
          data: []
        }]
      }

      const leadsViaChannelData = {
        labels: [],
        datasets: [{
          backgroundColor: [],
          data: []
        }]
      }

      data.marketingBoost.boostStats.channelStats.forEach(function (element) {
        // remove 'if' statements if we want to show ALL keys in the legend.
        if (element.clicks > 0) {
          clicksViaChannelData.labels.push(element.channelType)
          clicksViaChannelData.datasets[0].data.push(element.clicks)
          clicksViaChannelData.datasets[0].backgroundColor.push(self.getChannelTypeBackgroundColor(element.channelType))
        }

        if (element.leads > 0) {
          leadsViaChannelData.labels.push(element.channelType)
          leadsViaChannelData.datasets[0].data.push(element.leads)
          leadsViaChannelData.datasets[0].backgroundColor.push(self.getChannelTypeBackgroundColor(element.channelType))
        }
      })

      self._data.stats.clicksViaChannel.data = clicksViaChannelData
      self._data.stats.leadsViaChannel.data = leadsViaChannelData
    }
  },
  mounted () {
    this.$ua.trackView('MarketingBoost')
  }
}
</script>

<style lang="scss">
@import '../../../assets/scss/variables';
@import '../../../assets/scss/mixins';

.backButton {
  margin:      20px;
  display:     flex;
  align-items: center;
  cursor:      pointer;
  @include media(md) {
    margin: 40px 0;
  }

  i {
    margin-right: 20px;
    color:        $grey-dark;
    display:      block;
  }

  div {
    color: $grey-basic;
    font-size:   16px;
    font-weight: 500;
    line-height: 16px;
  }
}

#success {
  .ui-modal__content {
    margin:         20px;
    display:        flex;
    flex-direction: column;
    align-items:    center;
  }

  p {
    max-width:   360px;
    margin:      0;
    color:       $grey-basic;
    font-size:   16px;
    font-weight: 400;
    line-height: 24px;
    text-align:  center;
  }
}
</style>

<style lang="scss" scoped>
.ui-card {
  margin-bottom: 20px;
}
</style>
