<template>
  <div v-if="loading < 1" class="landingPage">
    <ui-layout justify-center wrap>

      <div class="wrapper">
        <div class="one">
          <h2 class="welcome">Welcome to the<br>Marketing<br>Boosts Library</h2>
        </div>
        <div class="two">
          <p>Your <strong style="font-size: 24px;">Free Marketing Boosts</strong> are ready to send.</p>
          <p>Select a boost below and once you are done previewing it, send it to your contacts through email and social media.</p>
        </div>
        <div class="tag-cloud three">
          <p><strong><em>Boost Tags</em></strong></p>
        <div class="dis-tag" v-for="tag in boostTags" :style="{ background: `rgb(${tag.color.r},${tag.color.g},${tag.color.b})` }">{{ tag.text }}</div>
        </div>
      </div>

      <ui-layout id="boosts-wrapper" class="col-xs-12" justify-center wrap>
        <ui-layout
          v-for="boost in boosts.data"
          :key="boost.id"
          class="col-xs-12 col-sm-6 col-md-3"
        >
          <ui-boost-library-mini-card
            :tags="boost.tags"
            :date="boost.date"
            :coverImage="boost.coverImage"
            :completed="boost.sent"
            :header="boost.title"
            :content="boost.summary"
            @click.native="$router.push({ name: 'libraryBoost', params: { id: boost.id } })"
            :style="{ marginBottom: '30px' }"
          />
        </ui-layout>
      </ui-layout>
      <ui-layout justify-center>
        <!-- <ui-pagination
          :current="pagination.page"
          :pages="pages"
          @pagination="changePage"
        /> -->
      </ui-layout>

      </ui-layout>
    </ui-layout>

    <!-- Modal -->
    <div v-show="showModal" class="howItWorksModal">
      <div class="howItWorksContent">
        <h1>How it works:</h1>

        <!-- Section 1 -->
        <ui-layout id="about-1" align-center wrap>
          <ui-layout class="col-xs-12 col-md-6 remove-left" align-center>
            <img :src="`/static/BoostLibrary.png`">
          </ui-layout>
          <ui-layout class="col-xs-12 col-md-6 about-text" column>
            <span>Step 1: <br>Select and Preview Your Boost</span>
            <p>Take a look and you'll see exactly what your marketing boost will look like before you send it</p>
          </ui-layout>
          <hr class="separator"></hr>
        </ui-layout>

        <!-- Section 2 -->
        <ui-layout id="about-2" align-center wrap>     
          <!-- Text -->
          <ui-layout class="col-xs-12 col-md-6 about-text" column>
            <span>Step 2: <br> Link Email & Social Media</span>
            <p>Choose exactly which email accounts and social media accounts you want to send your marketing boost through. Remember, the more you send, the better your results.</p>
          </ui-layout>
          <ui-layout class="col-xs-12 col-md-6 remove-right" align-center>
            <img :src="`/static/landing-2.png`">
          </ui-layout>
      
          <hr class="separator"></hr>
        </ui-layout>

        <!-- Section 3 -->
        <ui-layout id="about-3" align-center wrap>
          <ui-layout class="col-xs-12 col-md-6 about-image" align-center>
            <img  :src="`/static/landing-3.png`">
          </ui-layout>
          <ui-layout class="col-xs-12 col-md-6 about-text" column>
            <span>Step 3: <br> Send</span>
            <p>Once you're ready, click send and your Marketing Boost will be distributed.</p>
          </ui-layout>
          <hr class="separator"></hr>
        </ui-layout>

        <!-- Section 4 -->
        <ui-layout id="about-4" align-center wrap>
          <ui-layout class="col-xs-12 col-md-6 about-text" column>
            <span>Step 4: <br> Report</span>
            <p>Cutting edge reporting will show you all the results of the marketing boost. But don't worry! Only you can see your client’s contact information. This is not shared with Americo and your client’s information is kept safe from solicitors!</p>
          </ui-layout>
          <ui-layout class="col-xs-12 col-md-6 remove-right" align-center>
            <img id="about-4" :src="`/static/landing-4.png`">
          </ui-layout>

          <ui-layout justify-center>
            <ui-button
              success
              :style="{ marginTop: '50px', marginBottom: '70px' }"
              @click.native="showModal=0"
            >
              Got it!
            </ui-button>
          </ui-layout>
        </ui-layout>
      </div>
    </div>

  </div>
</template>

<script>
import gql from 'graphql-tag'

export default {
  name: 'BoostLibrary',
  data () {
    return {
      loading: 0,
      showModal: 1,
      boosts: [],
      pagination: {
        page: 1,
        offset: 0,
        countPerPage: 9
      }
    }
  },
  apollo: {
    boosts: {
      query: gql`
      query getCarrierBoosts($offset: Int!, $countPerPage: Int!) {
        getCarrierBoosts(offset: $offset, countPerPage: $countPerPage) {
          totalCount
          data {
            id
            coverImage
            title
            summary
            date
            tags {
              text
              color {
                r
                g
                b
              }
            }
          }
        }
      }
      `,
      variables () {
        return {
          offset: this.pagination.offset,
          countPerPage: this.pagination.countPerPage
        }
      },
      update: (response) => response.getCarrierBoosts,
      loadingKey: 'loading'
    }
  },
  watch: {
    loading (value) {
      if (value !== 0) {
        this.$store.dispatch('loading/loading', true)
      } else {
        this.$store.dispatch('loading/loading', false)
      }
    }
  },
  computed: {
    boostTags: function () {
      let tagFilter = []
      let tagArray = []
      for (let boost in this.boosts.data) {
        for (let tag in this.boosts.data[boost].tags) {
          if (tagFilter.indexOf(this.boosts.data[boost].tags[tag].text) > -1) {
            continue
          } else {
            tagArray.push(this.boosts.data[boost].tags[tag])
            tagFilter.push(this.boosts.data[boost].tags[tag].text)
          }
        }
      }
      return tagArray
    },
    visibleBoosts: function () {
      let visible = []

      return visible
    }
  }
}
</script>

<style lang="scss">
@import '../../assets/scss/variables';
@import '../../assets/scss/mixins';

#launchWidget {

  @include media(md) {
    max-width: 43%;
    margin: 0 auto;
  }

  @include media(lg) {
    max-width: 100%;
    background-color: $grey-light;
    width: 275px;
    border-radius: 15px;
    border: 1px solid $grey-light;
    margin: 0 auto;
    position: fixed;
    z-index: 1;
    top: 110px;
    left: 20px;
    .ui-button {
      width: 100%;
    }
  }
  .ui-button {
    width: 100%;
    margin: 0 20px 20px 20px;
  }
}

#about-2 .about-text, #about-4 .about-text {
  padding-left: 25px;
}

#about-3 img {
  max-height: 350px;
  margin: 0 auto
}

#about-3 .about-image {
  flex-basis: 40% !important;
}

.remove-left {
  padding-left: 0 !important;
}

.remove-right {
  padding-right: 0 !important;
}

.separator {
  width: 90%;
  border: 0; 
  height: 0; 
  border-top: 1px solid rgba(0, 0, 0, 0.1); 
  border-bottom: 1px solid rgba(255, 255, 255, 0.3);
}

.landingPage {
  &__description {
    margin:        0 auto;
    margin-bottom: 20px;
    padding:       0 20px 0 20px;
    max-width:     700px;
    color:         $grey-dark;
    text-align:    center;
  }

  &__content {
    margin:     0 auto;
    padding:    0 20px;
    max-width:  700px;
    color:      $grey-dark;
    text-align: center;

    * {
      color:       $grey-dark;
      font-size:   16px;
      font-weight: 400;
      line-height: 25px;
    }
  }

  .ui-boost-card {
    @include media(lg) {
      margin-top: 20px;
    }
  }

  .ui-boost-card__content {
    display: none;
  }
}

.wrapper {
  display: inline;
  margin: 30px 0 30px 0;

  @include media(md) {
    display: grid;
    grid-template-columns: 1fr 1.3fr 1fr;
    grid-gap: 10px;
  }
}

.one, .two, .three {
  padding: 30px;
  color: $grey-dark;
}

.one {
  grid-column: 1;
  border: none;

  @include media(md) {
    border-right: 2px solid $grey-dark;
  }
}

.two {
  grid-column: 2;
  border: none;

  @include media(md) {
    border-right: 2px solid $grey-dark;
  }
}

.two p {
  font-size: 22px;
}

.three {
  grid-column: 3;
}

.three p strong em{
  font-size: 22px;
}

.welcome {
  font-size: 42px;
  text-align: right;
  font-weight: 900;
  margin: 0;
  color: $grey-dark;
}

.tag-cloud {
  flex-direction: row;
}

.dis-tag {
  display: inline-block;
  box-sizing: border-box;
  padding: 6px 13px;
  height: 30px;
  font-size: 14px;
  line-height: 18px;
  border-radius: 40px;
  color: white;
  margin-bottom: 10px;
  text-align: center;

  &:not(:last-of-type) {
    margin-right: 10px;
  }
}

#boosts-wrapper {
  padding: 0 20px 0 20px;

  @include media(md) {
    padding: 0 50px 0 50px;
  }
}

.howItWorksModal {
  position: fixed;
  z-index: 1;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  overflow: auto;
  background-color: rgb(0,0,0);
  background-color: rgba(0,0,0,0.4);
}

.howItWorksContent {
  background-color: #f2f2f2;
  margin: 8% auto;
  border: 1px solid #888;
  border-radius: 5px;
  width: 100%;
  @include media(md) {
    width: 60% !important;
  }
  img {
    max-width: 100%;
  }
  h1 {
    text-align: center;
    font-size: 50px;
    color: $grey-dark;
  }
  span {
    color:          $grey-dark;
    font-size:      40px;
    font-weight:    300;
    line-height:    58px;
    letter-spacing: -1.54px; 
  }
  p {
    color:       $grey-dark;
    font-size:   22px;
    font-weight: 300;
    line-height: 32px;
  }
}
</style>
