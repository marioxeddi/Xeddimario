<template>
  <div>
    <ui-header
      class="color-primary"
      font-size="24"
      top="90"
      bottom="16"
    >
      Welcome to your Marketing Boost
    </ui-header>
    <ui-subheader class="onboardinBoost-subheader color-grey-dark">
      Preview the Marketing Boost below, link all social media and email accounts desired (remember, the more you link, the more will see it) then click send.  Don’t worry!  Your contacts information is not seen by Americo and is not shared with anyone!
    </ui-subheader>
    <ui-layout container justify-center wrap>
      <ui-layout class="col-xs-12 col-md-8" :style="{ marginBottom: '50px' }">
        <ui-boost-card
          :tags="boostCard.tags"
          :coverImage="boostCard.coverImage"
          :header="boostCard.title"
          :content="boostCard.text"
        />
      </ui-layout>

      <!-- Load Contacts -->
      <ui-card
        fluid
        header="Load Contacts"
        :style="{ marginBottom: '30px' }"
      >
        <ui-layout wrap>
          <ui-layout
            v-for="contactCard in connections.contactConnections"
            :key="contactCard.name"
            class="col-xs-12 col-sm-6 col-md-2"
          >
            <ui-social-card
              :id="contactCard.id"
              :name="contactCard.name"
              :type="contactCard.type"
              :icon="contactCard.icon"
              :color="contactCard.color"
              :connected="contactCard.isConnected"
              :count="contactCard.count"
              :isUploadFileType="contactCard.isUploadFileType"
              @clicked="setAnchor()"
            />
          </ui-layout>
          <ui-table
            card-table
            searchable
            deletable
            custom-action="+ Add Contact"
            custom-action-icon="add"
            pagination
            :offset="pagination.offset"
            :countPerPage="pagination.countPerPage"
            :totalCount="contactsTable.totalCount"
            :fields="contactsTableFields"
            :data="contactsTable.data"
            :search-query="searchQuery"
            :sorting="sorting"
            @customAction="$refs.addContact.open()"
            @search="searchQuery = $event"
            @sort="sorting = $event"
            @delete="deleteRows"
            @changeCountPerPage="pagination.countPerPage = $event"
            @prev="pagination.offset = $event"
            @next="pagination.offset = $event"
          />
        </ui-layout>
      </ui-card>
      <ui-card
        fluid
        header="Link Social Media"
        :style="{ marginBottom: '50px' }"
      >
        <ui-layout wrap>
          <ui-layout
            v-for="socialCard in connections.socialMediaConnections"
            :key="socialCard.name"
            class="col-xs-12 col-sm-6 col-md-2"
          >
            <ui-social-card
              :id="socialCard.id"
              :name="socialCard.name"
              :type="socialCard.type"
              :icon="socialCard.icon"
              :color="socialCard.color"
              :connected="socialCard.isConnected"
              :count="null"
              :isUploadFileType="socialCard.isUploadFileType"
              @clicked="setAnchor()"
            />
          </ui-layout>
        </ui-layout>
      </ui-card>
      <ui-layout justify-center class="col-xs-12">
        <ui-button v-if="boostCard.sent" success @click.native="sendBoost()">
          Resend Marketing Boost
        </ui-button>
        <ui-button v-else success @click.native="$refs.acceptTermsAndConditions.open()">
          Send Marketing Boost
        </ui-button>
      </ui-layout>
    </ui-layout>

    <ui-modal id="acceptTermsAndConditions" ref="acceptTermsAndConditions">
      <ui-subheader
        font-size="18"
        font-weight="700"
        class="color-grey-dark"
      >
        Terms and Conditions
      </ui-subheader>
      <p>
        IMPORTANT MESSAGE – PLEASE READ!
        <br><br>
        Americo is not responsible for the content of this Marketing Boost. REVIEW THE MESSAGE CAREFULLY
        BEFORE YOU SEND. The Marketing Boost is designed to interact and educate your contacts via email
        and social media to generate interest in insurance and/or annuity products provided by Americo. You
        are responsible for ensuring marketing materials used or sent as part of this program meet all insurance
        marketing rules, regulations and statutes including but not limited to sales practices and CANSPAM
        requirements.
        Americo and its affiliates do NOT KEEP YOUR CONTACTS PERSONAL DATA and DO NOT MARKET TO OR
        SELL YOUR CONTACTS – YOUR CONTACTS ARE SAFE! However, Americo and its affiliates reserve the
        right to track the results of the Marketing Boosts to better improve future Marketing Boosts and to
        generate useful reports to you.
        Your contacts information is not sold or distributed in any way and all Marketing Boosts are sent
        through your email and social media channels and the integrity of the contacts information is the
        responsibility of those channels (Gmail®, Yahoo®, Outlook®, MSN®, Facebook®, Twitter®, LinkedIn®,
        Google®, AOL®, Apple®, and any other distribution channels you elect to use).
        By clicking on the box below you agree that you understand your obligations under this program and
        that you understand that any action taken or brought against Americo by any contact as a direct or
        indirect result of the Marketing Boost shall be indemnified as required by the agency agreement
        between you and Americo.
      </p>
      <ui-modal-actions justify-center>
        <ui-button success @click.native="sendBoost()">
          Accept and Continue
        </ui-button>
      </ui-modal-actions>
    </ui-modal>

    <ui-modal id="boostsSendMethodModal" ref="boostsSendMethodModal" non-closable>
      <ui-icon border>check</ui-icon>
      <ui-subheader
        font-size="16"
        font-weight="700"
        top="30"
        bottom="10"
        class="color-grey-dark"
      >
        Success! Your Boost has been sent.
      </ui-subheader>
      <p>You will receive a full report in one week, you might also have a few people contact you directly who fill out a quote request.  Be on the lookout for increased activity from your network of contacts!</p>
      <ui-subheader
        font-size="16"
        font-weight="700"
        top="0"
        bottom="20"
        class="color-grey-dark"
      >
        Send out all future boosts automatically.
      </ui-subheader>
      <ui-checkbox
        id="sendAutomatically"
        v-model="autoSend"
        :value="autoSend"
        label="Send automatically"
      />
      <ui-modal-actions justify-center>
        <ui-button outline @click.native="confirmBoostSendMethod()">
          Close
        </ui-button>
      </ui-modal-actions>
    </ui-modal>

    <ui-modal id="addContact" ref="addContact">
      <ui-card header="Add New Contact">
        <ui-layout wrap>
          <ui-layout class="col-xs-12 col-md-6">
            <ui-input
              v-model="newContact.firstName"
              label="First name"
              fluid
            />
          </ui-layout>
          <ui-layout class="col-xs-12 col-md-6">
            <ui-input
              v-model="newContact.lastName"
              label="Last name"
              fluid
            />
          </ui-layout>
          <ui-layout class="col-xs-12">
            <ui-input
              v-model="newContact.email"
              label="E-mail"
              fluid
            />
          </ui-layout>
          <ui-layout class="col-xs-12" justify-end :style="{ marginTop: '15px' }">
            <ui-button
              dense
              outline
              @click.native="$refs.addContact.close()"
              :style="{ marginRight: '10px' }"
            >
              Cancel
            </ui-button>
            <ui-button
              dense
              success
              @click.native="addContact()"
            >
              Add Contact
            </ui-button>
          </ui-layout>
        </ui-layout>
      </ui-card>
    </ui-modal>

    <ui-modal id="state" ref="state">
      <ui-icon border>check</ui-icon>
      <ui-subheader
        font-size="18"
        font-weight="500"
        top="30"
        bottom="10"
        class="color-grey-dark"
      >
        {{ message }}
      </ui-subheader>
      <ui-modal-actions justify-center>
        <ui-button outline @click.native="$refs.state.close()">
          Close
        </ui-button>
      </ui-modal-actions>
    </ui-modal>

    <ui-modal id="success" ref="success" non-closable>
      <ui-icon border>check</ui-icon>
      <ui-subheader
        font-size="16"
        font-weight="700"
        top="30"
        bottom="10"
        class="color-grey-dark"
      >
        Success!
      </ui-subheader>
      <p>Your Boost has been sent.</p>
      <ui-modal-actions justify-center>
        <ui-button outline @click.native="$refs.success.close()">
          Close
        </ui-button>
      </ui-modal-actions>
    </ui-modal>
  </div>
</template>

<script>
import gql from 'graphql-tag'
// import { clone } from 'lodash'

export default {
  name: 'LaunchBoost',
  data () {
    return {
      loading: 0,
      boostId: this.$store.state.boostLibrary.selectedBoostId,
      boostCard: {},
      connections: {},
      message: '',
      autoSend: true,
      searchQuery: '',
      contactCards: [],
      contactsTable: {
        totalCount: 0,
        data: []
      },
      contactsTableFields: [
        {
          name: 'name',
          header: 'Name'
        },
        {
          name: 'email',
          header: 'E-mail'
        },
        {
          name: 'sourceType',
          header: 'Source'
        }
      ],
      newContact: {
        firstName: '',
        lastName: '',
        email: ''
      },
      pagination: {
        offset: 0,
        countPerPage: 50
      },
      sorting: {
        column: 'name',
        isSortDesc: true
      }
    }
  },
  apollo: {
    boostCard: {
      query: gql`
      query getBoost($id: Int!) {
        getBoost(id: $id) {
          id
          coverImage
          title
          text
          date
          sent
          tags {
            text
            color {
              r
              g
              b
            }
          }
        }
      }
      `,
      variables () {
        return {
          id: this.boostId
        }
      },
      update: (response) => response.getBoost,
      loadingKey: 'loading'
    },
    connections: {
      query: gql`
      query getConnections {
        getConnections {
          totalCount
          contactConnections {
            id
            name
            type
            icon
            color
            isConnected
            count
            isUploadFileType
          }
          socialMediaConnections {
            id
            name
            type
            icon
            color
            isConnected
          }
        }
      }
      `,
      update: (response) => response.getConnections,
      loadingKey: 'loading'
    },
    contactsTable: {
      query: gql`
      query getContacts(
        $offset: Int!
        $countPerPage: Int!
        $sortColumn: String
        $isSortDesc: Boolean
        $search: String
      ) {
        getContacts(
          offset: $offset
          countPerPage: $countPerPage
          sortColumn: $sortColumn
          isSortDesc: $isSortDesc
          search: $search
        ) {
          totalCount
          data {
            id
            name
            email
            sourceType
          }
        }
      }
      `,
      variables () {
        return {
          offset: this.pagination.offset,
          countPerPage: this.pagination.countPerPage,
          sortColumn: this.sorting.column,
          isSortDesc: this.sorting.isSortDesc,
          search: this.searchQuery
        }
      },
      update: (response) => response.getContacts,
      loadingKey: 'loading'
    }
  },
  watch: {
    loading (value) {
      if (value !== 0) {
        this.$store.dispatch('loading/loading', true)
      } else {
        this.$store.dispatch('loading/loading', false)
      }

      if (value < 1) {
        this.$nextTick(() => {
          const anchor = this.$store.state.anchoring.anchor

          if (anchor) {
            window.scroll(0, anchor)
          } else {
            window.scroll(0, 0)
          }
        })
      }
    }
  },
  methods: {
    setAnchor () {
      const anchor = window.pageYOffset

      this.$store.dispatch('anchoring/setAnchor', anchor)
    },
    sendBoost () {
      this.$store.dispatch('loading/loading', true)

      this.$apollo.mutate({
        mutation: gql`
        mutation sendMarketingBoost($id: Int!) {
          sendMarketingBoost(id: $id) {
            id
            isSuccessful
            message
          }
        }
        `,
        variables: {
          id: this.boostCard.id
        }
      }).then((response) => {
        this.$store.dispatch('loading/loading', false)
        this.$refs.acceptTermsAndConditions.close()

        if (this.boostCard.sent) {
          this.$refs.success.open()
        } else {
          this.$refs.boostsSendMethodModal.open()
        }
      }).catch((response) => {
        this.$store.dispatch('loading/loading', false)
        this.$store.dispatch('states/setMessage', response.graphQLErrors[0].message)
        this.$store.dispatch('states/openSnackbar')
      })
    },
    confirmBoostSendMethod () {
      this.$store.dispatch('loading/loading', true)

      this.$apollo.mutate({
        mutation: gql`
        mutation editAccount($email: String!, $autoSend: Boolean) {
          editAccount (email: $email, autoSend: $autoSend) {
            id
            autoSend
          }
        }
        `,
        variables: {
          email: this.$store.state.auth.user.email,
          autoSend: this.autoSend
        }
      }).then((response) => {
        this.$store.dispatch('anchoring/setAnchor', false)
        this.$router.push({ name: 'myBoosts' })
      }).catch((response) => {
        this.$store.dispatch('loading/loading', false)
        this.$store.dispatch('states/setMessage', response.graphQLErrors[0].message)
        this.$store.dispatch('states/openSnackbar')
      })
    },
    addContact () {
      this.$store.dispatch('loading/loading', true)

      this.$apollo.mutate({
        mutation: gql`
        mutation createContact($firstName: String!, $lastName: String!, $email: String!) {
          createContact(firstName: $firstName, lastName: $lastName, email: $email) {
            id
          }
        }
        `,
        variables: {
          firstName: this.newContact.firstName,
          lastName: this.newContact.lastName,
          email: this.newContact.email
        },
        refetchQueries: [
          {
            query: gql`
            query getContacts(
              $offset: Int!
              $countPerPage: Int!
              $sortColumn: String
              $isSortDesc: Boolean
              $search: String
            ) {
              getContacts(
                offset: $offset
                countPerPage: $countPerPage
                sortColumn: $sortColumn
                isSortDesc: $isSortDesc
                search: $search
              ) {
                totalCount
                data {
                  id
                  name
                  email
                  sourceType
                }
              }
            }
            `,
            variables: {
              offset: this.pagination.offset,
              countPerPage: this.pagination.countPerPage,
              sortColumn: this.sorting.column,
              isSortDesc: this.sorting.isSortDesc,
              search: this.searchQuery
            }
          }
        ]
      }).then((response) => {
        this.$store.dispatch('loading/loading', false)
        this.$refs.addContact.close()
        this.message = 'We have added your contact successfully'
        this.$refs.state.open()
      }).catch((response) => {
        this.$store.dispatch('loading/loading', false)
        this.$store.dispatch('states/setMessage', response.graphQLErrors[0].message)
        this.$store.dispatch('states/openSnackbar')
      })
    },
    deleteRows (rows) {
      this.$store.dispatch('loading/loading', true)

      this.$apollo.mutate({
        mutation: gql`
        mutation deleteContact($ids: [Int]!) {
          deleteContact(ids: $ids) {
            isSuccessful
          }
        }
        `,
        variables: {
          ids: rows
        },
        refetchQueries: [
          {
            query: gql`
            query getContacts(
              $offset: Int!
              $countPerPage: Int!
              $sortColumn: String
              $isSortDesc: Boolean
              $search: String
            ) {
              getContacts(
                offset: $offset
                countPerPage: $countPerPage
                sortColumn: $sortColumn
                isSortDesc: $isSortDesc
                search: $search
              ) {
                totalCount
                data {
                  id
                  name
                  email
                  sourceType
                }
              }
            }
            `,
            variables: {
              offset: this.pagination.offset,
              countPerPage: this.pagination.countPerPage,
              sortColumn: this.sorting.column,
              isSortDesc: this.sorting.isSortDesc,
              search: this.searchQuery
            }
          }
        ]
      }).then((response) => {
        this.$store.dispatch('loading/loading', false)
        this.message = 'Your contacts have been deleted successfully'
        this.$refs.state.open()
      }).catch((response) => {
        this.$store.dispatch('loading/loading', false)
        this.$store.dispatch('states/setMessage', response.graphQLErrors[0].message)
        this.$store.dispatch('states/openSnackbar')
      })
    }
  },
  mounted () {
    // this.boostId = this.$route.params.boostId
    // this.boostId = this.$store.state.boostLibrary.selectedBoostId
    this.$ua.trackView('LaunchBoost', '/launchBoosts')
  }
}
</script>

<style lang="scss">
@import "../../assets/scss/variables";
@import "../../assets/scss/mixins";

.onboardinBoost-subheader {
  max-width:    750px;
  margin-left:  auto;
  margin-right: auto;
  font-weight:  400;
}

#acceptTermsAndConditions {
  .ui-modal__content {
    margin:  20px;
    padding: 40px 20px;
    @include media(md) {
      padding: 50px;
    }
  }

  p {
    max-width:   360px;
    color:       $grey-basic;
    font-size:   16px;
    font-weight: 400;
    line-height: 24px;
  }
}

#boostsSendMethodModal {
  .ui-modal__content {
    margin:         20px;
    display:        flex;
    flex-direction: column;
    align-items:    center;
  }

  p {
    max-width:   360px;
    margin:      0 0 30px;
    color:       $grey-basic;
    font-size:   16px;
    font-weight: 400;
    line-height: 24px;
    text-align:  center;
  }
}

#addContact {
  .ui-modal__content {
    padding: 0;
  }
}

#state {
  .ui-modal__content {
    margin:         20px;
    display:        flex;
    flex-direction: column;
    align-items:    center;
  }
}
</style>
