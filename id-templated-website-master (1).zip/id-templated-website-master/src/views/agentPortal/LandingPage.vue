<template>
  <div v-if="loading < 1" class="landingPage">

    <ui-layout id="launchWidget" wrap justify-center>
      <ui-header
        class="color-primary"
        top="10"
        bottom="10"
        fontSize="20"
      >
        Welcome Americo Agent!
      </ui-header>
      <p class="landingPage__description">
        Your <strong>Free Marketing Boost</strong> is ready to send.
      </p>
      <p class="landingPage__description">
        Once you are done previewing it, click below to send to your contacts through email and social media.
      </p>
      <ui-layout justify-center>
        <ui-button 
        success
        id="launchBtn"
        @click.native="$router.push({ name: 'verifyAccount' })">
          Launch Marketing Boost
        </ui-button>
      </ui-layout>
    </ui-layout>

    <ui-layout container justify-center>
      <ui-layout class="col-xs-12 col-md-7">
        <ui-boost-card
          :tags="boostCard.tags"
          :coverImage="boostCard.coverImage"
        />
      </ui-layout>
    </ui-layout>
    <ui-header
      alignCenter
      top="50"
      bottom="40"
      :style="{
        maxWidth: '700px',
        marginLeft: 'auto',
        marginRight: 'auto',
        padding: '0 20px'
      }"
    >
      {{ boostCard.title }}
    </ui-header>
    <div v-html="boostCard.text" class="landingPage__content"></div>
    <ui-layout justifyCenter>
      <ui-button
        success
        :style="{ marginTop: '24px', marginBottom: '170px' }"
        @click.native="$router.push({ name: 'verifyAccount' })"
      >
        Launch Marketing Boost
      </ui-button>
    </ui-layout>

    <!-- Modal -->
    <div v-show="showModal" class="howItWorksModal">
      <div class="howItWorksContent">
        <h1>How it works:</h1>

        <!-- Section 1 -->
        <ui-layout id="about-1" align-center wrap>
          <ui-layout class="col-xs-12 col-md-6 remove-left" align-center>
            <img :src="`/static/landing-1.png`">
          </ui-layout>
          <ui-layout class="col-xs-12 col-md-6 about-text" column>
            <span>Step 1: <br>Preview Your Boost</span>
            <p>Take a look and you'll see exactly what your marketing boost will look like before you send it</p>
          </ui-layout>
          <hr class="separator"></hr>
        </ui-layout>

        <!-- Section 2 -->
        <ui-layout id="about-2" align-center wrap>     
          <!-- Text -->
          <ui-layout class="col-xs-12 col-md-6 about-text" column>
            <span>Step 2: <br> Link Email & Social Media</span>
            <p>Choose exactly which email accounts and social media accounts you want to send your marketing boost through. Remember, the more you send, the better your results.</p>
          </ui-layout>
          <ui-layout class="col-xs-12 col-md-6 remove-right" align-center>
            <img :src="`/static/landing-2.png`">
          </ui-layout>
    
          <hr class="separator"></hr>
        </ui-layout>

        <!-- Section 3 -->
        <ui-layout id="about-3" align-center wrap>
          <ui-layout class="col-xs-12 col-md-6 about-image" align-center>
            <img  :src="`/static/landing-3.png`">
          </ui-layout>
          <ui-layout class="col-xs-12 col-md-6 about-text" column>
            <span>Step 3: <br> Send</span>
            <p>Once you're ready, click send and your Marketing Boost will be distributed.</p>
          </ui-layout>
          <hr class="separator"></hr>
        </ui-layout>

        <!-- Section 4 -->
        <ui-layout id="about-4" align-center wrap>
          <ui-layout class="col-xs-12 col-md-6 about-text" column>
            <span>Step 4: <br> Report</span>
            <p>Cutting edge reporting will show you all the results of the marketing boost. But don't worry! Only you can see your client’s contact information. This is not shared with Americo and your client’s information is kept safe from solicitors!</p>
          </ui-layout>
          <ui-layout class="col-xs-12 col-md-6 remove-right" align-center>
            <img id="about-4" :src="`/static/landing-4.png`">
          </ui-layout>

          <ui-layout justify-center>
            <ui-button
              success
              :style="{ marginTop: '50px', marginBottom: '70px' }"
              @click.native="showModal=0"
            >
              Got it!
            </ui-button>
          </ui-layout>
        </ui-layout>
      </div>
    </div>

  </div>
</template>

<script>
import gql from 'graphql-tag'

export default {
  name: 'AgentLangingPage',
  data () {
    return {
      showModal: 1,
      loading: 0,
      boostCard: {}
    }
  },
  apollo: {
    boostCard: {
      query: gql`
      query newestBoost {
        newestBoost {
          id
          coverImage
          title
          text
          date
          sent
          tags {
            text
            color {
              r
              g
              b
            }
          }
        }
      }
      `,
      update: (response) => response.newestBoost,
      loadingKey: 'loading'
    }
  },
  watch: {
    loading (value) {
      if (value !== 0) {
        this.$store.dispatch('loading/loading', true)
      } else {
        this.$store.dispatch('loading/loading', false)
      }
    }
  }
}
</script>

<style lang="scss">
@import '../../assets/scss/variables';
@import '../../assets/scss/mixins';

#launchWidget {

  @include media(md) {
    max-width: 43%;
    margin: 0 auto;
  }

  @include media(lg) {
    max-width: 100%;
    background-color: $grey-light;
    width: 275px;
    border-radius: 15px;
    border: 1px solid $grey-light;
    margin: 0 auto;
    position: fixed;
    z-index: 1;
    top: 110px;
    left: 20px;
    .ui-button {
      width: 100%;
    }
  }
  .ui-button {
    width: 100%;
    margin: 0 20px 20px 20px;
  }
}

.howItWorksModal {
  position: fixed;
  z-index: 1;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  overflow: auto;
  background-color: rgb(0,0,0);
  background-color: rgba(0,0,0,0.4);
}

.howItWorksContent {
  background-color: #f2f2f2;
  margin: 8% auto;
  border: 1px solid #888;
  border-radius: 5px;
  width: 100%;
  @include media(md) {
    width: 60% !important;
  }
  img {
    max-width: 100%;
  }
  h1 {
    text-align: center;
    font-size: 50px;
    color: $grey-dark;
  }
  span {
    color:          $grey-dark;
    font-size:      40px;
    font-weight:    300;
    line-height:    58px;
    letter-spacing: -1.54px; 
  }
  p {
    color:       $grey-dark;
    font-size:   22px;
    font-weight: 300;
    line-height: 32px;
  }
}

hr {
  margin-top: 35px;
  margin-bottom: 35px;
}

#about-2 .about-text, #about-4 .about-text {
  padding-left: 25px;
}

#about-3 img {
  max-height: 350px;
  margin: 0 auto
}

#about-3 .about-image {
  flex-basis: 40% !important;
}

.remove-left {
  padding-left: 0 !important;
}

.remove-right {
  padding-right: 0 !important;
}

.separator {
  width: 90%;
  border: 0; 
  height: 0; 
  border-top: 1px solid rgba(0, 0, 0, 0.1); 
  border-bottom: 1px solid rgba(255, 255, 255, 0.3);
}

.landingPage {
  &__description {
    margin:        0 auto;
    margin-bottom: 20px;
    padding:       0 20px 0 20px;
    max-width:     700px;
    color:         $grey-dark;
    text-align:    center;
  }

  &__content {
    margin:     0 auto;
    padding:    0 20px;
    max-width:  700px;
    color:      $grey-dark;
    text-align: center;

    * {
      color:       $grey-dark;
      font-size:   16px;
      font-weight: 400;
      line-height: 25px;
    }
  }

  .ui-boost-card {
    @include media(lg) {
      margin-top: 20px;
    }
  }

  .ui-boost-card__content {
    display: none;
  }
}
</style>
