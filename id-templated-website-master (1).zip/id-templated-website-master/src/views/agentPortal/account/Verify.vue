<template>
  <div>
    <ui-header align-center bottom="20">
      Account Verification
    </ui-header>
    <ui-subheader class="verifyAccount-subheader color-primary">
      Before you access your FREE Marketing Boost, please verify your Americo agent credentials
    </ui-subheader>
    <ui-layout container justify-center>
      <ui-layout class="col-xs-12 col-md-6">
        <ui-card fluid header="General Information">
          <ui-layout wrap align-end>
            <ui-layout class="col-xs-12">
              <ui-input
                fluid
                label="Please enter your Americo Agent ID"
                v-model="agentID"
              />
            </ui-layout>
            <ui-layout class="col-xs-12">
              <ui-input
                fluid
                label="Please enter the last 4 digits of your registered home phone number"
                v-model="verifyPhone"
              />
            </ui-layout>
            <ui-layout wrap class="col-xs-12" :style="{ marginTop: '10px' }">
              <ui-button success @click.native="verifyAccount()">
                Next
              </ui-button>
              <div class="form-login">
                Already verified?
                <router-link :to="{ name: 'login', params: {boostId: boostId} }">
                  Login here
                </router-link>
              </div>
            </ui-layout>
          </ui-layout>
        </ui-card>
      </ui-layout>
    </ui-layout>

    <ui-modal id="tutorialModal" ref="tutorialModal">
      <ui-header
        top="0"
        class="color-primary"
      >
        How it works
      </ui-header>
      <ui-subheader
        font-size="16"
        font-weight="700"
        top="30"
        bottom="10"
        class="color-grey-dark"
        align-left
        :style="{ padding: '0' }"
      >
        VERIFY YOUR CREDENTIALS
      </ui-subheader>
      <p>Let us know that you are an Americo agent who should have access to this FREE Marketing Boost</p>
      <ui-subheader
        font-size="16"
        font-weight="700"
        top="30"
        bottom="10"
        class="color-grey-dark"
        align-left
        :style="{ padding: '0' }"
      >
        CREATE YOUR ACCOUNT
      </ui-subheader>
      <p>Upload a picture your preferred contact information and secure it with a password</p>
      <ui-subheader
        font-size="16"
        font-weight="700"
        top="30"
        bottom="10"
        class="color-grey-dark"
        align-left
        :style="{ padding: '0' }"
      >
        PREVIEW, LINK & SEND
      </ui-subheader>
      <p>Preview exactly what your contacts will see, link whichever email & social media accounts you desire and send your FREE Marketing Boost</p>
      <ui-subheader
        font-size="16"
        font-weight="700"
        top="30"
        bottom="10"
        class="color-grey-dark"
        align-left
        :style="{ padding: '0' }"
      >
        REVIEW THE RESULTS
      </ui-subheader>
      <p>One week after your boost sends, you will receive a complete report that details who responded, where they found you and how many leads you generated</p>
      <ui-modal-actions justify-center>
        <ui-button success @click.native="$refs.tutorialModal.close()">
          Okay
        </ui-button>
      </ui-modal-actions>
    </ui-modal>
  </div>
</template>

<script>
import gql from 'graphql-tag'

export default {
  name: 'AgentVerifyAccount',
  data () {
    return {
      agentID: '',
      verifyPhone: '',
      boostId: ''
    }
  },
  mounted () {
    // Commented out for now, will remove or uncomment
    // after status is more stable.
    // this.$refs.tutorialModal.open()
    this.$ua.trackView('VerifyAccount', '/verifyAccount')
    this.boostId = this.$route.query.boostId
  },
  methods: {
    verifyAccount () {
      this.$store.dispatch('loading/loading', true)

      this.$apollo.mutate({
        mutation: gql`
        mutation verifyAccount(
          $verifyPhone: String!,
          $agentID: String!
        ) {
          verifyAccount(
            verifyPhone: $verifyPhone,
            agentID: $agentID
          ) {
            id
            email
            phone
          }
        }
        `,
        variables: {
          verifyPhone: this.verifyPhone,
          agentID: this.agentID
        }
      }).then((response) => {
        this.$store.dispatch('loading/loading', false)
        this.$router.push({
          name: 'createAccount',
          params: { id: response.data.verifyAccount.id }
        })
      }).catch((response) => {
        this.$store.dispatch('loading/loading', false)
        this.$store.dispatch('states/setMessage', response.graphQLErrors[0].message)
        this.$store.dispatch('states/openSnackbar')
      })
    }
  }
}
</script>

<style lang="scss" scoped>
@import '../../../assets/scss/variables';

.verifyAccount-subheader {
  max-width:    500px;
  margin-left:  auto;
  margin-right: auto;
}

.form-login {
  width:         100%;
  margin-top:    20px;
  margin-bottom: 6px;
  font-size:     14px;
  font-weight:   400;
  color:         $grey-dark;

  a {
    color:           $link-classic;
    text-decoration: underline;
  }
}

#tutorialModal p {
  max-width: 360px;
  color:     $grey-basic;
}
</style>
