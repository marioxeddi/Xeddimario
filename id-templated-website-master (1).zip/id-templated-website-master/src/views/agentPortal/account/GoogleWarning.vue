<!-- Backup code for previously use Google Warning -->

        <ui-layout wrap>
          <ui-layout ui-layout col-xs-12 col-sm-3 col-md-2 style="padding-left:10px; padding-right:10px">
            <ui-layout
              id="gmailButton"
              class="ui-social-card__button"
              @click.native="$refs.gmail.open()"
            >
              Have Gmail? Click here first
            </ui-layout>
          </ui-layout>
        </ui-layout>

<!-- Google help button/ modal -->
          <ui-modal id="gmail" ref="gmail">
            <p>
              When connecting your Google account, if you see this warning message, follow the below steps in order to connect:
            </p>
            <img class="gmail-warning-image" :src="'/static/google_1.png'" />
            <img class="gmail-warning-image" :src="'/static/google_2.png'" />
            <img class="gmail-warning-image" :src="'/static/google_3.png'" />

            <ui-modal-actions justify-center>
              <ui-button
                success
                @click.native="$refs.gmail.close()"
              >
                Close
              </ui-button>
            </ui-modal-actions>
          </ui-modal>



#gmailButton {
  background: rgb(172, 61, 49);
  max-width: 100%;
  width: 100%;
  margin-bottom: 10px;
  padding-left: 10px;
  padding-right: 10px;
  @include media(md) {
    max-width: 15%;
    float: left;
  }
}

#gmail {
  p {
    font-size: 24px;
    color: $grey-dark;
    @include media(sm) {
      font-size: 12px;
    }
    @include media(md) {
      font-size: 18px;
    }
    @include media(lg) {
      font-size: 24px;
    }
  }
  img {
    border: 1px solid $grey-dark;
    display: block;
    margin: 0 auto;
    margin-top: 30px;
    margin-bottom: 30px;
    max-width: 100%;
  }
  button {
    margin-bottom: 30px;
  }
}