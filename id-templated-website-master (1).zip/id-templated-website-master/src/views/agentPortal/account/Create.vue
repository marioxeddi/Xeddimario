<template>
  <div>
    <ui-header align-center bottom="20">
      Create Account
    </ui-header>
    <ui-subheader class="color-primary">
      Add your picture and info so your digital community will recognize you!
    </ui-subheader>
    <ui-layout container justify-center>
      <ui-layout class="col-xs-12 col-md-6">
        <ui-card fluid header="General Information">
          <ui-layout wrap align-end>
            <ui-layout class="col-xs-12">
              <ui-avatar
                uploadable
                id="createAccountAvatar"
                v-model="profilePicture"
              />
            </ui-layout>
            <p class="createAccountTooltip">
              Please confirm what email and phone number you want listed on your marketing boosts for consumers to contact you
            </p>
            <ui-layout class="col-xs-12">
              <ui-input
                fluid
                label="First name"
                v-model="firstName"
              />
            </ui-layout>
            <ui-layout class="col-xs-12">
              <ui-input
                fluid
                label="Last name"
                v-model="lastName"
              />
            </ui-layout>
            <ui-layout class="col-xs-12">
              <ui-input
                fluid
                validation
                label="E-mail"
                v-model="email"
                :valid="validation.email"
                @blur="checkEmail(), warnEmail()"

              />
            </ui-layout>
            <ui-layout class="col-xs-12">
              <ui-input
                fluid
                validation
                type="tel"
                label="Phone number"
                mask="###-###-####"
                v-model="phone"
                :valid="validation.phone"
                
              />
            </ui-layout>
            <ui-layout class="col-xs-12">
              <ui-input
                fluid
                validation
                type="password"
                label="New password"
                tooltip="Use at least 8 characters. Don’t use a password from another site, or something too obvious like your pet’s name."
                v-model="password"
                :valid="validation.password"
              />
            </ui-layout>
            <ui-layout class="col-xs-12">
              <ui-input
                fluid
                validation
                type="password"
                label="Confirm password"
                v-model="confirmPassword"
                :valid="validation.confirmPassword"
              />
            </ui-layout>
            <!-- <ui-layout class="col-xs-12" :style="{ marginTop: '10px' }">
              <ui-button outline @click.native="uploadPhoto()">
                Try photo upload
              </ui-button>
            </ui-layout> -->
            <ui-layout class="col-xs-12" :style="{ marginTop: '10px' }">
              <ui-button success @click.native="confirm()">
                Access Marketing Boost
              </ui-button>
            </ui-layout>
          </ui-layout>
        </ui-card>
      </ui-layout>
    </ui-layout>


    <!-- Email Warning -->
    <ui-modal id="warnEmail" ref="warnEmail">
      <ui-subheader
        font-size="18"
        font-weight="700"
        class="color-grey-dark"
        align-center
        :style="{ padding: '0' }"
      >
        Email Warning
      </ui-subheader>
      <p>
        Email cannot be @aol.com or @yahoo.com. Security restrictions with Yahoo and AOL do not allow this technology.
      </p>
      <br />
      <p><br /><b>
        Please use an alternate email to send out your marketing boost.
      </b></p>
      <br />
      <p><br />
        Don't worry, you can still sync your contacts from AOL and Yahoo, you just need to send it from a different email address.
      </p>
        <ui-modal-actions justify-center>
          <ui-button success @click.native="$refs.warnEmail.close()">
            Ok
          </ui-button>
        </ui-modal-actions>
      </ui-layout>
    </ui-modal>

    <ui-modal id="emailRecognized" ref="emailRecognized">
      <ui-subheader
        font-size="18"
        font-weight="700"
        class="color-grey-dark"
        align-left
        :style="{ padding: '0' }"
      >
        E-mail recognized
      </ui-subheader>
      <p>
        We recognize your email address as having an active Agent account with InsuranceDrip. You can use your same login credentials with this recognized email address for this new account.
      </p>
      <label>E-mail</label>
      <div class="modalEmail">
        {{ email }}
      </div>
      <ui-input v-model="modalPassword" type="password" label="Password" fluid />
      <ui-layout justify-space-between :style="{ marginTop: '40px' }">
        <button class="forgotPassword" @click="sendResetPasswordEmail()">
          I forgot my password
        </button>
        <ui-button success @click.native="login()">
          Log in
        </ui-button>
      </ui-layout>
    </ui-modal>

    <ui-modal id="passwordResetEmailSent" ref="passwordResetEmailSent">
      <ui-icon border>check</ui-icon>
      <ui-subheader
        bottom="40"
        font-size="18"
        font-weight="700"
        class="color-grey-dark"
        :style="{ padding: '0' }"
      >
        We have sent you an email with a link to change your password.<br>
        Please check your inbox.
      </ui-subheader>
      <ui-button outline @click.native="$refs.passwordResetEmailSent.close()">
        Close
      </ui-button>
    </ui-modal>
  </div>
</template>

<script>
import gql from 'graphql-tag'
import * as axios from 'axios'

export default {
  name: 'AgentCreateAccount',
  data () {
    return {
      boostId: '',
      profilePicture: null,
      firstName: '',
      lastName: '',
      email: '',
      phone: '',
      password: '',
      confirmPassword: '',
      modalPassword: '',
      uploadedImage: null,
      validation: {
        email: false,
        password: false,
        confirmPassword: false
      }
    }
  },
  watch: {
    email (value) {
      const regexp = new RegExp('^([a-zA-Z0-9-_.+]+)@((?!aol|yahoo)(([a-zA-Z0-9-]+)+))[.]([a-zA-Z]{2,4}|[0-9]{1,3})$')
      this.validation.email = regexp.test(value)
    },
    password (value) {
      this.validation.password = value.length >= 8
      this.validation.confirmPassword = this.confirmPassword === value
    },
    confirmPassword (value) {
      if (!this.password) {
        this.validation.password = false
        this.validation.confirmPassword = false
      } else if (value === this.password) {
        this.validation.confirmPassword = true
      } else {
        this.validation.confirmPassword = false
      }
    },
    phone (value) {
      if (value.length !== 12) {
        this.validation.phone = false
      } else {
        this.validation.phone = true
      }
    }
  },
  mounted () {
    this.$store.dispatch('loading/loading', false)
    this.$store.dispatch('anchoring/setAnchor', false)
    this.$ua.trackView('CreateAccount', '/createAccount')
    this.boostId = this.$route.params.boostId
  },
  methods: {
    warnEmail () {
      if (this.email.length > 0 && this.validation.email === false) {
        this.$refs.warnEmail.open()
      }
    },
    checkEmail () {
      if (this.email) {
        this.$apollo.query({
          query: gql`
          query doesAgentEmailExist($email: String!) {
            doesAgentEmailExist(email: $email) {
              value
            }
          }
          `,
          variables: {
            email: this.email
          }
        }).then((response) => {
          if (response.data.doesAgentEmailExist.value) {
            this.$refs.emailRecognized.open()
          }
        }).catch((response) => {
          this.$store.dispatch('states/setMessage', response.graphQLErrors[0].message)
          this.$store.dispatch('states/openSnackbar')
        })
      }
    },
    sendResetPasswordEmail () {
      this.$store.dispatch('loading/loading', true)

      this.$apollo.mutate({
        mutation: gql`
        mutation requestPasswordResetEmail($email: String!) {
          requestPasswordResetEmail(email: $email) {
            id
          }
        }
        `,
        variables: {
          email: this.email
        }
      }).then((response) => {
        this.$store.dispatch('loading/loading', false)
        this.$refs.emailRecognized.close()
        this.$refs.passwordResetEmailSent.open()
      }).catch((response) => {
        this.$store.dispatch('loading/loading', false)
        this.$store.dispatch('states/setMessage', response.graphQLErrors[0].message)
        this.$store.dispatch('states/openSnackbar')
      })
    },
    login () {
      const loginData = {
        email: this.email,
        password: this.modalPassword,
        id: this.$route.params.id
        // templateId: this.$route.params.templateId
      }

      this.$store.dispatch('loading/loading', true)

      this.$store.dispatch('auth/login', loginData).then((response) => {
        this.$store.dispatch('loading/loading', false)
        this.$router.push({ name: 'launchBoost', params: { boostId: this.boostId } })
        if (this.boostId) {
          this.$router.push({ name: 'launchBoost', params: { boostId: this.boostId } })
        } else {
          this.$router.push({ name: 'landingPage' })
        }
      }).catch((response) => {
        this.$store.dispatch('loading/loading', false)
        this.$store.dispatch('states/setMessage', response.graphQLErrors[0].message)
        this.$store.dispatch('states/openSnackbar')
      })
    },
    confirm () {
      if (this.validation.email && this.validation.password && this.validation.confirmPassword) {
        if (this.profilePicture) {
          this.uploadPhoto()
        } else {
          this.createAccount()
        }
      } else {
        this.$store.dispatch('states/setMessage', 'Credentials are invalid, please enter valid credentials.')
        this.$store.dispatch('states/openSnackbar')
      }
    },
    uploadPhoto () {
      this.$store.dispatch('loading/loading', true)

      this.$apollo.query({
        query: gql`
        query requestFileUploadToken {
          requestFileUploadToken {
            postUrl
          }
        }
        `
      }).then((response) => {
        const url = response.data.requestFileUploadToken.postUrl
        axios.post(url, { imageData: this.profilePicture }).then((response2) => {
          this.uploadedImage = response2.data.getUrl
          this.createAccount()
        }).catch(() => {
          this.$store.dispatch('loading/loading', false)
          this.$store.dispatch('states/setMessage', 'The image upload failed. Please try repeating the action.')
          this.$store.dispatch('states/openSnackbar')
        })
      }).catch((response) => {
        this.$store.dispatch('loading/loading', false)
        this.$store.dispatch('states/setMessage', response.graphQLErrors[0].message)
        this.$store.dispatch('states/openSnackbar')
      })
    },
    createAccount () {
      this.$store.dispatch('loading/loading', true)

      this.$apollo.query({
        query: gql`
        query doesAgentEmailExist($email: String!) {
          doesAgentEmailExist(email: $email) {
            value
          }
        }
        `,
        variables: {
          email: this.email
        }
      }).then((response) => {
        if (response.data.doesAgentEmailExist.value) {
          this.$refs.emailRecognized.open()
        } else {
          this.$apollo.mutate({
            mutation: gql`
            mutation createAccount(
              $id: Int!
              $profilePhoto: String
              $firstName: String!
              $lastName: String!
              $email: String!
              $phone: String
              $password: String!
              $confirmPassword: String!
              $templateId: Int 
            ) {
              createAccount(
                id: $id
                profilePhoto: $profilePhoto
                firstName: $firstName
                lastName: $lastName
                email: $email
                phone: $phone
                password: $password
                confirmPassword: $confirmPassword
                templateId: $templateId
              ) {
                id
                authToken
                profilePhoto
                firstName
                lastName
                email
                phone
                autoSend
              }
            }
            `,
            variables: {
              id: this.$route.params.id,
              profilePhoto: this.uploadedImage,
              firstName: this.firstName,
              lastName: this.lastName,
              email: this.email,
              phone: this.phone,
              password: this.password,
              confirmPassword: this.confirmPassword,
              templateId: this.$route.params.templateId
            }
          }).then((response) => {
            const dataForStore = {
              email: this.email,
              password: this.password
            }

            this.$store.dispatch('auth/logout')
            this.$store.dispatch('auth/login', dataForStore).then((response2) => {
              this.$store.dispatch('loading/loading', false)

              if (response2.success) {
                this.$router.push({ name: 'launchBoost' })
                // this.$router.push({ name: 'launchBoost', params: { boostId: this.boostId } })
                // if (this.boostId) {
                //   // This one should point to 'launchBoost'
                //   this.$router.push({ name: 'launchBoost', params: { boostId: this.boostId } })
                // } else {
                //   this.$router.push({ name: 'landingPage' })
                // }
              } else {
                this.$store.dispatch('states/setMessage', 'The account creation was successful, but we encountered an error during the auth process.')
                this.$store.dispatch('states/openSnackbar')
              }
            }).catch((response) => {
              this.$store.dispatch('loading/loading', false)
              this.$store.dispatch('states/setMessage', response.graphQLErrors[0].message)
              this.$store.dispatch('states/openSnackbar')
            })
          }).catch((response) => {
            this.$store.dispatch('loading/loading', false)
            this.$store.dispatch('states/setMessage', response.graphQLErrors[0].message)
            this.$store.dispatch('states/openSnackbar')
          })
        }
      }).catch((response) => {
        this.$store.dispatch('states/setMessage', response.graphQLErrors[0].message)
        this.$store.dispatch('states/openSnackbar')
      })
    }
  }
}
</script>

<style lang="scss" scoped>
@import '../../../assets/scss/variables';

.createAccountTooltip {
  margin:      20px 10px;
  color:       $grey-dark;
  font-size:   14px;
  font-weight: 400;
  line-height: 21px;
}
</style>

<style lang="scss">
@import '../../../assets/scss/variables';

#warnEmail {
  .ui-modal__content {
    margin:         20px;
    display:        flex;
    flex-direction: column;
    align-items:    center
  }

  p {
    max-width:   360px;
    margin:      0;
    color:       $grey-basic;
    font-size:   16px;
    font-weight: 400;
    line-height: 24px;
  }
}

#emailRecognized {
  .ui-modal__content {
    max-width: 450px;
  }

  .modalEmail {
    margin-bottom: 30px;
    color:         $grey-dark;
    font-size:     14px;
    font-weight:   500;
  }

  .forgotPassword {
    color:       $link-classic;
    font-size:   14px;
    font-weight: 400;
    line-height: 16px;
  }

  p {
    margin-bottom: 30px;
    color:         $grey-basic;
    font-size:     16px;
    font-weight:   400;
    line-height:   24px;
  }

  label {
    margin-bottom: 10px;
    color:         $grey-basic;
    font-size:     14px;
    font-weight:   400;
    line-height:   14px;
    display:       block;
  }
}

#passwordResetEmailSent {
  text-align: center;

  .ui-icon {
    margin-bottom: 50px;
  }
}
</style>
