<template></template>

<script>
import gql from 'graphql-tag'

export default {
  name: 'LinkAccountSyncHandler',
  mounted () {
    const substring = window.location.search.substring(1)
    const paramsArray = substring.split('&')
    const key = paramsArray[0].split('=')[0]

    let paramsObject = {
      code: paramsArray[0] ? paramsArray[0].split('=')[1] : null,
      code2: paramsArray[1] ? paramsArray[1].split('=')[1] : null
    }

    if (key !== 'code' && key !== 'oauth_token') {
      this.$router.push({ name: this.$route.params.redirectURL })
    } else {
      this.$apollo.mutate({
        mutation: gql`
        mutation linkAccount(
          $type: String!,
          $redirectUrl: String!,
          $code: String,
          $code2: String
        ) {
          linkAccount(
            type: $type,
            redirectUrl: $redirectUrl,
            code: $code,
            code2: $code2
          ) {
            id
            isSuccessful
            message
          }
        }
        `,
        variables: {
          type: this.$route.params.type,
          redirectUrl: `${window.location.origin}/syncHandler/${this.$route.params.redirectURL}/${this.$route.params.type}`,
          code: paramsObject.code,
          code2: paramsObject.code2
        }
      }).then((response) => {
        this.$router.push({ name: this.$route.params.redirectURL })
      }).catch((response) => {
        this.$store.dispatch('states/setMessage', response.graphQLErrors[0].message)
        this.$store.dispatch('states/openSnackbar')
      })
    }
  }
}
</script>
