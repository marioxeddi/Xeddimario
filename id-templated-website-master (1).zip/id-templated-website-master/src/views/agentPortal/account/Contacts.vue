<template>
  <div v-if="loading < 1">
    <ui-layout container :style="{ marginTop: '50px', marginBottom: '255px' }">

      <!-- Load Contacts -->
      <ui-card
        fluid
        header="Load Contacts"
      >
        <ui-layout wrap>
          <ui-layout ui-layout col-xs-12 col-sm-3 col-md-2 style="padding-left:10px; padding-right:10px">
          </ui-layout>
        </ui-layout>
        <ui-layout wrap>
          <ui-layout
            v-for="contactCard in contactCards.contactConnections"
            :key="contactCard.name"
            class="col-xs-12 col-sm-3 col-md-2"
          >
            <ui-social-card
              :id="contactCard.id"
              :name="contactCard.name"
              :type="contactCard.type"
              :icon="contactCard.icon"
              :color="contactCard.color"
              :connected="contactCard.isConnected"
              :count="contactCard.count"
              :isUploadFileType="contactCard.isUploadFileType"
            />
        </ui-layout>
          
          <ui-table
            card-table
            searchable
            deletable
            custom-action="+ Add Contact"
            custom-action-icon="add"
            pagination
            :offset="pagination.offset"
            :countPerPage="pagination.countPerPage"
            :totalCount="contactsTable.totalCount"
            :fields="contactsTableFields"
            :data="contactsTable.data"
            :search-query="searchQuery"
            :sorting="sorting"
            @customAction="$refs.addContact.open()"
            @search="searchQuery = $event"
            @sort="sorting = $event"
            @delete="deleteRows"
            @changeCountPerPage="pagination.countPerPage = $event"
            @prev="pagination.offset = $event"
            @next="pagination.offset = $event"
          />
          <!-- <ui-subheader top="50" bottom="20" class="color-primary">
            There aren't any contacts added yet. Add contacts to be able to send marketing boosts via email.
          </ui-subheader> -->
        </ui-layout>
      </ui-card>
    </ui-layout>

    <ui-modal id="addContact" ref="addContact">
      <ui-card header="Add New Contact">
        <ui-layout wrap>
          <ui-layout class="col-xs-12 col-md-6">
            <ui-input
              v-model="newContact.firstName"
              label="First name"
              fluid
            />
          </ui-layout>
          <ui-layout class="col-xs-12 col-md-6">
            <ui-input
              v-model="newContact.lastName"
              label="Last name"
              fluid
            />
          </ui-layout>
          <ui-layout class="col-xs-12">
            <ui-input
              v-model="newContact.email"
              label="E-mail"
              fluid
            />
          </ui-layout>
          <ui-layout class="col-xs-12" justify-end :style="{ marginTop: '15px' }">
            <ui-button
              dense
              outline
              @click.native="$refs.addContact.close()"
              :style="{ marginRight: '10px' }"
            >
              Cancel
            </ui-button>
            <ui-button
              dense
              success
              @click.native="addContact()"
            >
              Add Contact
            </ui-button>
          </ui-layout>
        </ui-layout>
      </ui-card>
    </ui-modal>
    <ui-modal id="state" ref="state">
      <ui-icon border>check</ui-icon>
      <ui-subheader
        font-size="18"
        font-weight="500"
        top="30"
        bottom="10"
        class="color-grey-dark"
      >
        {{ message }}
      </ui-subheader>
      <ui-modal-actions justify-center>
        <ui-button outline @click.native="$refs.state.close()">
          Close
        </ui-button>
      </ui-modal-actions>
    </ui-modal>
  </div>
</template>

<script>
import gql from 'graphql-tag'

export default {
  name: 'AgentContacts',
  data () {
    return {
      loading: 0,
      message: '',
      searchQuery: '',
      contactCards: [],
      contactsTable: [],
      contactsTableFields: [
        {
          name: 'name',
          header: 'Name'
        },
        {
          name: 'email',
          header: 'E-mail'
        },
        {
          name: 'sourceType',
          header: 'Source'
        }
      ],
      newContact: {
        firstName: '',
        lastName: '',
        email: ''
      },
      pagination: {
        offset: 0,
        countPerPage: 50
      },
      sorting: {
        column: 'name',
        isSortDesc: true
      }
    }
  },
  apollo: {
    contactCards: {
      query: gql`
      query getConnections {
        getConnections {
          totalCount
          contactConnections {
            id
            name
            type
            icon
            color
            isConnected
            count
            isUploadFileType
          }
        }
      }
      `,
      update: (response) => response.getConnections,
      loadingKey: 'loading'
    },
    contactsTable: {
      query: gql`
      query getContacts(
        $offset: Int!
        $countPerPage: Int!
        $sortColumn: String
        $isSortDesc: Boolean
        $search: String
      ) {
        getContacts(
          offset: $offset
          countPerPage: $countPerPage
          sortColumn: $sortColumn
          isSortDesc: $isSortDesc
          search: $search
        ) {
          totalCount
          data {
            id
            name
            email
            sourceType
          }
        }
      }
      `,
      variables () {
        return {
          offset: this.pagination.offset,
          countPerPage: this.pagination.countPerPage,
          sortColumn: this.sorting.column,
          isSortDesc: this.sorting.isSortDesc,
          search: this.searchQuery
        }
      },
      update: (response) => response.getContacts,
      loadingKey: 'loading'
    }
  },
  watch: {
    loading (value) {
      if (value !== 0) {
        this.$store.dispatch('loading/loading', true)
      } else {
        this.$store.dispatch('loading/loading', false)
      }
    }
  },
  methods: {
    addContact () {
      this.$store.dispatch('loading/loading', true)

      this.$apollo.mutate({
        mutation: gql`
        mutation createContact($firstName: String!, $lastName: String!, $email: String!) {
          createContact(firstName: $firstName, lastName: $lastName, email: $email) {
            id
          }
        }
        `,
        variables: {
          firstName: this.newContact.firstName,
          lastName: this.newContact.lastName,
          email: this.newContact.email
        },
        refetchQueries: [
          {
            query: gql`
            query getContacts(
              $offset: Int!
              $countPerPage: Int!
              $sortColumn: String
              $isSortDesc: Boolean
              $search: String
            ) {
              getContacts(
                offset: $offset
                countPerPage: $countPerPage
                sortColumn: $sortColumn
                isSortDesc: $isSortDesc
                search: $search
              ) {
                totalCount
                data {
                  id
                  name
                  email
                  sourceType
                }
              }
            }
            `,
            variables: {
              offset: this.pagination.offset,
              countPerPage: this.pagination.countPerPage,
              sortColumn: this.sorting.column,
              isSortDesc: this.sorting.isSortDesc,
              search: this.searchQuery
            }
          }
        ]
      }).then((response) => {
        this.$store.dispatch('loading/loading', false)
        this.$refs.addContact.close()
        this.message = 'We have added your contact successfully'
        this.$refs.state.open()
      }).catch((response) => {
        this.$store.dispatch('loading/loading', false)
        this.$store.dispatch('states/setMessage', response.graphQLErrors[0].message)
        this.$store.dispatch('states/openSnackbar')
      })
    },
    deleteRows (rows) {
      this.$store.dispatch('loading/loading', true)

      this.$apollo.mutate({
        mutation: gql`
        mutation deleteContact($ids: [Int]!) {
          deleteContact(ids: $ids) {
            isSuccessful
          }
        }
        `,
        variables: {
          ids: rows
        },
        refetchQueries: [
          {
            query: gql`
            query getContacts(
              $offset: Int!
              $countPerPage: Int!
              $sortColumn: String
              $isSortDesc: Boolean
              $search: String
            ) {
              getContacts(
                offset: $offset
                countPerPage: $countPerPage
                sortColumn: $sortColumn
                isSortDesc: $isSortDesc
                search: $search
              ) {
                totalCount
                data {
                  id
                  name
                  email
                  sourceType
                }
              }
            }
            `,
            variables: {
              offset: this.pagination.offset,
              countPerPage: this.pagination.countPerPage,
              sortColumn: this.sorting.column,
              isSortDesc: this.sorting.isSortDesc,
              search: this.searchQuery
            }
          }
        ]
      }).then((response) => {
        this.$store.dispatch('loading/loading', false)
        this.message = 'Your contacts have been deleted successfully'
        this.$refs.state.open()
      }).catch((response) => {
        this.$store.dispatch('loading/loading', false)
        this.$store.dispatch('states/setMessage', response.graphQLErrors[0].message)
        this.$store.dispatch('states/openSnackbar')
      })
    }
  },
  mounted () {
    this.$ua.trackView('Contacts', '/contacts')
  }
}
</script>

<style lang="scss">
@import '../../../assets/scss/variables';
@import '../../../assets/scss/mixins';

@media screen and (max-width: 768px) {
  .ui-social-card {
    margin: 10px 0;
  }
}

#addContact {
  .ui-modal__content {
    padding: 0;
  }
}

#state {
  .ui-modal__content {
    margin:         20px;
    display:        flex;
    flex-direction: column;
    align-items:    center;
  }
}



</style>
