<template>
  <ui-layout wrap container :style="{ marginTop: '50px' }">
    <ui-layout class="col-xs-12" :style="{ marginBottom: '20px' }">
      <ui-card fluid header="My Account">
        <ui-layout wrap :style="{ maxWidth: 'calc(100% + 80px)', margin: '0 -40px' }">
          <ui-layout class="col-xs-12" :style="{ padding: '0 50px' }">
            <ui-avatar
              uploadable
              id="myAccountAvatar"
              v-model="imageToUpload"
              :src="profilePhoto"
            />
          </ui-layout>
          <ui-layout
            column
            class="col-xs-12 col-md-6"
            :style="{ padding: '0 50px' }"
          >
            <ui-form-header>Account Information</ui-form-header>
            <ui-layout wrap :style="{ maxWidth: 'calc(100% + 40px)', margin: '0 -10px' }">
              <ui-layout class="col-xs-12 col-md-6">
                <ui-input @input="detectFormChanges" v-model="firstName" label="First name" fluid />
              </ui-layout>
              <ui-layout class="col-xs-12 col-md-6">
                <ui-input @input="detectFormChanges" v-model="lastName" label="Last name" fluid />
              </ui-layout>
            </ui-layout>
            <ui-input
              fluid
              validation
              label="E-mail"
              v-model="email"
              :valid="validation.email"
            />
            <ui-input @input="detectFormChanges" v-model="phone" label="Phone number" mask="###-###-####" fluid />
          </ui-layout>
          <ui-layout
            column
            class="col-xs-12 col-md-6"
            :style="{ padding: '0 50px' }"
          >
            <ui-form-header>Change Password</ui-form-header>
            <ui-input
              fluid
              validation
              type="password"
              label="New password"
              tooltip="Use at least 8 characters. Don’t use a password from another site, or something too obvious like your pet’s name."
              v-model="password"
              :valid="validation.password"
              @input="detectFormChanges"
            />
            <ui-input
              fluid
              validation
              type="password"
              label="Confirm new password"
              v-model="confirmPassword"
              :valid="validation.confirmPassword"
              @input="detectFormChanges"
            />
            <ui-form-header>Boosts Send Out</ui-form-header>
            <ui-checkbox v-model="autoSend" label="Send automatically" id="boostsSendMethod" />
            <!-- <ui-radio :options="" name="boostsSendOut"><ui-radio> -->
          </ui-layout>
        </ui-layout>
        <ui-layout justify-end class="col-xs-12" :style="{ marginTop: '40px' }">
          <ui-button @click.native="save()" success>Save Changes</ui-button>
        </ui-layout>
      </ui-card>
    </ui-layout>
    <ui-layout class="col-xs-12">
      <ui-card
        fluid
        header="Link Social Media"
        :style="{ marginBottom: '50px' }"
      >
        <ui-layout wrap>
          <ui-layout
            v-for="socialCard in socialCards.socialMediaConnections"
            :key="socialCard.name"
            class="col-xs-12 col-sm-6 col-md-2"
          >
            <ui-social-card
              :id="socialCard.id"
              :name="socialCard.name"
              :type="socialCard.type"
              :icon="socialCard.icon"
              :color="socialCard.color"
              :connected="socialCard.isConnected"
              :count="null"
              :isUploadFileType="socialCard.isUploadFileType"
            />
          </ui-layout>
        </ui-layout>
      </ui-card>
    </ui-layout>

    <ui-modal id="saveSuccess" ref="saveSuccess">
      <ui-icon border>check</ui-icon>
      <ui-subheader
        font-size="16"
        font-weight="700"
        top="30"
        bottom="10"
        class="color-grey-dark"
      >
        Success
      </ui-subheader>
      <p>Changes to your settings have been saved.</p>
      <ui-modal-actions justify-center>
        <ui-button outline @click.native="$refs.saveSuccess.close()">
          Close
        </ui-button>
      </ui-modal-actions>
    </ui-modal>

    <!-- Open if user navigates without saving changes -->
    <ui-modal id="unsavedChanges" ref="unsavedChanges" >
      <ui-subheader
        font-size="16"
        font-weight="700"
        top="30"
        bottom="10"
        class="color-grey-dark"
      >
        Warning:
      </ui-subheader>
      <p>You have made changes to your information.<br>You can save these changes now, or continue without saving.</p>
        <ui-modal-actions justify-center>
          <ui-button outline @click.native="continueNavigation()">
            Continue
          </ui-button>
          <ui-button outline @click.native="save()">
            Save
          </ui-button>
      </ui-modal-actions>
    </ui-modal>
  </ui-layout>
</template>

<script>
import gql from 'graphql-tag'
import * as axios from 'axios'

export default {
  name: 'AgentMyAccount',
  beforeRouteLeave (to, from, next) {
    if (this.dirtyForm === true) {
      this.$refs.unsavedChanges.open()
    } else {
      next()
    }
  },
  data () {
    return {
      loading: 0,
      profilePhoto: this.$store.state.auth.user.profilePhoto,
      firstName: this.$store.state.auth.user.firstName,
      lastName: this.$store.state.auth.user.lastName,
      email: this.$store.state.auth.user.email,
      phone: this.$store.state.auth.user.phone,
      password: '',
      confirmPassword: '',
      autoSend: this.$store.state.auth.user.autoSend,
      dirtyForm: false,
      validation: {
        email: true,
        password: true,
        confirmPassword: true
      },
      socialCards: [],
      imageToUpload: null,
      uploadedImage: null
      // radioOptions: [
      //   {
      //     value: 1,
      //     name: 'Send All Automatically'
      //   },
      //   {
      //     value: 2,
      //     name: 'Send Manually'
      //   }
      // ]
    }
  },
  apollo: {
    socialCards: {
      query: gql`
      query getConnections {
        getConnections {
          socialMediaConnections {
            id
            name
            type
            icon
            color
            isConnected
          }
        }
      }
      `,
      update: (response) => response.getConnections,
      loadingKey: 'loading'
    }
  },
  watch: {
    loading (value) {
      if (value !== 0) {
        this.$store.dispatch('loading/loading', true)
      } else {
        this.$store.dispatch('loading/loading', false)
      }
    },
    email (value) {
      const regexp = new RegExp('^([a-zA-Z0-9-_.]+)@((?!aol|yahoo)(([a-zA-Z0-9-]+)+))[.]([a-zA-Z]{2,4}|[0-9]{1,3})$')

      this.validation.email = regexp.test(value)
    },
    password (value) {
      this.validation.password = value.length >= 8
      this.validation.confirmPassword = this.confirmPassword === value
    },
    confirmPassword (value) {
      if (!this.password) {
        this.validation.password = false
        this.validation.confirmPassword = false
      } else if (value === this.password) {
        this.validation.confirmPassword = true
      } else {
        this.validation.confirmPassword = false
      }
    }
  },
  methods: {
    detectFormChanges () {
      this.dirtyForm = true
    },
    continueNavigation () {
      this.dirtyForm = false
      this.$refs.unsavedChanges.close()
    },
    saveAndClose () {
      this.save()
    },
    save () {
      this.$refs.unsavedChanges.close()
      this.dirtyForm = false
      console.log(this.dirtyForm)
      if (this.validation.email && this.validation.password && this.validation.confirmPassword) {
        if (this.imageToUpload) {
          this.uploadPhoto()
        } else {
          this.editAccount()
        }
      } else {
        this.$store.dispatch('states/setMessage', 'Credentials are invalid, please enter valid credentials.')
        this.$store.dispatch('states/openSnackbar')
      }
    },
    uploadPhoto () {
      this.$store.dispatch('loading/loading', true)

      this.$apollo.query({
        query: gql`
        query requestFileUploadToken {
          requestFileUploadToken {
            postUrl
          }
        }
        `
      }).then((response) => {
        this.$store.dispatch('loading/loading', false)

        const url = response.data.requestFileUploadToken.postUrl
        axios.post(url, { imageData: this.imageToUpload }).then((response2) => {
          this.uploadedImage = response2.data.getUrl
          this.editAccount()
        }).catch(() => {
          this.$store.dispatch('loading/loading', false)

          this.$store.dispatch('states/setMessage', 'The image upload failed. Please try repeating the action.')
          this.$store.dispatch('states/openSnackbar')
        })
      }).catch((response) => {
        this.$store.dispatch('loading/loading', false)
        this.$store.dispatch('states/setMessage', response.graphQLErrors[0].message)
        this.$store.dispatch('states/openSnackbar')
      })
    },
    editAccount () {
      this.$store.dispatch('loading/loading', true)

      this.$apollo.mutate({
        mutation: gql`
        mutation editAccount(
          $profilePhoto: String
          $firstName: String
          $lastName: String
          $email: String!
          $phone: String
          $password: String
          $confirmPassword: String
          $autoSend: Boolean
        ) {
          editAccount (
            profilePhoto: $profilePhoto
            firstName: $firstName
            lastName: $lastName
            email: $email
            phone: $phone
            password: $password
            confirmPassword: $confirmPassword
            autoSend: $autoSend
          ) {
            id
            profilePhoto
            firstName
            lastName
            email
            phone
            autoSend
          }
        }
        `,
        variables: {
          profilePhoto: this.uploadedImage,
          firstName: this.firstName,
          lastName: this.lastName,
          email: this.email,
          phone: this.phone,
          password: this.password,
          confirmPassword: this.confirmPassword,
          autoSend: this.autoSend
        }
      }).then((response) => {
        this.$store.dispatch('loading/loading', false)
        this.$store.dispatch('auth/setUser', response.data.editAccount)
        this.$refs.saveSuccess.open()
      }).catch((response) => {
        this.$store.dispatch('loading/loading', false)
        this.$store.dispatch('states/setMessage', response.graphQLErrors[0].message)
        this.$store.dispatch('states/openSnackbar')
      })
    }
  },
  mounted () {
    this.$ua.trackView('MyAccount', '/myAccount')
  }
}
</script>

<style lang="scss">
@import '../../../assets/scss/variables';

#saveSuccess {
  .ui-modal__content {
    margin:         20px;
    display:        flex;
    flex-direction: column;
    align-items:    center;
  }

  p {
    max-width:   360px;
    margin:      0;
    color:       $grey-basic;
    font-size:   16px;
    font-weight: 400;
    line-height: 24px;
    text-align:  center;
  }
}

#unsavedChanges p {
  text-align: center;
  max-width:   360px;
  margin:      0;
  color:       $grey-basic;
  font-size:   16px;
  font-weight: 400;
  line-height: 24px;
  text-align:  center;
}
</style>
