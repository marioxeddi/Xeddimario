<template>
  <div v-if="loading < 1">
    <ui-layout container justify-center wrap :style="{ marginTop: '90px' }">
      <ui-layout class="col-xs-12 col-md-8" :style="{ padding: '0' }" justify-center wrap>
        <ui-layout
          v-for="boost in boosts.data"
          :key="boost.id"
          class="col-xs-12 col-sm-6 col-md-4"
        >
          <ui-mini-boost-card
            :tags="boost.tags"
            :date="boost.date"
            :coverImage="boost.coverImage"
            :completed="boost.sent"
            :header="boost.title"
            :content="boost.summary"
            :sends="boost.sends"
            :opens="boost.opens"
            :clicks="boost.clicks"
            @click.native="$router.push({ name: 'marketingBoost', params: { id: boost.id } })"
            :style="{ marginBottom: '30px' }"
          />
        </ui-layout>
      </ui-layout>
      <ui-layout justify-center>
        <ui-pagination
          :current="pagination.page"
          :pages="pages"
          @pagination="changePage"
        />
      </ui-layout>
      <ui-header font-weight="300" font-size="26">
        My Reports
      </ui-header>
      <ui-layout class="col-xs-12 col-md-8" wrap :style="{ padding: '0' }">
        <ui-subheader
          class="color-grey-dark"
        >
          Your Marketing Boost reports and analytics will be available seven days after you send your first marketing boost.
        </ui-subheader>
      </ui-layout>
      <ui-layout class="col-xs-12 col-md-8" wrap :style="{ padding: '0' }">
        <ui-layout class="col-xs-12 col-md-6">
          <ui-card header="Engagement via Email" fluid>
            <ui-bar-chart
              :data="stats.statsViaEmail.data"
              :options="stats.statsViaEmail.options"
            />
          </ui-card>
        </ui-layout>
        <ui-layout class="col-xs-12 col-md-6">
          <ui-card header="Clicks via Social Media" fluid>
            <ui-bar-chart
              :data="stats.statsViaSocial.data"
              :options="stats.statsViaSocial.options"
            />
          </ui-card>
        </ui-layout>
        <ui-layout class="col-xs-12 col-md-6">
          <ui-card header="Clicks" fluid>
            <ui-doughnut-chart
              :data="stats.clicksViaChannel.data"
              :options="stats.clicksViaChannel.options"
            />
          </ui-card>
        </ui-layout>
        <ui-layout class="col-xs-12 col-md-6">
          <ui-card header="Leads Generated" fluid>
            <ui-doughnut-chart
              :data="stats.leadsViaChannel.data"
              :options="stats.leadsViaChannel.options"
            />
          </ui-card>
        </ui-layout>
      </ui-layout>
    </ui-layout>
  </div>
</template>

<script>
import gql from 'graphql-tag'

export default {
  name: 'AgentMyBoosts',
  data () {
    return {
      loading: 0,
      boosts: [],
      agentDashboard: {},
      stats: {
        statsViaEmail: {
          data: {
            labels: [],
            datasets: [{
              label: 'Clicks',
              backgroundColor: '#358ED7',
              data: []
            },
            {
              label: 'Opens',
              backgroundColor: '#5E6977',
              data: []
            }]
          },
          options: {
            legend: {
              labels: {
                boxWidth: 12
              }
            }
          }
        },
        statsViaSocial: {
          data: {
            labels: [],
            datasets: [{
              backgroundColor: [],
              data: []
            }]
          },
          options: {
            legend: {
              display: false,
              labels: {
                boxWidth: 12
              }
            }
          }
        },
        clicksViaChannel: {
          data: {
            labels: [],
            datasets: [{
              backgroundColor: [],
              data: []
            }]
          },
          options: {
            percentageInnerCutout: 80,
            legend: {
              display: true,
              position: 'right',
              labels: {
                boxWidth: 12
              }
            }
          }
        },
        leadsViaChannel: {
          data: {
            labels: [],
            datasets: [{
              backgroundColor: [],
              data: []
            }]
          },
          options: {
            percentageInnerCutout: 20,
            legend: {
              display: true,
              position: 'right',
              labels: {
                boxWidth: 12
              }
            }
          }
        }
      },
      pagination: {
        page: 1,
        offset: 0,
        countPerPage: 9
      }
    }
  },
  apollo: {
    boosts: {
      query: gql`
      query getBoosts($offset: Int!, $countPerPage: Int!) {
        getBoosts(offset: $offset, countPerPage: $countPerPage) {
          totalCount
          data {
            id
            coverImage
            title
            summary
            date
            sent
            sends
            opens
            clicks
            tags {
              text
              color {
                r
                g
                b
              }
            }
          }
        }
      }
      `,
      variables () {
        return {
          offset: this.pagination.offset,
          countPerPage: this.pagination.countPerPage
        }
      },
      update: (response) => response.getBoosts,
      loadingKey: 'loading'
    },
    agentDashboard: {
      query: gql`
      query agentDashboard {
        agentDashboard {
          boostStats {
            contactSourceStats {
              sends
              clicks
              opens
              leads
              sourceType
            }
            socialMediaStats {
              clicks
              leads
              socialNetworkType
            }
            channelStats {
              clicks
              leads
              channelType
            }
            totalClicks
            totalLeads
          }
        }
      }
      `,
      result ({ data }) {
        this.populateStatsViaEmailData(data)
        this.populateStatsViaSocialData(data)
        this.populateStatsViaChannelData(data)
      },
      update: (response) => response.agentDashboard,
      loadingKey: 'loading'
    }
  },
  computed: {
    pages () {
      const count = this.boosts.totalCount / this.pagination.countPerPage

      return count <= 1 ? 1 : Math.ceil(count)
    }
  },
  watch: {
    loading (value) {
      if (value !== 0) {
        this.$store.dispatch('loading/loading', true)
      } else {
        this.$store.dispatch('loading/loading', false)
      }
    }
  },
  methods: {
    getChannelTypeBackgroundColor (channelType) {
      if (channelType === 'Facebook') {
        return '#4460A0'
      }

      if (channelType === 'LinkedIn') {
        return '#007EBB'
      }

      if (channelType === 'LinkedIn') {
        return '#007EBB'
      }

      if (channelType === 'Google+') {
        return '#F93F2D'
      }

      if (channelType === 'Twitter') {
        return '#00AAEC'
      }

      if (channelType === 'Gmail') {
        return '#AC3D31'
      }

      if (channelType === 'Yahoo') {
        return '#6B0094'
      }

      if (channelType === 'Outlook' || channelType === 'MSN') {
        return '#0072C6'
      }

      if (channelType === 'AOL') {
        return '#2D3140'
      }

      if (channelType === 'iCloud') {
        return '#BD10E0'
      }

      if (channelType === 'Other') {
        return '#878787'
      }

      return '#000000'
    },
    populateStatsViaEmailData (data) {
      const self = this
      const statsViaEmailData = {
        labels: [],
        datasets: [{
          label: 'Clicks',
          backgroundColor: '#358ED7',
          data: []
        },
        {
          label: 'Opens',
          backgroundColor: '#5E6977',
          data: []
        }]
      }

      data.agentDashboard.boostStats.contactSourceStats.forEach(function (element) {
        statsViaEmailData.labels.push(element.sourceType)
        statsViaEmailData.datasets[0].data.push(element.clicks)
        statsViaEmailData.datasets[1].data.push(element.opens)
      })

      self._data.stats.statsViaEmail.data = statsViaEmailData
    },
    populateStatsViaSocialData (data) {
      const self = this

      const statsViaSocialData = {
        labels: [],
        datasets: [{
          backgroundColor: [],
          data: []
        }]
      }

      data.agentDashboard.boostStats.socialMediaStats.forEach(function (element) {
        statsViaSocialData.labels.push(element.socialNetworkType)
        statsViaSocialData.datasets[0].data.push(element.clicks)
        statsViaSocialData.datasets[0].backgroundColor.push(self.getChannelTypeBackgroundColor(element.socialNetworkType))
      })

      self._data.stats.statsViaSocial.data = statsViaSocialData
    },
    populateStatsViaChannelData (data) {
      const self = this

      const clicksViaChannelData = {
        labels: [],
        datasets: [{
          backgroundColor: [],
          data: []
        }]
      }

      const leadsViaChannelData = {
        labels: [],
        datasets: [{
          backgroundColor: [],
          data: []
        }]
      }

      data.agentDashboard.boostStats.channelStats.forEach(function (element) {
        // remove 'if' statements if we want to show ALL keys in the legend.
        if (element.clicks > 0) {
          clicksViaChannelData.labels.push(element.channelType)
          clicksViaChannelData.datasets[0].data.push(element.clicks)
          clicksViaChannelData.datasets[0].backgroundColor.push(self.getChannelTypeBackgroundColor(element.channelType))
        }

        if (element.leads > 0) {
          leadsViaChannelData.labels.push(element.channelType)
          leadsViaChannelData.datasets[0].data.push(element.leads)
          leadsViaChannelData.datasets[0].backgroundColor.push(self.getChannelTypeBackgroundColor(element.channelType))
        }
      })

      self._data.stats.clicksViaChannel.data = clicksViaChannelData
      self._data.stats.leadsViaChannel.data = leadsViaChannelData
    },
    changePage (page) {
      this.pagination.page = page
      this.pagination.offset = (page - 1) * this.pagination.countPerPage
    }
  },
  mounted () {
    this.$ua.trackView('MyBoosts', '/myBoosts')
  }
}
</script>

<style lang="scss" scoped>
.ui-card {
  margin-bottom: 20px;
}
</style>
