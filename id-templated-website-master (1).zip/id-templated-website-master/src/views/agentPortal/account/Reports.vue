<template>
  <ui-layout container justify-center wrap :style="{ marginTop: '90px' }">
    <ui-layout class="col-xs-12 col-md-8" wrap :style="{ padding: '0' }">
      <ui-layout class="col-xs-12 col-md-6" :style="{ marginBottom: '30px' }">
        <ui-card header="Engagement via Email" fluid>
          <ui-bar-chart
            :data="stats.statsViaEmail.data"
            :options="stats.statsViaEmail.options"
          />
        </ui-card>
      </ui-layout>
      <ui-layout class="col-xs-12 col-md-6" :style="{ marginBottom: '30px' }">
        <ui-card header="Clicks via Social Media" fluid>
          <ui-bar-chart
            :data="stats.statsViaSocial.data"
            :options="stats.statsViaSocial.options"
          />
        </ui-card>
      </ui-layout>
      <ui-layout class="col-xs-12 col-md-6" :style="{ marginBottom: '30px' }">
        <ui-card header="Clicks" fluid>
          <ui-doughnut-chart
            :data="stats.clicksViaChannel.data"
            :options="stats.clicksViaChannel.options"
          />
        </ui-card>
      </ui-layout>
      <ui-layout class="col-xs-12 col-md-6" :style="{ marginBottom: '30px' }">
        <ui-card header="Leads Generated" fluid>
          <ui-doughnut-chart
            :data="stats.leadsViaChannel.data"
            :options="stats.leadsViaChannel.options"
          />
        </ui-card>
      </ui-layout>
    </ui-layout>
  </ui-layout>
</template>

<script>
import gql from 'graphql-tag'

export default {
  name: 'AgentReports',
  data () {
    return {
      stats: {
        statsViaEmail: {
          data: {
            labels: [],
            datasets: [{
              label: 'Clicks',
              backgroundColor: '#358ED7',
              data: []
            },
            {
              label: 'Opens',
              backgroundColor: '#5E6977',
              data: []
            }]
          },
          options: {
            legend: {
              labels: {
                boxWidth: 12
              }
            }
          }
        },
        statsViaSocial: {
          data: {
            labels: [],
            datasets: [{
              backgroundColor: [],
              data: []
            }]
          },
          options: {
            legend: {
              display: false,
              labels: {
                boxWidth: 12
              }
            }
          }
        },
        clicksViaChannel: {
          data: {
            labels: [],
            datasets: [{
              backgroundColor: [],
              data: []
            }]
          },
          options: {
            percentageInnerCutout: 80,
            legend: {
              display: true,
              position: 'right',
              labels: {
                boxWidth: 12
              }
            }
          }
        },
        leadsViaChannel: {
          data: {
            labels: [],
            datasets: [{
              backgroundColor: [],
              data: []
            }]
          },
          options: {
            percentageInnerCutout: 20,
            legend: {
              display: true,
              position: 'right',
              labels: {
                boxWidth: 12
              }
            }
          }
        }
      }
    }
  },
  apollo: {
    agentDashboard: {
      query: gql`
      query agentDashboard {
        agentDashboard {
          boostStats {
            contactSourceStats {
              sends
              clicks
              opens
              leads
              sourceType
            }
            socialMediaStats {
              clicks
              leads
              socialNetworkType
            }
            channelStats {
              clicks
              leads
              channelType
            }
            totalClicks
            totalLeads
          }
        }
      }
      `,
      result ({ data }) {
        this.populateStatsViaEmailData(data)
        this.populateStatsViaSocialData(data)
        this.populateStatsViaChannelData(data)
      },
      update: (response) => response.agentDashboard,
      loadingKey: 'loading'
    }
  },
  methods: {
    getChannelTypeBackgroundColor (channelType) {
      if (channelType === 'Facebook') {
        return '#4460A0'
      }

      if (channelType === 'LinkedIn') {
        return '#007EBB'
      }

      if (channelType === 'LinkedIn') {
        return '#007EBB'
      }

      if (channelType === 'Google+') {
        return '#F93F2D'
      }

      if (channelType === 'Twitter') {
        return '#00AAEC'
      }

      if (channelType === 'Gmail') {
        return '#AC3D31'
      }

      if (channelType === 'Yahoo') {
        return '#6B0094'
      }

      if (channelType === 'Outlook' || channelType === 'MSN') {
        return '#0072C6'
      }

      if (channelType === 'AOL') {
        return '#2D3140'
      }

      if (channelType === 'iCloud') {
        return '#BD10E0'
      }

      if (channelType === 'Other') {
        return '#878787'
      }

      return '#000000'
    },
    populateStatsViaEmailData (data) {
      const self = this
      const statsViaEmailData = {
        labels: [],
        datasets: [{
          label: 'Clicks',
          backgroundColor: '#358ED7',
          data: []
        },
        {
          label: 'Opens',
          backgroundColor: '#5E6977',
          data: []
        }]
      }

      data.agentDashboard.boostStats.contactSourceStats.forEach(function (element) {
        statsViaEmailData.labels.push(element.sourceType)
        statsViaEmailData.datasets[0].data.push(element.clicks)
        statsViaEmailData.datasets[1].data.push(element.opens)
      })

      self._data.stats.statsViaEmail.data = statsViaEmailData
    },
    populateStatsViaSocialData (data) {
      const self = this

      const statsViaSocialData = {
        labels: [],
        datasets: [{
          backgroundColor: [],
          data: []
        }]
      }

      data.agentDashboard.boostStats.socialMediaStats.forEach(function (element) {
        statsViaSocialData.labels.push(element.socialNetworkType)
        statsViaSocialData.datasets[0].data.push(element.clicks)
        statsViaSocialData.datasets[0].backgroundColor.push(self.getChannelTypeBackgroundColor(element.socialNetworkType))
      })

      self._data.stats.statsViaSocial.data = statsViaSocialData
    },
    populateStatsViaChannelData (data) {
      const self = this

      const clicksViaChannelData = {
        labels: [],
        datasets: [{
          backgroundColor: [],
          data: []
        }]
      }

      const leadsViaChannelData = {
        labels: [],
        datasets: [{
          backgroundColor: [],
          data: []
        }]
      }

      data.agentDashboard.boostStats.channelStats.forEach(function (element) {
        // remove 'if' statements if we want to show ALL keys in the legend.
        if (element.clicks > 0) {
          clicksViaChannelData.labels.push(element.channelType)
          clicksViaChannelData.datasets[0].data.push(element.clicks)
          clicksViaChannelData.datasets[0].backgroundColor.push(self.getChannelTypeBackgroundColor(element.channelType))
        }

        if (element.leads > 0) {
          leadsViaChannelData.labels.push(element.channelType)
          leadsViaChannelData.datasets[0].data.push(element.leads)
          leadsViaChannelData.datasets[0].backgroundColor.push(self.getChannelTypeBackgroundColor(element.channelType))
        }
      })

      self._data.stats.clicksViaChannel.data = clicksViaChannelData
      self._data.stats.leadsViaChannel.data = leadsViaChannelData
    }
  },
  mounted () {
    this.$ua.trackView('Reports', '/reports')
  }
}
</script>

<style lang="scss">
</style>
