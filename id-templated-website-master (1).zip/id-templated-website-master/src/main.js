// IMPORTS
import Vue from 'vue'
import CONFIG from './config'
import VueRouter from 'vue-router'
import VueAnalytics from 'vue-ua'
import apollo from './apollo'
import VueApollo from 'vue-apollo'
import VueMoment from 'vue-moment'
import VTooltip from 'v-tooltip'
import Components from './components'
import store from './store'
import { VueMaskDirective } from 'v-mask'

/* eslint-disable no-unused-vars */
import moment from 'moment'

// VUE USE
Vue.use(VueRouter)
Vue.use(VueApollo)
Vue.use(VueMoment)
Vue.use(VTooltip)
Vue.use(Components)

VTooltip.options.autoHide = false

// DIRECTIVES
Vue.directive('mask', VueMaskDirective)

// UTILS
// import JWT from './plugins/jwt'
import './plugins/filters'

// ROUTER
const router = new VueRouter({
  routes: CONFIG.routes,
  mode: 'history',
  scrollBehavior () {
    return { y: 0 }
  }
})

// VueAnalytics (Google Analytics plugin)
Vue.use(VueAnalytics, {
  appName: 'americo.insurancedrip.com',
  appVersion: '1.0',
  trackingId: 'UA-111029755-1',
  debug: true,
  vueRouter: router
})

// APOLLO CLIENT
const apolloProvider = new VueApollo({
  defaultClient: apollo
})

// AUTH VALIDATION
router.beforeEach((to, from, next) => {
  store.dispatch('states/closeSnackbar')

  const token = store.state.auth.token
  const user = store.state.auth.user

  if (to.name !== 'LinkAccountSyncHandler' &&
    to.name !== 'login' &&
    to.name !== 'verifyAccount' &&
    to.name !== 'createAccount' &&
    to.name !== 'launchBoost') {
    store.dispatch('boostLibrary/resetSelectedBoostId')
  }

  // console.log(store.state.boostLibrary.selectedBoostId)

  if (token && (to.name === 'landingPage' || to.name === 'verifyAccount' || to.name === 'createAccount')) {
    if (user.isCarrier) {
      next({ name: 'carrierDashboard' })
    } else {
      next({ name: 'myBoosts' })
    }
  } else if (to.meta.auth) {
    if (token) {
      store.dispatch('auth/check').then((response) => {
        if (!response.success) {
          store.dispatch('auth/logout')
          next({ name: 'login' })
        } else if (to.name !== 'launchBoost' && !response.data.hasSentABoost) {
          next({ name: 'launchBoost' })
        } else next()
      }).catch(() => {
        store.dispatch('auth/logout')
        next({ name: 'login' })
      })
    } else {
      next({ name: 'login' })
    }
  } else next()
})

// SCSS
import './assets/scss/import.scss'

// MOUNT APP
import App from './App.vue'

new Vue({
  store,
  router,
  apolloProvider,
  render: h => h(App)
}).$mount('#app')
