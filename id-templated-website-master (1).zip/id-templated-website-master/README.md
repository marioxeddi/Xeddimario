# InsuranceDrip Carrier Edition Templated Website
Built with Vue.js

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build

# build for staging
npm run build:staging

# build for production and view the bundle analyzer report
npm run build --report
```

For detailed explanation on how things work, checkout the [guide](http://vuejs-templates.github.io/webpack/) and [docs for vue-loader](http://vuejs.github.io/vue-loader).

# UI kit guidelines
`ui-avatar`
*image uploading/displaying component*
- id: REQUIRED, String - provides the functionality of opening the cropper, can be anything you'll want to, but it has to be String
- uploadable: Boolean - if provided, the UPLOAD button will appear next to the image
- custom-upload-text: String - provide this prop to change the UPLOAD button text, otherwise it will be "Upload Profile Photo"
- src: String - provide this if you want the component to have a preloaded image

`ui-boost-card`
*component for displaying the marketing boost detail*
- tags: Array - provide this tag to display tags on the top of the boost card, one tag should have this structure:
```
tag: {
  text: 'someText'
  color: {
    r: 123,
    g: 123,
    b: 123
  }
}
```
- date: String - provide this to display the date on the top of the card (format: YYYY-MM-DD HH:mm:ss)
- cover-image: String - the URL to the image of displayed in the marketing boost
- header: String - The big header text displayed below the image
- content: String - HTML content of the marketing boost - will get automatically formatted if HTML tags are provided in the string

`ui-button`
*button*
- disabled: Boolean - makes the button gray and unclickable
- dense: Boolean - makes the button smaller than the original size
- success: Boolean - makes the button to have a green background and white text
- blue: Boolean - makes the button to have a thin blue border and blue text (takes color from the `$blue` SCSS variable)
- dark: Boolean - makes the button to have a white background (good for usage on dark on colored backgrounds)
- color-primary: Boolean - makes the button to have the text color, that the carrier has set in his settings
- outline: Boolean - makes the button to have a normal width (2px) border with a light grey color
- outline-alert: Boolean - makes the button to have a normal width (2px) border with a red color
- fluid: Boolean - makes the button to be 100% wide of it's parent's width
- to: String - if provided, the button will redirect to the desired named route upon click

`ui-card`
*component prepared to hold content in it*
- header: String - if provided, this will create a header on the top of the card
- subheader: String - if provided, this will create a subheader on the right side of the header on the top of the card
- fluid: Boolean - makes the card to be 100% wide of it's parent's width
- unresponsiveStyle: Boolean - makes the card to behave like a normal component, so it won't be stretched to the whole screen on small devices

`ui-checkbox`
*checkbox*
- id: REQUIRED, String - basic HTML functionality, ID is required for checkboxes, can be whatever you want
- value: Boolean - Checked from the beginning or not?
- label: String - the text next to the checkbox
- dense: Boolean - makes the checkbox smaller

`ui-color-picker`
*color picker*
- id: REQUIRED, String - if not provided, the color picker won't open, can be whatever you want
- value: Object - initial value of the picker, should be in this format:
```
{
  r: 123,
  g: 123,
  b: 123
}
```

`ui-form-header`
*text describing a part of a form, can be seen in agent's account settings for example*
- NO PROPS

`ui-header`
*big text that makes sections of the app stand out*
- aling-left: Boolean - self explanatory
- aling-center: Boolean - self explanatory
- aling-right: Boolean - self explanatory
- font-size: Number/String - self explanatory
- font-weight: Number/String - self explanatory
- top: Number/String - top margin
- bottom: Number/String - bottom margin

`ui-icon`
*material design icon*
- primary: Boolean - the icon will have the color, that carrier has set for his theme
- size: String/Number - size of the icon, default is 24
- grey-light: Boolean - light grey color of the icon
- grey-basic: Boolean - basic grey color of the icon
- grey-dark: Boolean - dark grey color of the icon
- custom-color: String - custom color of the icon
- border: Boolean - makes the icon green and have a circular border around it

`ui-input`
*input*
- type: DEFAULT: text, String - type of the input
- label: String - when provided this will display a label above the input
- label-right: Boolean - aligns the label to the right side
- placeholder: String - provides a placeholder for the input
- value: String/Number - provides the initial value for the input
- fluid: Boolean - makes the input to be 100% wide of it's parent's width
- tooltip: String - provides a tooltip for the input (that little (?) icon next to the label)
- max-width: String/Number - sets the max width of the input
- mask: String - provides an input mask (auto formatting of the input text)
- validation: Boolean - turns on the input validation
- valid: Boolean - decides whether the input value is valid or not (provide method for input validation in the parent component)

`ui-layout`
*grid component*
- container: Boolean - if provided, the component will behave as a container (will have fixed width and will be centered on the screen)
- wrap: Boolean - when the children overlap one row, they will be thrown into a new row, if not turned on, they will be always in the same row no matter how wide they are
- align-start: Boolean - aligns the content up (vertically)
- align-center: Boolean - aligns the content to the center (vertically)
- align-end: Boolean - aligns the content down (vertically)
- justify-start: Boolean - aligns the content to the left side (horizontally)
- justify-center: Boolean - aligns the content to the center (horizontally)
- justify-end: Boolean - aligns the content to the right side (horizontally)
- justify-space-between: Boolean - aligns the children to have equal gaps between them (horizontally)
- column: Boolean - turns the whole grid by 90 degrees - the children will not sit next to each other, but one below each other

`ui-loading`
*the loading animation*
- visible: Boolean - decides whether the loading is visible or not, it can be displayed or hidden via store module "loading"

`ui-mini-boost-card`
*marketing boost thumbnail*
- tags: Array - provide this tag to display tags on the top of the boost card, one tag should have this structure:
```
tag: {
  text: 'someText'
  color: {
    r: 123,
    g: 123,
    b: 123
  }
}
```
- date: String - provide this to display the date on the top of the card (format: YYYY-MM-DD HH:mm:ss)
- cover-image: String - the URL to the image of displayed in the marketing boost
- header: String - The big header text displayed below the image
- content: String - HTML content of the marketing boost - will get automatically formatted if HTML tags are provided in the string
- completed: Boolean - decices whether the blue or green button should be displayed
- sends: Number - stats below the button
- opens: Number - stats below the button
- clicks: Number - stats below the button

`ui-modal`
*modal*
- id: REQUIRED, String - without providing this the user won't be able to close the modal
- visible: Boolean - decides whether the modal should be displayed or not
- non-closable: Boolean - if provided, the user won't be able to close the modal in any other way, than clicking any action button in it, that calls the `close()` method of this modal

`ui-modal-actions`
*bottom part of the modal that includes buttons*
- wrap: Boolean - when the children overlap one row, they will be thrown into a new row, if not turned on, they will be always in the same row no matter how wide they are
- align-start: Boolean - aligns the content up (vertically)
- align-center: Boolean - aligns the content to the center (vertically)
- align-end: Boolean - aligns the content down (vertically)
- justify-start: Boolean - aligns the content to the left side (horizontally)
- justify-center: Boolean - aligns the content to the center (horizontally)
- justify-end: Boolean - aligns the content to the right side (horizontally)
- justify-space-between: Boolean - aligns the children to have equal gaps between them (horizontally)
- column: Boolean - turns the whole grid by 90 degrees - the children will not sit next to each other, but one below each other

`ui-pagination`
*component used to click between multiple pages of content*
- current: REQUIRED, Number - the current page of the pagination
- pages: REQUIRED, Number - tells the pagination how many pages it should have

`ui-select`
*selectbox*
- label: String - when provided this will display a label above the input
- placeholder: String - provides a placeholder for the input
- data: REQUIRED, Array - the data for the selectbox:
```
[
  {
    id: 1,
    text: 'option one'
  },
  {
    id: 2,
    text: 'option two'
  }
]
```
- track-by: REQUIRED, String - internal thing for the select, the key by which it should track the selection
- text: REQUIRED, String - what key to track for displaying the text in the select dropdown options
- fluid: Boolean - makes the select to be 100% wide of it's parent's width
- default: Number - the number (NOT INDEX!) of the default value in the select

`ui-snackbar`
*informational bar at the bottom of the page, that should open when some error occurs*
- see store module "states" or any component with Apollo requrests for example
