module.exports = {
  NODE_ENV: '"staging"'
}
