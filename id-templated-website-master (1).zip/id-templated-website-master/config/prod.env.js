NODE_ENV = process.env.NODE_ENV || 'production';

module.exports = {
  NODE_ENV: '"' + NODE_ENV + '"'
}
